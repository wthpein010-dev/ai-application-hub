using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Automation;
using System.Windows.Forms;
using System.Web.Script.Serialization;

namespace CodexHabitTool
{
    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            bool tray = args != null && Array.Exists(args, a => string.Equals(a, "--tray", StringComparison.OrdinalIgnoreCase));
            Application.Run(new MainForm(tray));
        }
    }

    public class MainForm : Form
    {
        private const int HotkeyId = 0x5301;
        private const int ModAlt = 0x0001;
        private const int WmHotkey = 0x0312;
        private const int SwHide = 0;
        private const int SwShow = 5;
        private const int SwRestore = 9;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);

        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc enumProc, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        private readonly CheckBox chineseChat = new CheckBox();
        private readonly CheckBox chineseUi = new CheckBox();
        private readonly CheckBox terraModel = new CheckBox();
        private readonly CheckBox altS = new CheckBox();
        private readonly CheckBox startup = new CheckBox();
        private readonly CheckBox hotkeyAlt = new CheckBox();
        private readonly CheckBox hotkeyControl = new CheckBox();
        private readonly CheckBox hotkeyShift = new CheckBox();
        private readonly CheckBox hotkeyWindows = new CheckBox();
        private readonly ComboBox hotkeyKey = new ComboBox();
        private readonly ComboBox modelPicker = new ComboBox();
        private readonly ComboBox reasoningPicker = new ComboBox();
        private readonly TextBox logBox = new TextBox();
        private readonly NotifyIcon trayIcon = new NotifyIcon();
        private readonly Label reportStatus = new Label();
        private readonly Label namingStatus = new Label();
        private readonly Button openLatestReportButton = new Button();
        private bool threadNameUpdateRunning;

        public MainForm(bool startHidden)
        {
            Text = "Codex 习惯设置工具";
            Width = 760;
            Height = 930;
            MinimumSize = new Size(720, 840);
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            BackColor = Color.FromArgb(246, 248, 252);

            BuildUi();

            chineseChat.Checked = true;
            chineseUi.Checked = true;
            terraModel.Checked = true;
            altS.Checked = true;
            LoadHotkeySettings();
            LoadModelSettings();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            trayIcon.Visible = false;
            base.OnFormClosing(e);
        }

        private void BuildUi()
        {
            var header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 112;
            header.BackColor = Color.FromArgb(34, 91, 138);
            header.Paint += delegate(object sender, PaintEventArgs e)
            {
                using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(header.ClientRectangle, Color.FromArgb(28, 94, 145), Color.FromArgb(52, 137, 124), 0F))
                {
                    e.Graphics.FillRectangle(brush, header.ClientRectangle);
                }
            };
            Controls.Add(header);

            var title = new Label();
            title.Text = "Codex 习惯设置工具";
            title.ForeColor = Color.White;
            title.BackColor = Color.Transparent;
            title.Font = new Font("Microsoft YaHei UI", 20F, FontStyle.Bold);
            title.AutoSize = true;
            title.Location = new Point(28, 22);
            header.Controls.Add(title);

            var subtitle = new Label();
            subtitle.Text = "把常用偏好、快捷键和对话报告集中管理。";
            subtitle.ForeColor = Color.FromArgb(226, 246, 255);
            subtitle.BackColor = Color.Transparent;
            subtitle.Font = new Font("Microsoft YaHei UI", 10.5F);
            subtitle.AutoSize = true;
            subtitle.Location = new Point(30, 68);
            header.Controls.Add(subtitle);

            var body = new TableLayoutPanel();
            body.Location = new Point(0, header.Height);
            body.Size = new Size(ClientSize.Width, ClientSize.Height - header.Height);
            body.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            body.Padding = new Padding(28, 24, 28, 18);
            body.ColumnCount = 1;
            body.RowCount = 5;
            body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            body.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Controls.Add(body);
            header.BringToFront();

            var card = new Panel();
            card.BackColor = Color.White;
            card.Padding = new Padding(22);
            card.Height = 440;
            card.Dock = DockStyle.Top;
            card.Paint += delegate(object sender, PaintEventArgs e)
            {
                using (var pen = new Pen(Color.FromArgb(222, 229, 238)))
                {
                    e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
                }
            };
            body.Controls.Add(card, 0, 0);

            body.Controls.Add(BuildReportCard(), 0, 1);

            var cardTitle = new Label();
            cardTitle.Text = "要应用的设置";
            cardTitle.Font = new Font("Microsoft YaHei UI", 13F, FontStyle.Bold);
            cardTitle.ForeColor = Color.FromArgb(30, 42, 58);
            cardTitle.AutoSize = true;
            cardTitle.Location = new Point(22, 18);
            card.Controls.Add(cardTitle);

            InitCheck(chineseChat, "默认用中文沟通", "写入一份全局习惯说明，让新线程优先中文、回答更短更自然。", 52, card);
            InitCheck(chineseUi, "Codex 界面优先中文", "设置 Codex 内置浏览器语言偏好为 zh-CN，尽量让界面和网页中文优先。", 102, card);
            InitCheck(terraModel, "设置默认模型", "选择新线程默认使用的模型和推理档位，应用后写入 Codex 配置。", 152, card);
            BuildModelSelector(card);
            InitCheck(altS, "启用全局快捷键", "设置窗口退出后，独立的无窗口助手仍可显示或隐藏 Codex。", 242, card);
            BuildHotkeySelector(card);
            InitCheck(startup, "开机启动快捷键助手", "登录 Windows 后自动启动，设置窗口本身不会常驻。", 330, card);
            BuildThreadNamingSection(card);

            var hint = new Label();
            hint.Text = "提示：这些设置都是本机级别，不绑定任何项目。Codex 未来版本若改配置位置，可再次运行本工具重新应用。";
            hint.ForeColor = Color.FromArgb(88, 99, 113);
            hint.AutoSize = true;
            hint.Margin = new Padding(2, 8, 2, 8);
            body.Controls.Add(hint, 0, 2);

            logBox.Multiline = true;
            logBox.ReadOnly = true;
            logBox.ScrollBars = ScrollBars.Vertical;
            logBox.BackColor = Color.FromArgb(252, 253, 255);
            logBox.BorderStyle = BorderStyle.FixedSingle;
            logBox.Font = new Font("Consolas", 9.5F);
            logBox.Dock = DockStyle.Fill;
            body.Controls.Add(logBox, 0, 3);

            var buttons = new FlowLayoutPanel();
            buttons.FlowDirection = FlowDirection.RightToLeft;
            buttons.Dock = DockStyle.Fill;
            buttons.Height = 48;
            buttons.Padding = new Padding(0, 12, 0, 0);
            body.Controls.Add(buttons, 0, 4);

            var apply = MakeButton("应用设置", Color.FromArgb(32, 120, 107), Color.White);
            apply.Click += delegate { ApplyAllWithConfirm(); };
            buttons.Controls.Add(apply);

        }

        private void InitCheck(CheckBox box, string text, string tip, int top, Control parent)
        {
            box.Text = text;
            box.ForeColor = Color.FromArgb(30, 42, 58);
            box.Font = new Font("Microsoft YaHei UI", 10.5F, FontStyle.Bold);
            box.AutoSize = true;
            box.Location = new Point(26, top);
            parent.Controls.Add(box);

            var label = new Label();
            label.Text = tip;
            label.ForeColor = Color.FromArgb(95, 108, 125);
            label.AutoSize = false;
            label.Size = new Size(650, 23);
            label.Location = new Point(28, top + 25);
            parent.Controls.Add(label);
        }

        private void BuildModelSelector(Control parent)
        {
            var modelLabel = new Label();
            modelLabel.Text = "默认模型";
            modelLabel.ForeColor = Color.FromArgb(95, 108, 125);
            modelLabel.AutoSize = true;
            modelLabel.Location = new Point(28, 207);
            parent.Controls.Add(modelLabel);

            modelPicker.DropDownStyle = ComboBoxStyle.DropDownList;
            modelPicker.Font = new Font("Microsoft YaHei UI", 9.5F, FontStyle.Bold);
            modelPicker.Width = 154;
            modelPicker.Location = new Point(94, 202);
            modelPicker.Items.Add("5.6 Terra");
            modelPicker.Items.Add("5.6 Sol");
            modelPicker.Items.Add("5.6 Luna");
            modelPicker.SelectedIndex = 0;
            parent.Controls.Add(modelPicker);

            var reasoningLabel = new Label();
            reasoningLabel.Text = "推理档位";
            reasoningLabel.ForeColor = Color.FromArgb(95, 108, 125);
            reasoningLabel.AutoSize = true;
            reasoningLabel.Location = new Point(278, 207);
            parent.Controls.Add(reasoningLabel);

            reasoningPicker.DropDownStyle = ComboBoxStyle.DropDownList;
            reasoningPicker.Font = new Font("Microsoft YaHei UI", 9.5F, FontStyle.Bold);
            reasoningPicker.Width = 110;
            reasoningPicker.Location = new Point(344, 202);
            reasoningPicker.Items.Add("高");
            reasoningPicker.Items.Add("中");
            reasoningPicker.Items.Add("低");
            reasoningPicker.SelectedIndex = 0;
            parent.Controls.Add(reasoningPicker);
        }

        private void BuildHotkeySelector(Control parent)
        {
            var label = new Label();
            label.Text = "快捷键组合";
            label.ForeColor = Color.FromArgb(95, 108, 125);
            label.AutoSize = true;
            label.Location = new Point(28, 295);
            parent.Controls.Add(label);

            InitHotkeyCheck(hotkeyControl, "Ctrl", 126, parent);
            InitHotkeyCheck(hotkeyAlt, "Alt", 188, parent);
            InitHotkeyCheck(hotkeyShift, "Shift", 238, parent);
            InitHotkeyCheck(hotkeyWindows, "Win", 302, parent);

            hotkeyKey.DropDownStyle = ComboBoxStyle.DropDownList;
            hotkeyKey.Font = new Font("Microsoft YaHei UI", 9.5F, FontStyle.Bold);
            hotkeyKey.Width = 92;
            hotkeyKey.Location = new Point(362, 290);
            for (char letter = 'A'; letter <= 'Z'; letter++) hotkeyKey.Items.Add(letter.ToString());
            for (int functionKey = 1; functionKey <= 12; functionKey++) hotkeyKey.Items.Add("F" + functionKey);
            hotkeyKey.SelectedItem = "S";
            parent.Controls.Add(hotkeyKey);
        }

        private void InitHotkeyCheck(CheckBox box, string text, int left, Control parent)
        {
            box.Text = text;
            box.ForeColor = Color.FromArgb(40, 66, 92);
            box.Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold);
            box.AutoSize = true;
            box.Location = new Point(left, 291);
            parent.Controls.Add(box);
        }

        private Button MakeButton(string text, Color back, Color fore)
        {
            var button = new Button();
            button.Text = text;
            button.BackColor = back;
            button.ForeColor = fore;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold);
            button.Width = 136;
            button.Height = 36;
            button.Margin = new Padding(8, 0, 0, 0);
            return button;
        }

        private Panel BuildReportCard()
        {
            var card = new Panel();
            card.BackColor = Color.FromArgb(247, 251, 255);
            card.Height = 144;
            card.Dock = DockStyle.Top;
            card.Margin = new Padding(0, 8, 0, 0);
            card.Paint += delegate(object sender, PaintEventArgs e)
            {
                using (var pen = new Pen(Color.FromArgb(191, 215, 238)))
                {
                    e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
                }
            };

            var title = new Label();
            title.Text = "对话报告";
            title.ForeColor = Color.FromArgb(30, 70, 112);
            title.Font = new Font("Microsoft YaHei UI", 13F, FontStyle.Bold);
            title.AutoSize = true;
            title.Location = new Point(22, 18);
            card.Controls.Add(title);

            var description = new Label();
            description.Text = "第一次用也很简单：点击“生成并打开报告”，它会读取本机 Codex 对话，更新 Excel 后自动打开。";
            description.ForeColor = Color.FromArgb(78, 99, 123);
            description.Font = new Font("Microsoft YaHei UI", 9.5F);
            description.AutoSize = false;
            description.Size = new Size(490, 40);
            description.Location = new Point(23, 48);
            card.Controls.Add(description);

            reportStatus.Text = "还没有生成报告。";
            reportStatus.ForeColor = Color.FromArgb(95, 112, 132);
            reportStatus.Font = new Font("Microsoft YaHei UI", 9F);
            reportStatus.AutoSize = true;
            reportStatus.Location = new Point(23, 94);
            card.Controls.Add(reportStatus);

            var refresh = MakeButton("生成并打开报告", Color.FromArgb(40, 111, 174), Color.White);
            refresh.Width = 154;
            refresh.Height = 38;
            refresh.Location = new Point(540, 22);
            refresh.Click += delegate { UpdateAndViewReport(refresh); };
            card.Controls.Add(refresh);

            openLatestReportButton.Text = "打开最近报告";
            openLatestReportButton.BackColor = Color.FromArgb(228, 238, 248);
            openLatestReportButton.ForeColor = Color.FromArgb(36, 77, 120);
            openLatestReportButton.FlatStyle = FlatStyle.Flat;
            openLatestReportButton.FlatAppearance.BorderSize = 0;
            openLatestReportButton.Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold);
            openLatestReportButton.Width = 154;
            openLatestReportButton.Height = 34;
            openLatestReportButton.Location = new Point(540, 70);
            openLatestReportButton.Click += delegate { OpenLatestReport(); };
            card.Controls.Add(openLatestReportButton);

            UpdateReportStatus();
            return card;
        }

        private void BuildThreadNamingSection(Control parent)
        {
            var divider = new Panel();
            divider.BackColor = Color.FromArgb(228, 232, 239);
            divider.Size = new Size(666, 1);
            divider.Location = new Point(22, 386);
            parent.Controls.Add(divider);

            var title = new Label();
            title.Text = "线程命名";
            title.ForeColor = Color.FromArgb(79, 55, 126);
            title.Font = new Font("Microsoft YaHei UI", 10.5F, FontStyle.Bold);
            title.AutoSize = true;
            title.Location = new Point(26, 405);
            parent.Controls.Add(title);

            var description = new Label();
            description.Text = "更新近 3 天有变化的对话，标题最多 7 字。";
            description.ForeColor = Color.FromArgb(92, 82, 117);
            description.Font = new Font("Microsoft YaHei UI", 9F);
            description.AutoSize = false;
            description.Size = new Size(390, 22);
            description.Location = new Point(120, 406);
            parent.Controls.Add(description);

            var refresh = MakeButton("更新名称", Color.FromArgb(104, 76, 164), Color.White);
            refresh.Width = 128;
            refresh.Height = 34;
            refresh.Location = new Point(538, 398);
            refresh.Click += delegate { UpdateThreadNames(refresh); };
            parent.Controls.Add(refresh);
        }

        private void UpdateThreadNames(Button button)
        {
            if (threadNameUpdateRunning) return;
            threadNameUpdateRunning = true;
            Log("正在按增量规则检查线程名称。");

            var worker = new BackgroundWorker();
            worker.DoWork += delegate(object sender, DoWorkEventArgs e)
            {
                e.Result = new ThreadNamingService(Application.StartupPath).Run();
            };
            worker.RunWorkerCompleted += delegate(object sender, RunWorkerCompletedEventArgs e)
            {
                threadNameUpdateRunning = false;
                if (e.Error != null)
                {
                    Log("线程命名失败：" + e.Error.Message);
                    MessageBox.Show(this, e.Error.Message, "无法更新线程名称", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                var result = (ThreadNamingResult)e.Result;
                string nativeError = "";
                foreach (ThreadRenameAction action in result.Actions)
                {
                    if (ThreadNativeRenamer.TryRename(action.CurrentTitle, action.NewTitle))
                    {
                        result.State.Entries[action.ThreadId] = new ThreadNamingRecord
                        {
                            Fingerprint = action.Fingerprint,
                            LastRenamedAtMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                            VisibleTitle = action.NewTitle
                        };
                        result.Renamed++;
                    }
                    else
                    {
                        nativeError += (nativeError.Length == 0 ? "" : "\n") + "未能在 Codex 侧栏找到：" + action.CurrentTitle;
                    }
                }
                ThreadNamingStateStore.Save(result.StatePath, result.State);
                Log(result.ToLogText());
                if (CodexSidebarRefreshPolicy.ShouldRefresh(result.Renamed)) RefreshCodexTaskList();
                if (!string.IsNullOrWhiteSpace(result.ErrorMessage))
                {
                    MessageBox.Show(this, result.ErrorMessage, "部分线程未更新", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (!string.IsNullOrWhiteSpace(nativeError))
                {
                    MessageBox.Show(this, nativeError, "部分线程未更新", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            };
            worker.RunWorkerAsync();
        }

        private void RefreshCodexTaskList()
        {
            IntPtr hwnd = FindCodexWindow();
            if (hwnd == IntPtr.Zero) return;
            SetForegroundWindow(hwnd);
            SendKeys.SendWait("{F5}");
            BeginInvoke((MethodInvoker)delegate { Activate(); });
        }

        private void UpdateAndViewReport(Button refreshButton)
        {
            string scannerPath = ReportIntegration.GetScannerPath(Application.StartupPath);
            if (!File.Exists(scannerPath))
            {
                string message = "没有找到对话评分组件。请确认“Codex对话评分工具”文件夹与本工具放在一起。";
                Log(message);
                MessageBox.Show(this, message, "无法生成报告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string outputPath = ReportIntegration.GetNextReportPath(Application.StartupPath);
            refreshButton.Enabled = false;
            reportStatus.Text = "正在读取并生成最新报告，请稍候...";
            reportStatus.Visible = true;
            openLatestReportButton.Visible = false;
            Log("正在生成对话报告：" + outputPath);

            var worker = new BackgroundWorker();
            worker.DoWork += delegate(object sender, DoWorkEventArgs e)
            {
                var info = new ProcessStartInfo();
                info.FileName = scannerPath;
                info.Arguments = ReportIntegration.BuildArguments(outputPath);
                info.UseShellExecute = false;
                info.CreateNoWindow = true;
                info.RedirectStandardOutput = true;
                info.RedirectStandardError = true;

                using (Process process = Process.Start(info))
                {
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();
                    process.WaitForExit();
                    e.Result = new ReportRunResult(outputPath, process.ExitCode, output, error);
                }
            };
            worker.RunWorkerCompleted += delegate(object sender, RunWorkerCompletedEventArgs e)
            {
                refreshButton.Enabled = true;
                if (e.Error != null)
                {
                    ShowReportError("生成报告时出错：" + e.Error.Message);
                    return;
                }

                var result = (ReportRunResult)e.Result;
                if (result.ExitCode != 0 || !File.Exists(result.OutputPath))
                {
                    string detail = string.IsNullOrWhiteSpace(result.Error) ? result.Output : result.Error;
                    ShowReportError("报告没有生成成功。" + Environment.NewLine + detail);
                    return;
                }

                reportStatus.Text = "最新报告：" + Path.GetFileName(result.OutputPath);
                reportStatus.Visible = true;
                openLatestReportButton.Visible = true;
                Log("报告已生成：" + result.OutputPath);
                OpenReport(result.OutputPath);
            };
            worker.RunWorkerAsync();
        }

        private void OpenLatestReport()
        {
            string reportPath = ReportIntegration.FindLatestReport(ReportIntegration.GetReportDirectory(Application.StartupPath));
            if (string.IsNullOrWhiteSpace(reportPath))
            {
                MessageBox.Show(this, "还没有可打开的报告。请先点“生成并打开报告”。", "没有报告", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            OpenReport(reportPath);
        }

        private void OpenReport(string reportPath)
        {
            try
            {
                Process.Start(reportPath);
            }
            catch (Exception ex)
            {
                ShowReportError("无法打开表格：" + ex.Message);
            }
        }

        private void UpdateReportStatus()
        {
            string reportPath = ReportIntegration.FindLatestReport(ReportIntegration.GetReportDirectory(Application.StartupPath));
            bool hasReport = !string.IsNullOrWhiteSpace(reportPath);
            reportStatus.Visible = hasReport;
            openLatestReportButton.Visible = hasReport;
            if (hasReport) reportStatus.Text = "上次报告：" + Path.GetFileName(reportPath);
        }

        private void ShowReportError(string message)
        {
            reportStatus.Text = "报告生成失败，请查看下面的运行记录。";
            reportStatus.Visible = true;
            openLatestReportButton.Visible = false;
            Log(message);
            MessageBox.Show(this, message, "无法生成报告", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void ApplyAllWithConfirm()
        {
            HotkeySettings hotkey = GetHotkeySettingsFromUi();
            string message =
                "即将应用这些设置：\n\n" +
                (chineseChat.Checked ? "· 默认中文沟通\n" : "") +
                (chineseUi.Checked ? "· Codex 界面语言优先中文\n" : "") +
                (terraModel.Checked ? "· 默认模型改为 " + GetSelectedModelName() + " / " + GetSelectedReasoningName() + "\n" : "") +
                (altS.Checked ? "· 启用 " + hotkey.DisplayText + " 打开/隐藏 Codex\n" : "· 关闭全局快捷键\n") +
                (startup.Checked ? "· 开机启动无窗口快捷键助手\n" : "· 不设置快捷键助手开机启动\n") +
                "\n继续吗？";

            if (MessageBox.Show(this, message, "确认应用设置", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK)
            {
                Log("已取消，没有修改设置。");
                return;
            }

            try
            {
                if (terraModel.Checked) ApplyModelConfig();
                if (chineseChat.Checked) WriteHabitFiles();
                if (chineseUi.Checked) ApplyLanguagePreferences();
                ApplyHotkeyAssistantState();
                ApplyStartupState();

                MessageBox.Show(this, "设置已保存。\n\n你可以直接退出本窗口；全局快捷键由无窗口助手维持。模型和语言设置请完全退出 Codex 后重新打开。", "完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Log("应用失败：" + ex.Message);
                MessageBox.Show(this, ex.Message, "应用失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ApplyModelConfig()
        {
            string codexHome = GetCodexHome();
            Directory.CreateDirectory(codexHome);
            string configPath = Path.Combine(codexHome, "config.toml");
            string text = File.Exists(configPath) ? File.ReadAllText(configPath, Encoding.UTF8) : "";
            BackupFile(configPath);
            text = SetTomlString(text, "model", GetSelectedModelId());
            text = SetTomlString(text, "model_reasoning_effort", GetSelectedReasoningId());
            text = SetTomlString(text, "service_tier", "fast");
            File.WriteAllText(configPath, text, new UTF8Encoding(false));
            Log("已设置默认模型：" + GetSelectedModelId() + " / " + GetSelectedReasoningId() + "。");
        }

        private void LoadModelSettings()
        {
            try
            {
                string configPath = Path.Combine(GetCodexHome(), "config.toml");
                if (!File.Exists(configPath)) return;
                string text = File.ReadAllText(configPath, Encoding.UTF8);
                Match model = Regex.Match(text, "(?m)^model\\s*=\\s*\\\"([^\\\"]+)\\\"\\s*$");
                Match effort = Regex.Match(text, "(?m)^model_reasoning_effort\\s*=\\s*\\\"([^\\\"]+)\\\"\\s*$");
                if (model.Success)
                {
                    if (string.Equals(model.Groups[1].Value, "gpt-5.6-sol", StringComparison.OrdinalIgnoreCase)) modelPicker.SelectedItem = "5.6 Sol";
                    else if (string.Equals(model.Groups[1].Value, "gpt-5.6-luna", StringComparison.OrdinalIgnoreCase)) modelPicker.SelectedItem = "5.6 Luna";
                    else modelPicker.SelectedItem = "5.6 Terra";
                }
                if (effort.Success)
                {
                    if (string.Equals(effort.Groups[1].Value, "medium", StringComparison.OrdinalIgnoreCase)) reasoningPicker.SelectedItem = "中";
                    else if (string.Equals(effort.Groups[1].Value, "low", StringComparison.OrdinalIgnoreCase) || string.Equals(effort.Groups[1].Value, "minimal", StringComparison.OrdinalIgnoreCase)) reasoningPicker.SelectedItem = "低";
                    else reasoningPicker.SelectedItem = "高";
                }
            }
            catch { }
        }

        private string GetSelectedModelName()
        {
            return modelPicker.SelectedItem == null ? "5.6 Terra" : modelPicker.SelectedItem.ToString();
        }

        private string GetSelectedModelId()
        {
            if (string.Equals(GetSelectedModelName(), "5.6 Sol", StringComparison.Ordinal)) return "gpt-5.6-sol";
            if (string.Equals(GetSelectedModelName(), "5.6 Luna", StringComparison.Ordinal)) return "gpt-5.6-luna";
            return "gpt-5.6-terra";
        }

        private string GetSelectedReasoningName()
        {
            return reasoningPicker.SelectedItem == null ? "高" : reasoningPicker.SelectedItem.ToString();
        }

        private string GetSelectedReasoningId()
        {
            if (string.Equals(GetSelectedReasoningName(), "中", StringComparison.Ordinal)) return "medium";
            if (string.Equals(GetSelectedReasoningName(), "低", StringComparison.Ordinal)) return "low";
            return "high";
        }

        private void WriteHabitFiles()
        {
            string codexHome = GetCodexHome();
            Directory.CreateDirectory(codexHome);
            string habitPath = Path.Combine(codexHome, "codex-habits.zh-CN.md");
            string text =
                "# Codex 通用习惯\n\n" +
                "- 默认用中文回复，除非用户明确要求其他语言。\n" +
                "- 回答要自然口语一点，少一点技术味，优先说结果。\n" +
                "- 简单任务直接处理，不要反复问开放式问题。\n" +
                "- 线程标题尽量短、口语、好懂，避免像分类标签。\n" +
                "- 默认模型优先使用 5.6 Terra；复杂重构、疑难 bug、长时间任务再建议 Sol。\n" +
                "- 做本机设置、Unity、飞书、网页预览、文件整理时，能直接操作就直接操作，同时保留必要备份。\n";
            File.WriteAllText(habitPath, text, new UTF8Encoding(true));

            string templatePath = Path.Combine(codexHome, "新线程默认提示.txt");
            string template =
                "请按我的通用习惯工作：默认中文、回答简洁自然、能直接做就直接做；默认模型用 5.6 Terra，标题短一点、口语一点。";
            File.WriteAllText(templatePath, template, new UTF8Encoding(true));
            Log("已写入通用习惯说明：" + habitPath);
            Log("已写入新线程提示模板：" + templatePath);
        }

        private void ApplyLanguagePreferences()
        {
            var paths = GetPreferencePaths();
            int count = 0;
            foreach (string path in paths)
            {
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    Dictionary<string, object> root;
                    if (File.Exists(path))
                    {
                        BackupFile(path);
                        string raw = File.ReadAllText(path, Encoding.UTF8);
                        root = string.IsNullOrWhiteSpace(raw)
                            ? new Dictionary<string, object>()
                            : new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(raw);
                    }
                    else
                    {
                        root = new Dictionary<string, object>();
                    }

                    Dictionary<string, object> intl = GetOrCreateDict(root, "intl");
                    intl["accept_languages"] = "zh-CN,zh,en-US,en";

                    Dictionary<string, object> spell = GetOrCreateDict(root, "spellcheck");
                    spell["dictionaries"] = new ArrayList { "zh-CN", "en-US" };
                    if (!spell.ContainsKey("dictionary")) spell["dictionary"] = "";

                    string json = new JavaScriptSerializer().Serialize(root);
                    File.WriteAllText(path, json, new UTF8Encoding(false));
                    count++;
                }
                catch (Exception ex)
                {
                    Log("语言偏好写入失败：" + path + "；" + ex.Message);
                }
            }
            Log("已写入 Codex 中文语言偏好文件：" + count + " 个。");
        }

        private Dictionary<string, object> GetOrCreateDict(Dictionary<string, object> root, string key)
        {
            if (root.ContainsKey(key) && root[key] is Dictionary<string, object>)
                return (Dictionary<string, object>)root[key];
            var dict = new Dictionary<string, object>();
            root[key] = dict;
            return dict;
        }

        private List<string> GetPreferencePaths()
        {
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var result = new List<string>();
            string packages = Path.Combine(local, "Packages");
            if (Directory.Exists(packages))
            {
                foreach (string dir in Directory.GetDirectories(packages, "OpenAI.Codex_*"))
                {
                    string baseDir = Path.Combine(dir, "LocalCache", "Roaming", "Codex");
                    result.Add(Path.Combine(baseDir, "Preferences"));
                    result.Add(Path.Combine(baseDir, "Partitions", "codex-browser-app", "Preferences"));
                    result.Add(Path.Combine(baseDir, "web", "Codex", "Default", "Preferences"));
                }
            }
            result.Add(Path.Combine(local, "OpenAI", "Codex", "Preferences"));
            return result;
        }

        private void ApplyHotkeyAssistantState()
        {
            string settingsPath = GetHotkeySettingsPath();
            if (!altS.Checked)
            {
                StopHotkeyHelper();
                Log("全局快捷键已关闭。");
                return;
            }

            HotkeySettings settings = GetHotkeySettingsFromUi();
            HotkeySettings.Save(settingsPath, settings);
            StopHotkeyHelper();

            string helperPath = GetHotkeyHelperPath();
            if (!File.Exists(helperPath))
                throw new FileNotFoundException("没有找到快捷键助手。请确认 CodexHotkeyHelper.exe 与设置工具放在同一文件夹。", helperPath);

            Process.Start(helperPath);
            Log("已启用 " + settings.DisplayText + "。设置窗口退出后仍会生效。");
        }

        private void ApplyStartupState()
        {
            string startupDir = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
            string bat = Path.Combine(startupDir, "CodexHotkeyHelper.bat");
            if (startup.Checked && altS.Checked)
            {
                string helper = GetHotkeyHelperPath();
                string content = "@echo off\r\nstart \"\" \"" + helper + "\"\r\n";
                File.WriteAllText(bat, content, Encoding.Default);
                Log("已设置开机自动启动：" + bat);
            }
            else if (File.Exists(bat))
            {
                File.Delete(bat);
                Log("已移除开机自动启动：" + bat);
            }
        }

        private void StopHotkeyHelper()
        {
            foreach (Process process in Process.GetProcessesByName("CodexHotkeyHelper"))
            {
                try
                {
                    process.Kill();
                    process.WaitForExit(2000);
                }
                catch { }
            }
        }

        private void LoadHotkeySettings()
        {
            HotkeySettings settings = HotkeySettings.Load(GetHotkeySettingsPath());
            hotkeyAlt.Checked = settings.UseAlt;
            hotkeyControl.Checked = settings.UseControl;
            hotkeyShift.Checked = settings.UseShift;
            hotkeyWindows.Checked = settings.UseWindows;
            if (hotkeyKey.Items.Contains(settings.Key.ToUpperInvariant()))
                hotkeyKey.SelectedItem = settings.Key.ToUpperInvariant();
            startup.Checked = File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), "CodexHotkeyHelper.bat"));
        }

        private HotkeySettings GetHotkeySettingsFromUi()
        {
            return new HotkeySettings
            {
                UseAlt = hotkeyAlt.Checked,
                UseControl = hotkeyControl.Checked,
                UseShift = hotkeyShift.Checked,
                UseWindows = hotkeyWindows.Checked,
                Key = hotkeyKey.SelectedItem == null ? "S" : hotkeyKey.SelectedItem.ToString()
            };
        }

        private string GetHotkeySettingsPath()
        {
            return Path.Combine(Application.StartupPath, "CodexHotkey.json");
        }

        private string GetHotkeyHelperPath()
        {
            return Path.Combine(Application.StartupPath, "CodexHotkeyHelper.exe");
        }

        private void ToggleCodexWindow()
        {
            IntPtr hwnd = FindCodexWindow();
            if (hwnd == IntPtr.Zero)
            {
                LaunchCodex();
                Log("未找到 Codex 窗口，已尝试启动 Codex。");
                return;
            }

            if (CodexWindowTarget.ShouldHide(IsWindowVisible(hwnd)))
            {
                ShowWindow(hwnd, SwHide);
                Log("Codex 已隐藏。");
            }
            else
            {
                ShowWindow(hwnd, SwShow);
                ShowWindow(hwnd, SwRestore);
                SetForegroundWindow(hwnd);
                Log("Codex 已显示。");
            }
        }

        private IntPtr FindCodexWindow()
        {
            IntPtr found = IntPtr.Zero;
            EnumWindows(delegate(IntPtr hWnd, IntPtr lParam)
            {
                uint pid;
                GetWindowThreadProcessId(hWnd, out pid);
                if (pid == 0) return true;
                try
                {
                    var p = Process.GetProcessById((int)pid);
                    string name = p.ProcessName ?? "";
                    if (CodexWindowTarget.IsSupportedProcessName(name))
                    {
                        found = hWnd;
                        return false;
                    }
                }
                catch { }
                return true;
            }, IntPtr.Zero);
            return found;
        }

        private void LaunchCodex()
        {
            try
            {
                Process.Start("explorer.exe", "shell:AppsFolder\\OpenAI.Codex_2p2nqsd0c76g0!App");
            }
            catch
            {
                try { Process.Start("codex"); } catch { }
            }
        }

        private string SetTomlString(string text, string key, string value)
        {
            string line = key + " = \"" + value + "\"";
            string pattern = "(?m)^" + Regex.Escape(key) + "\\s*=\\s*\"[^\"]*\"\\s*$";
            if (Regex.IsMatch(text, pattern))
                return Regex.Replace(text, pattern, line);
            if (string.IsNullOrWhiteSpace(text))
                return line + Environment.NewLine;
            return line + Environment.NewLine + text.TrimStart();
        }

        private string GetCodexHome()
        {
            string home = Environment.GetEnvironmentVariable("CODEX_HOME");
            if (!string.IsNullOrWhiteSpace(home)) return home;
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".codex");
        }

        private void BackupFile(string path)
        {
            if (!File.Exists(path)) return;
            string backup = path + ".bak-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
            File.Copy(path, backup, true);
        }

        private void Log(string message)
        {
            logBox.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] " + message + Environment.NewLine);
        }
    }

    internal sealed class ReportRunResult
    {
        internal ReportRunResult(string outputPath, int exitCode, string output, string error)
        {
            OutputPath = outputPath;
            ExitCode = exitCode;
            Output = output ?? "";
            Error = error ?? "";
        }

        internal string OutputPath { get; private set; }
        internal int ExitCode { get; private set; }
        internal string Output { get; private set; }
        internal string Error { get; private set; }
    }

    internal sealed class HotkeySettings
    {
        public bool UseAlt { get; set; }
        public bool UseControl { get; set; }
        public bool UseShift { get; set; }
        public bool UseWindows { get; set; }
        public string Key { get; set; }

        public HotkeySettings()
        {
            UseAlt = true;
            Key = "S";
        }

        internal int ModifierFlags
        {
            get
            {
                int flags = 0;
                if (UseAlt) flags |= 0x0001;
                if (UseControl) flags |= 0x0002;
                if (UseShift) flags |= 0x0004;
                if (UseWindows) flags |= 0x0008;
                return flags;
            }
        }

        internal string DisplayText
        {
            get
            {
                var parts = new List<string>();
                if (UseControl) parts.Add("Ctrl");
                if (UseAlt) parts.Add("Alt");
                if (UseShift) parts.Add("Shift");
                if (UseWindows) parts.Add("Win");
                parts.Add(string.IsNullOrWhiteSpace(Key) ? "S" : Key.ToUpperInvariant());
                return string.Join("+", parts.ToArray());
            }
        }

        internal static HotkeySettings Load(string path)
        {
            try
            {
                if (!File.Exists(path)) return new HotkeySettings();
                HotkeySettings result = new JavaScriptSerializer().Deserialize<HotkeySettings>(File.ReadAllText(path, Encoding.UTF8));
                if (result == null || result.ModifierFlags == 0 || string.IsNullOrWhiteSpace(result.Key)) return new HotkeySettings();
                return result;
            }
            catch
            {
                return new HotkeySettings();
            }
        }

        internal static void Save(string path, HotkeySettings settings)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            string json = new JavaScriptSerializer().Serialize(settings);
            File.WriteAllText(path, json, new UTF8Encoding(false));
        }
    }

    internal static class CodexWindowTarget
    {
        internal static bool IsSupportedProcessName(string processName)
        {
            return string.Equals(processName, "codex", StringComparison.OrdinalIgnoreCase)
                || string.Equals(processName, "ChatGPT", StringComparison.OrdinalIgnoreCase);
        }

        internal static bool ShouldHide(bool isVisible)
        {
            return isVisible;
        }

        internal static int WindowPriority(bool isVisible, string title)
        {
            if (isVisible) return 2;
            return string.IsNullOrWhiteSpace(title) ? 0 : 1;
        }
    }

    internal sealed class ThreadNamingRecord
    {
        public string Fingerprint { get; set; }
        public long LastRenamedAtMs { get; set; }
        public string VisibleTitle { get; set; }
    }

    internal sealed class ThreadNamingState
    {
        public Dictionary<string, ThreadNamingRecord> Entries { get; set; }

        public ThreadNamingState()
        {
            Entries = new Dictionary<string, ThreadNamingRecord>();
        }
    }

    internal static class ThreadNamingPolicy
    {
        internal const long MinuteMs = 60000;
        internal const long DayMs = 86400000;

        internal static bool ShouldProcess(string threadId, string fingerprint, long updatedAtMs, long nowMs, ThreadNamingState state)
        {
            if (nowMs - updatedAtMs > 3 * DayMs) return false;
            ThreadNamingRecord record;
            if (!state.Entries.TryGetValue(threadId, out record)) return true;
            if (string.Equals(record.Fingerprint, fingerprint, StringComparison.Ordinal)) return false;
            return nowMs - record.LastRenamedAtMs >= 30 * MinuteMs;
        }
    }

    internal sealed class ThreadNamingResult
    {
        internal int Renamed { get; set; }
        internal int Unchanged { get; set; }
        internal int SkippedByCooldown { get; set; }
        internal int SkippedAsStale { get; set; }
        internal string ErrorMessage { get; set; }
        internal List<ThreadRenameAction> Actions { get; private set; }
        internal ThreadNamingState State { get; set; }
        internal string StatePath { get; set; }

        internal ThreadNamingResult()
        {
            Actions = new List<ThreadRenameAction>();
        }

        internal string ToDisplayText()
        {
            if (!string.IsNullOrWhiteSpace(ErrorMessage) && Renamed == 0)
                return "没有更新，请查看提示。";
            if (Renamed == 0)
                return "没有需要更新的近期线程。";
            return "已更新 " + Renamed + " 个近期线程名称。";
        }

        internal string ToLogText()
        {
            return "线程命名完成：更新 " + Renamed + "，内容未变 " + Unchanged + "，30 分钟内跳过 " + SkippedByCooldown + "，超过 3 天跳过 " + SkippedAsStale + "。";
        }
    }

    internal sealed class ThreadNamingCandidate
    {
        internal string Id { get; set; }
        internal string Path { get; set; }
        internal string Fingerprint { get; set; }
        internal string ExistingName { get; set; }
        internal long UpdatedAtMs { get; set; }
        internal string RecentText { get; set; }
        internal bool HasFeishuCapability { get; set; }
        internal string ModelPrefix { get; set; }
    }

    internal sealed class ThreadRenameAction
    {
        internal string ThreadId { get; set; }
        internal string CurrentTitle { get; set; }
        internal string NewTitle { get; set; }
        internal string Fingerprint { get; set; }
    }

    internal sealed class ThreadNamingService
    {
        private const int MaxCandidatesPerRun = 12;
        private readonly string applicationDirectory;

        internal ThreadNamingService(string applicationDirectory)
        {
            this.applicationDirectory = applicationDirectory;
        }

        internal ThreadNamingResult Run()
        {
            var result = new ThreadNamingResult();
            string statePath = GetStatePath();
            ThreadNamingState state = ThreadNamingStateStore.Load(statePath);
            result.State = state;
            result.StatePath = statePath;
            long nowMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            var candidates = new List<ThreadNamingCandidate>();

            using (var server = new CodexAppServerClient())
            {
                foreach (Dictionary<string, object> thread in server.ListRecentThreads())
                {
                    string id = ThreadValue.String(thread, "id");
                    long updatedAtMs = ThreadValue.Long(thread, "updatedAt") * 1000;
                    string fingerprint = updatedAtMs + "|" + ThreadValue.String(thread, "preview");
                    if (nowMs - updatedAtMs > 3 * ThreadNamingPolicy.DayMs)
                    {
                        result.SkippedAsStale++;
                        break;
                    }

                    ThreadNamingRecord previous;
                    bool isKnown = state.Entries.TryGetValue(id, out previous);
                    if (!ThreadNamingPolicy.ShouldProcess(id, fingerprint, updatedAtMs, nowMs, state))
                    {
                        if (isKnown && string.Equals(previous.Fingerprint, fingerprint, StringComparison.Ordinal))
                            result.Unchanged++;
                        else
                            result.SkippedByCooldown++;
                        continue;
                    }

                    if (candidates.Count >= MaxCandidatesPerRun) break;
                    Dictionary<string, object> fullThread = server.ReadThread(id);
                    string serialized = new JavaScriptSerializer().Serialize(fullThread);
                    var candidate = new ThreadNamingCandidate();
                    candidate.Id = id;
                    candidate.Path = ThreadValue.String(thread, "path");
                    candidate.ExistingName = ThreadValue.String(thread, "name");
                    candidate.Fingerprint = fingerprint;
                    candidate.UpdatedAtMs = updatedAtMs;
                    candidate.RecentText = ThreadContentExtractor.GetRecentUserText(fullThread);
                    candidate.HasFeishuCapability = ThreadContentExtractor.HasFeishuCapability(serialized);
                    candidate.ModelPrefix = ThreadSessionMetadata.GetModelPrefix(candidate.Path);
                    if (string.IsNullOrWhiteSpace(candidate.RecentText))
                        candidate.RecentText = ThreadValue.String(thread, "preview");
                    candidates.Add(candidate);
                }

                if (candidates.Count == 0) return result;

                Dictionary<string, string> titles;
                try
                {
                    titles = ThreadTitleGenerator.Generate(candidates, applicationDirectory);
                }
                catch (Exception ex)
                {
                    result.ErrorMessage = "未能生成新标题：" + ex.Message;
                    return result;
                }

                foreach (ThreadNamingCandidate candidate in candidates)
                {
                    string title;
                    if (!titles.TryGetValue(candidate.Id, out title) || string.IsNullOrWhiteSpace(title))
                        continue;
                    string fullName = (candidate.ModelPrefix ?? "") + (candidate.HasFeishuCapability ? "[飞书]" : "") + title;
                    ThreadNamingRecord priorRecord;
                    state.Entries.TryGetValue(candidate.Id, out priorRecord);
                    if (string.Equals(candidate.ExistingName, fullName, StringComparison.Ordinal))
                    {
                        state.Entries[candidate.Id] = new ThreadNamingRecord
                        {
                            Fingerprint = candidate.Fingerprint,
                            LastRenamedAtMs = nowMs,
                            VisibleTitle = fullName
                        };
                    }
                    else
                    {
                        result.Actions.Add(new ThreadRenameAction
                        {
                            ThreadId = candidate.Id,
                            CurrentTitle = string.IsNullOrWhiteSpace(candidate.ExistingName) && priorRecord != null
                                ? priorRecord.VisibleTitle
                                : candidate.ExistingName,
                            NewTitle = fullName,
                            Fingerprint = candidate.Fingerprint
                        });
                    }
                }
            }

            return result;
        }

        private string GetStatePath()
        {
            return Path.Combine(applicationDirectory, "CodexThreadNamingState.json");
        }
    }

    internal static class ThreadNamingStateStore
    {
        internal static ThreadNamingState Load(string path)
        {
            try
            {
                if (!File.Exists(path)) return new ThreadNamingState();
                ThreadNamingState state = new JavaScriptSerializer().Deserialize<ThreadNamingState>(File.ReadAllText(path, Encoding.UTF8));
                if (state == null || state.Entries == null) return new ThreadNamingState();
                return state;
            }
            catch
            {
                return new ThreadNamingState();
            }
        }

        internal static void Save(string path, ThreadNamingState state)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            string json = new JavaScriptSerializer().Serialize(state);
            File.WriteAllText(path, json, new UTF8Encoding(false));
        }
    }

    internal sealed class CodexAppServerClient : IDisposable
    {
        private readonly JavaScriptSerializer serializer = new JavaScriptSerializer();
        private readonly Process process;
        private int requestId;

        internal CodexAppServerClient()
        {
            string executable = FindCodexExecutable();
            if (string.IsNullOrWhiteSpace(executable))
                throw new FileNotFoundException("没有找到 Codex 命令行组件，无法读取线程。请重新安装或更新 Codex 后再试。");

            var info = new ProcessStartInfo();
            info.FileName = executable;
            info.Arguments = "app-server --stdio";
            info.UseShellExecute = false;
            info.RedirectStandardInput = true;
            info.RedirectStandardOutput = true;
            info.CreateNoWindow = true;
            process = Process.Start(info);
            requestId = 1;
            Call("initialize", new Dictionary<string, object>
            {
                { "clientInfo", new Dictionary<string, object> { { "name", "codex-habit-tool" }, { "version", "1.0" } } }
            });
        }

        internal List<Dictionary<string, object>> ListRecentThreads()
        {
            var result = new List<Dictionary<string, object>>();
            object cursor = null;
            for (int page = 0; page < 10; page++)
            {
                var parameters = new Dictionary<string, object>
                {
                    { "limit", 100 },
                    { "archived", false },
                    { "sortKey", "updated_at" },
                    { "sortDirection", "desc" }
                };
                if (cursor != null) parameters.Add("cursor", cursor);
                Dictionary<string, object> pageResult = Call("thread/list", parameters);
                ArrayList data = ThreadValue.Array(pageResult, "data");
                if (data == null || data.Count == 0) break;
                bool reachedStale = false;
                foreach (object item in data)
                {
                    var thread = item as Dictionary<string, object>;
                    if (thread == null) continue;
                    result.Add(thread);
                    long updated = ThreadValue.Long(thread, "updatedAt") * 1000;
                    if (DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - updated > 3 * ThreadNamingPolicy.DayMs)
                    {
                        reachedStale = true;
                        break;
                    }
                }
                if (reachedStale) break;
                cursor = ThreadValue.Object(pageResult, "nextCursor");
                if (cursor == null) break;
            }
            return result;
        }

        internal Dictionary<string, object> ReadThread(string threadId)
        {
            Dictionary<string, object> response = Call("thread/read", new Dictionary<string, object>
            {
                { "threadId", threadId }, { "includeTurns", true }
            });
            return ThreadValue.Dictionary(response, "thread") ?? new Dictionary<string, object>();
        }

        internal void SetThreadName(string threadId, string name)
        {
            Call("thread/name/set", new Dictionary<string, object>
            {
                { "threadId", threadId }, { "name", name }
            });
        }

        private Dictionary<string, object> Call(string method, Dictionary<string, object> parameters)
        {
            int id = requestId++;
            string request = ThreadJsonTransport.ToAsciiJson(serializer.Serialize(new Dictionary<string, object>
            {
                { "id", id }, { "method", method }, { "params", parameters }
            }));
            process.StandardInput.WriteLine(request);
            process.StandardInput.Flush();
            while (true)
            {
                string line = process.StandardOutput.ReadLine();
                if (line == null) throw new InvalidOperationException("Codex 线程服务意外退出。");
                Dictionary<string, object> response;
                try { response = serializer.Deserialize<Dictionary<string, object>>(line); }
                catch { continue; }
                object responseId;
                if (!response.TryGetValue("id", out responseId) || Convert.ToInt32(responseId) != id) continue;
                object error;
                if (response.TryGetValue("error", out error) && error != null)
                    throw new InvalidOperationException("Codex 线程服务返回错误：" + serializer.Serialize(error));
                return ThreadValue.Dictionary(response, "result") ?? new Dictionary<string, object>();
            }
        }

        public void Dispose()
        {
            if (process == null) return;
            try
            {
                if (!process.HasExited) process.Kill();
            }
            catch { }
            process.Dispose();
        }

        private static string FindCodexExecutable()
        {
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string root = Path.Combine(local, "OpenAI", "Codex", "bin");
            if (!Directory.Exists(root)) return null;
            string[] candidates = Directory.GetFiles(root, "codex.exe", SearchOption.AllDirectories);
            if (candidates.Length == 0) return null;
            string newest = candidates[0];
            foreach (string candidate in candidates)
            {
                if (File.GetLastWriteTimeUtc(candidate) > File.GetLastWriteTimeUtc(newest)) newest = candidate;
            }
            return newest;
        }
    }

    internal static class CodexSidebarRefreshPolicy
    {
        internal static bool ShouldRefresh(int renamedCount)
        {
            return renamedCount > 0;
        }
    }

    internal static class ThreadNativeRenamer
    {
        [DllImport("user32.dll")]
        private static extern bool SetCursorPos(int x, int y);

        [DllImport("user32.dll")]
        private static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extraInfo);

        private const uint MouseLeftDown = 0x0002;
        private const uint MouseLeftUp = 0x0004;

        internal static bool TryRename(string currentTitle, string newTitle)
        {
            if (string.IsNullOrWhiteSpace(currentTitle) || string.IsNullOrWhiteSpace(newTitle)) return false;
            try
            {
                Process desktop = null;
                foreach (Process process in Process.GetProcessesByName("ChatGPT"))
                {
                    if (process.MainWindowHandle != IntPtr.Zero)
                    {
                        desktop = process;
                        break;
                    }
                }
                if (desktop == null) return false;

                AutomationElement window = AutomationElement.FromHandle(desktop.MainWindowHandle);
                AutomationElement item = FindThreadItem(window, currentTitle);
                if (item == null) return false;
                AutomationElement row = item.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button));
                if (row == null) return false;
                ((InvokePattern)row.GetCurrentPattern(InvokePattern.Pattern)).Invoke();
                System.Threading.Thread.Sleep(250);

                window = AutomationElement.FromHandle(desktop.MainWindowHandle);
                AutomationElement operations = window.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, "任务操作"));
                if (operations == null) return false;
                System.Windows.Rect operationBox = operations.Current.BoundingRectangle;
                if (operationBox.IsEmpty) return false;
                Click(operationBox);
                System.Threading.Thread.Sleep(120);

                AutomationElement renameMenu = AutomationElement.RootElement.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, "重命名任务 Ctrl+Alt+R"));
                if (renameMenu == null) return false;
                ((InvokePattern)renameMenu.GetCurrentPattern(InvokePattern.Pattern)).Invoke();
                System.Threading.Thread.Sleep(120);

                window = AutomationElement.FromHandle(desktop.MainWindowHandle);
                var editCondition = new AndCondition(
                    new PropertyCondition(AutomationElement.NameProperty, "任务标题"),
                    new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit));
                AutomationElement edit = window.FindFirst(TreeScope.Descendants, editCondition);
                if (edit == null) return false;
                ((ValuePattern)edit.GetCurrentPattern(ValuePattern.Pattern)).SetValue(newTitle);
                edit.SetFocus();
                SendKeys.SendWait("{ENTER}");
                System.Threading.Thread.Sleep(180);
                return FindThreadItem(AutomationElement.FromHandle(desktop.MainWindowHandle), newTitle) != null;
            }
            catch
            {
                return false;
            }
        }

        private static AutomationElement FindThreadItem(AutomationElement window, string title)
        {
            return window.FindFirst(TreeScope.Descendants, new AndCondition(
                new PropertyCondition(AutomationElement.NameProperty, title),
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem)));
        }

        private static void Click(System.Windows.Rect box)
        {
            int x = (int)(box.X + box.Width / 2);
            int y = (int)(box.Y + box.Height / 2);
            SetCursorPos(x, y);
            mouse_event(MouseLeftDown, 0, 0, 0, UIntPtr.Zero);
            mouse_event(MouseLeftUp, 0, 0, 0, UIntPtr.Zero);
        }
    }

    internal static class ThreadJsonTransport
    {
        internal static readonly Encoding Utf8NoBom = new UTF8Encoding(false);

        internal static string ToAsciiJson(string json)
        {
            if (string.IsNullOrEmpty(json)) return json;
            var builder = new StringBuilder(json.Length);
            foreach (char value in json)
            {
                if (value <= 0x7f) builder.Append(value);
                else builder.Append("\\u").Append(((int)value).ToString("x4"));
            }
            return builder.ToString();
        }
    }

    internal static class ThreadValue
    {
        internal static string String(Dictionary<string, object> value, string key)
        {
            object raw;
            return value != null && value.TryGetValue(key, out raw) && raw != null ? Convert.ToString(raw) : "";
        }

        internal static long Long(Dictionary<string, object> value, string key)
        {
            object raw;
            return value != null && value.TryGetValue(key, out raw) && raw != null ? Convert.ToInt64(raw) : 0;
        }

        internal static object Object(Dictionary<string, object> value, string key)
        {
            object raw;
            return value != null && value.TryGetValue(key, out raw) ? raw : null;
        }

        internal static Dictionary<string, object> Dictionary(Dictionary<string, object> value, string key)
        {
            return Object(value, key) as Dictionary<string, object>;
        }

        internal static ArrayList Array(Dictionary<string, object> value, string key)
        {
            return Object(value, key) as ArrayList;
        }
    }

    internal static class ThreadContentExtractor
    {
        internal static string GetRecentUserText(Dictionary<string, object> thread)
        {
            var messages = new List<string>();
            ArrayList turns = ThreadValue.Array(thread, "turns");
            if (turns == null) return "";
            foreach (object rawTurn in turns)
            {
                var turn = rawTurn as Dictionary<string, object>;
                ArrayList items = turn == null ? null : ThreadValue.Array(turn, "items");
                if (items == null) continue;
                foreach (object rawItem in items)
                {
                    var item = rawItem as Dictionary<string, object>;
                    if (item == null || !string.Equals(ThreadValue.String(item, "type"), "userMessage", StringComparison.Ordinal)) continue;
                    ArrayList content = ThreadValue.Array(item, "content");
                    if (content == null) continue;
                    var parts = new List<string>();
                    foreach (object rawPart in content)
                    {
                        var part = rawPart as Dictionary<string, object>;
                        string text = part == null ? "" : ThreadValue.String(part, "text");
                        if (!string.IsNullOrWhiteSpace(text)) parts.Add(text.Trim());
                    }
                    if (parts.Count > 0) messages.Add(string.Join(" ", parts.ToArray()));
                }
            }
            int start = Math.Max(0, messages.Count - 3);
            string combined = string.Join("\n", messages.GetRange(start, messages.Count - start).ToArray());
            return combined.Length > 1200 ? combined.Substring(combined.Length - 1200) : combined;
        }

        internal static bool HasFeishuCapability(string serializedThread)
        {
            string text = (serializedThread ?? "").ToLowerInvariant();
            bool hasFeishu = text.IndexOf("feishu", StringComparison.Ordinal) >= 0
                || text.IndexOf("lark", StringComparison.Ordinal) >= 0
                || text.IndexOf("飞书", StringComparison.Ordinal) >= 0;
            bool hasCapability = text.IndexOf("mcp", StringComparison.Ordinal) >= 0
                || text.IndexOf(" cli", StringComparison.Ordinal) >= 0
                || text.IndexOf("机器人", StringComparison.Ordinal) >= 0
                || text.IndexOf("bot", StringComparison.Ordinal) >= 0
                || text.IndexOf("权限", StringComparison.Ordinal) >= 0
                || text.IndexOf("permission", StringComparison.Ordinal) >= 0
                || text.IndexOf("send_message", StringComparison.Ordinal) >= 0;
            return hasFeishu && hasCapability;
        }
    }

    internal static class ThreadSessionMetadata
    {
        internal static string GetModelPrefix(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return "";
            string model = "";
            string effort = "";
            try
            {
                using (var reader = new StreamReader(path, Encoding.UTF8, true))
                {
                    for (int i = 0; i < 400; i++)
                    {
                        string line = reader.ReadLine();
                        if (line == null) break;
                        Match modelMatch = Regex.Match(line, "\\\"model\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
                        if (modelMatch.Success && modelMatch.Groups[1].Value.IndexOf("gpt-", StringComparison.OrdinalIgnoreCase) >= 0)
                            model = modelMatch.Groups[1].Value;
                        Match effortMatch = Regex.Match(line, "\\\"reasoning_effort\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
                        if (effortMatch.Success) effort = effortMatch.Groups[1].Value;
                    }
                }
            }
            catch { return ""; }

            Match version = Regex.Match(model, "gpt-(\\d+(?:\\.\\d+)?)", RegexOptions.IgnoreCase);
            if (!version.Success) return "";
            string suffix = "";
            if (string.Equals(effort, "high", StringComparison.OrdinalIgnoreCase)) suffix = "高";
            else if (string.Equals(effort, "medium", StringComparison.OrdinalIgnoreCase)) suffix = "中";
            else if (string.Equals(effort, "low", StringComparison.OrdinalIgnoreCase) || string.Equals(effort, "minimal", StringComparison.OrdinalIgnoreCase)) suffix = "低";
            else if (string.Equals(effort, "xhigh", StringComparison.OrdinalIgnoreCase)) suffix = "极";
            return "[" + version.Groups[1].Value + suffix + "]";
        }
    }

    internal static class ThreadTitleGenerator
    {
        internal const int MaxWaitMilliseconds = 300000;

        internal static Dictionary<string, string> Generate(List<ThreadNamingCandidate> candidates, string applicationDirectory)
        {
            string executable = FindCodexExecutable();
            if (string.IsNullOrWhiteSpace(executable)) throw new FileNotFoundException("没有找到 Codex 命令行组件。");
            string outputPath = Path.Combine(Path.GetTempPath(), "codex-thread-titles-" + Guid.NewGuid().ToString("N") + ".json");
            string prompt = BuildPrompt(candidates);
            try
            {
                var info = new ProcessStartInfo();
                info.FileName = executable;
                string workingDirectory = applicationDirectory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                info.Arguments = "exec --ephemeral --skip-git-repo-check -s read-only -C \"" + workingDirectory + "\" --output-last-message \"" + outputPath + "\" \"" + prompt.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";
                info.UseShellExecute = false;
                info.CreateNoWindow = true;
                using (Process process = Process.Start(info))
                {
                    if (!process.WaitForExit(MaxWaitMilliseconds))
                    {
                        try { process.Kill(); } catch { }
                        throw new TimeoutException("生成标题超过五分钟，请检查网络后再试。");
                    }
                    if (process.ExitCode != 0)
                        throw new InvalidOperationException("Codex 生成标题未成功完成。");
                }
                if (!File.Exists(outputPath)) throw new InvalidOperationException("没有收到标题生成结果。");
                return Parse(File.ReadAllText(outputPath, Encoding.UTF8));
            }
            finally
            {
                try { if (File.Exists(outputPath)) File.Delete(outputPath); } catch { }
            }
        }

        internal static string BuildPrompt(List<ThreadNamingCandidate> candidates)
        {
            var builder = new StringBuilder();
            builder.Append("你是中文线程标题编辑。根据每条对话最近的用户内容，给每条取一个自然、口语、准确的中文标题。标题正文最多7个汉字，不要模型前缀、方括号、标点、序号或解释。只输出 JSON 数组，格式 [{\"id\":\"线程ID\",\"title\":\"七字内标题\"}]。\n\n");
            foreach (ThreadNamingCandidate candidate in candidates)
            {
                builder.Append("ID: ").Append(candidate.Id).Append("\n内容: ").Append(candidate.RecentText.Replace("\r", " ").Replace("\n", " ")).Append("\n\n");
            }
            return builder.ToString();
        }

        internal static Dictionary<string, string> Parse(string raw)
        {
            int start = raw.IndexOf('[');
            int end = raw.LastIndexOf(']');
            if (start < 0 || end <= start) throw new InvalidOperationException("标题生成结果不是有效 JSON。");
            ArrayList values = new JavaScriptSerializer().Deserialize<ArrayList>(raw.Substring(start, end - start + 1));
            var result = new Dictionary<string, string>();
            foreach (object item in values)
            {
                var value = item as Dictionary<string, object>;
                if (value == null) continue;
                string id = ThreadValue.String(value, "id");
                string title = CleanTitle(ThreadValue.String(value, "title"));
                if (!string.IsNullOrWhiteSpace(id) && !string.IsNullOrWhiteSpace(title)) result[id] = title;
            }
            if (result.Count == 0) throw new InvalidOperationException("标题生成结果为空。");
            return result;
        }

        internal static string CleanTitle(string title)
        {
            string cleaned = Regex.Replace(title ?? "", "[\\s\\p{P}\\p{S}]", "");
            return cleaned.Length > 7 ? cleaned.Substring(0, 7) : cleaned;
        }

        private static string FindCodexExecutable()
        {
            string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "OpenAI", "Codex", "bin");
            if (!Directory.Exists(root)) return null;
            string[] candidates = Directory.GetFiles(root, "codex.exe", SearchOption.AllDirectories);
            if (candidates.Length == 0) return null;
            string newest = candidates[0];
            foreach (string candidate in candidates)
            {
                if (File.GetLastWriteTimeUtc(candidate) > File.GetLastWriteTimeUtc(newest)) newest = candidate;
            }
            return newest;
        }
    }

    internal static class ReportIntegration
    {
        private const string ScannerFolderName = "Codex对话评分工具";
        private const string ScannerFileName = "Codex对话评分工具.exe";

        internal static string GetReportDirectory(string applicationDirectory)
        {
            return Path.Combine(applicationDirectory, "reports");
        }

        internal static string GetScannerPath(string applicationDirectory)
        {
            return Path.Combine(applicationDirectory, ScannerFolderName, ScannerFileName);
        }

        internal static string GetNextReportPath(string applicationDirectory)
        {
            string reportDirectory = GetReportDirectory(applicationDirectory);
            Directory.CreateDirectory(reportDirectory);
            string name = "codex_conversation_review_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";
            return Path.Combine(reportDirectory, name);
        }

        internal static string BuildArguments(string outputPath)
        {
            return "--output \"" + outputPath.Replace("\"", "\\\"") + "\"";
        }

        internal static string FindLatestReport(string reportDirectory)
        {
            if (!Directory.Exists(reportDirectory)) return null;
            string latestPath = null;
            DateTime latestTime = DateTime.MinValue;
            foreach (string path in Directory.GetFiles(reportDirectory, "codex_conversation_review_*.xlsx"))
            {
                DateTime time = File.GetLastWriteTimeUtc(path);
                if (time > latestTime)
                {
                    latestTime = time;
                    latestPath = path;
                }
            }
            return latestPath;
        }
    }
}
