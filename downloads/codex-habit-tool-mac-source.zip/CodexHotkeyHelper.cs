using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace CodexHabitTool
{
    internal static class CodexHotkeyHelperProgram
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new CodexHotkeyHelperForm());
        }
    }

    internal sealed class CodexHotkeyHelperForm : Form
    {
        private const int HotkeyId = 0x6302;
        private const int WmHotkey = 0x0312;
        private const int SwHide = 0;
        private const int SwShow = 5;
        private const int SwRestore = 9;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);

        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc enumProc, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        private bool registered;
        private HotkeySettings settings;
        private IntPtr lastTargetWindow;

        internal CodexHotkeyHelperForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            Opacity = 0;
            Width = 1;
            Height = 1;
            StartPosition = FormStartPosition.Manual;
            Location = new System.Drawing.Point(-10000, -10000);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            settings = HotkeySettings.Load(GetSettingsPath());
            Keys key = ParseKey(settings.Key);
            registered = RegisterHotKey(Handle, HotkeyId, settings.ModifierFlags, (int)key);
            WriteStatus(registered ? "ready: " + settings.DisplayText + " | handle: " + Handle : "error: " + Marshal.GetLastWin32Error());
        }

        protected override void OnHandleDestroyed(EventArgs e)
        {
            if (registered) UnregisterHotKey(Handle, HotkeyId);
            base.OnHandleDestroyed(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WmHotkey && m.WParam.ToInt32() == HotkeyId)
            {
                WriteStatus("triggered: " + settings.DisplayText);
                ToggleCodexWindow();
            }
            base.WndProc(ref m);
        }

        private static Keys ParseKey(string key)
        {
            try { return (Keys)Enum.Parse(typeof(Keys), key, true); }
            catch { return Keys.S; }
        }

        private void ToggleCodexWindow()
        {
            if (lastTargetWindow != IntPtr.Zero && !IsWindowVisible(lastTargetWindow))
            {
                ShowWindow(lastTargetWindow, SwShow);
                ShowWindow(lastTargetWindow, SwRestore);
                SetForegroundWindow(lastTargetWindow);
                return;
            }

            IntPtr hwnd = FindCodexWindow();
            if (hwnd != IntPtr.Zero && IsWindowVisible(hwnd))
            {
                lastTargetWindow = hwnd;
                ShowWindow(hwnd, SwHide);
                return;
            }

            if (hwnd == IntPtr.Zero)
            {
                LaunchCodex();
                return;
            }

            ShowWindow(hwnd, SwShow);
            ShowWindow(hwnd, SwRestore);
            SetForegroundWindow(hwnd);
        }

        private IntPtr FindCodexWindow()
        {
            foreach (Process process in Process.GetProcesses())
            {
                try
                {
                    if (CodexWindowTarget.IsSupportedProcessName(process.ProcessName) && process.MainWindowHandle != IntPtr.Zero)
                        return process.MainWindowHandle;
                }
                catch { }
            }

            IntPtr found = IntPtr.Zero;
            int foundPriority = 0;
            EnumWindows(delegate(IntPtr hWnd, IntPtr lParam)
            {
                uint processId;
                GetWindowThreadProcessId(hWnd, out processId);
                if (processId == 0) return true;
                try
                {
                    Process process = Process.GetProcessById((int)processId);
                    if (CodexWindowTarget.IsSupportedProcessName(process.ProcessName))
                    {
                        var title = new StringBuilder(256);
                        GetWindowText(hWnd, title, title.Capacity);
                        int priority = CodexWindowTarget.WindowPriority(IsWindowVisible(hWnd), title.ToString());
                        if (priority > foundPriority)
                        {
                            found = hWnd;
                            foundPriority = priority;
                            if (priority == 2) return false;
                        }
                    }
                }
                catch { }
                return true;
            }, IntPtr.Zero);
            return found;
        }

        private static void LaunchCodex()
        {
            try
            {
                Process.Start("explorer.exe", "shell:AppsFolder\\OpenAI.Codex_2p2nqsd0c76g0!App");
            }
            catch { }
        }

        private static string GetSettingsPath()
        {
            return Path.Combine(Application.StartupPath, "CodexHotkey.json");
        }

        private static void WriteStatus(string value)
        {
            try
            {
                File.WriteAllText(Path.Combine(Application.StartupPath, "CodexHotkey.status.txt"), value);
            }
            catch { }
        }
    }
}
