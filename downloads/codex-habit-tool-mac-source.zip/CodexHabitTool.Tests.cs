using System;
using System.IO;
using System.Windows.Forms;

namespace CodexHabitTool.Tests
{
    internal static class Program
    {
        private static int passed;

        [STAThread]
        private static void Main()
        {
            string root = Path.Combine(Path.GetTempPath(), "CodexHabitToolTest");
            AssertEqual("reports", Path.GetFileName(ReportIntegration.GetReportDirectory(root)), "reports folder");
            AssertContains("--output", ReportIntegration.BuildArguments(Path.Combine(root, "reports", "latest.xlsx")), "output argument");

            string reportDirectory = Path.Combine(root, "reports");
            Directory.CreateDirectory(reportDirectory);
            string older = Path.Combine(reportDirectory, "codex_conversation_review_older.xlsx");
            string newer = Path.Combine(reportDirectory, "codex_conversation_review_newer.xlsx");
            File.WriteAllText(older, "old");
            File.WriteAllText(newer, "new");
            File.SetLastWriteTimeUtc(older, DateTime.UtcNow.AddMinutes(-1));
            File.SetLastWriteTimeUtc(newer, DateTime.UtcNow);
            AssertEqual(newer, ReportIntegration.FindLatestReport(reportDirectory), "latest report");

            string hotkeyPath = Path.Combine(root, "CodexHotkey.json");
            var hotkey = new HotkeySettings();
            hotkey.UseAlt = true;
            hotkey.UseControl = true;
            hotkey.UseShift = false;
            hotkey.UseWindows = false;
            hotkey.Key = "J";
            HotkeySettings.Save(hotkeyPath, hotkey);
            HotkeySettings loaded = HotkeySettings.Load(hotkeyPath);
            AssertEqual("Ctrl+Alt+J", loaded.DisplayText, "custom hotkey display");
            AssertEqual("3", loaded.ModifierFlags.ToString(), "custom hotkey modifier flags");
            AssertTrue(CodexWindowTarget.IsSupportedProcessName("codex"), "standalone Codex process");
            AssertTrue(CodexWindowTarget.IsSupportedProcessName("ChatGPT"), "ChatGPT Codex surface");
            AssertTrue(CodexWindowTarget.ShouldHide(true), "visible window hides");
            AssertTrue(!CodexWindowTarget.ShouldHide(false), "hidden window restores");
            AssertEqual("2", CodexWindowTarget.WindowPriority(true, "ChatGPT").ToString(), "visible titled window priority");
            AssertEqual("2", CodexWindowTarget.WindowPriority(true, "").ToString(), "visible untitled window priority");
            AssertEqual("1", CodexWindowTarget.WindowPriority(false, "ChatGPT").ToString(), "hidden titled window priority");
            AssertEqual("0", CodexWindowTarget.WindowPriority(false, "").ToString(), "untitled window ignored");

            long now = 1000000000;
            var namingState = new ThreadNamingState();
            namingState.Entries["unchanged"] = new ThreadNamingRecord { Fingerprint = "same", LastRenamedAtMs = now - 3600000 };
            namingState.Entries["cooldown"] = new ThreadNamingRecord { Fingerprint = "old", LastRenamedAtMs = now - 10 * 60000 };
            AssertTrue(!ThreadNamingPolicy.ShouldProcess("unchanged", "same", now - 60000, now, namingState), "unchanged thread skipped");
            AssertTrue(!ThreadNamingPolicy.ShouldProcess("cooldown", "new", now - 60000, now, namingState), "recently renamed thread skipped");
            AssertTrue(!ThreadNamingPolicy.ShouldProcess("stale", "new", now - 4 * ThreadNamingPolicy.DayMs, now, namingState), "stale thread skipped");
            AssertTrue(ThreadNamingPolicy.ShouldProcess("new", "new", now - 60000, now, namingState), "new recent thread processed");

            string statePath = Path.Combine(root, "CodexThreadNamingState.json");
            ThreadNamingStateStore.Save(statePath, namingState);
            AssertEqual("same", ThreadNamingStateStore.Load(statePath).Entries["unchanged"].Fingerprint, "naming state persisted");
            AssertEqual("移动验证器标题", ThreadTitleGenerator.CleanTitle("移动验证器！标题过长"), "thread title shortened to seven characters");
            var titleJson = ThreadTitleGenerator.Parse("说明 [ {\"id\":\"one\",\"title\":\"更新快捷键。\"} ]");
            AssertEqual("更新快捷键", titleJson["one"], "thread title JSON parsed");
            AssertTrue(ThreadContentExtractor.HasFeishuCapability("已配置飞书 MCP 发送消息权限"), "feishu capability marked");
            AssertTrue(!ThreadContentExtractor.HasFeishuCapability("只是提到飞书"), "plain feishu mention not marked");
            AssertTrue(ThreadTitleGenerator.MaxWaitMilliseconds >= 300000, "thread title generation allows network fallback time");
            AssertTrue(ThreadTitleGenerator.BuildPrompt(new System.Collections.Generic.List<ThreadNamingCandidate> { new ThreadNamingCandidate { Id = "one", RecentText = "测试" } }).IndexOf("\nID: one\n", StringComparison.Ordinal) >= 0, "thread title prompt uses real line breaks");
            byte[] utf8Title = ThreadJsonTransport.Utf8NoBom.GetBytes("飞书标题");
            AssertEqual("飞书标题", new System.Text.UTF8Encoding(false).GetString(utf8Title), "thread name transport uses UTF-8");
            AssertContains("\\u98de", ThreadJsonTransport.ToAsciiJson("{\"name\":\"飞书标题\"}"), "thread name JSON escapes non-ASCII safely");
            AssertTrue(CodexSidebarRefreshPolicy.ShouldRefresh(1), "refresh requested after renamed threads");
            AssertTrue(!CodexSidebarRefreshPolicy.ShouldRefresh(0), "refresh skipped when no names changed");
            var renameAction = new ThreadRenameAction { ThreadId = "thread", CurrentTitle = "旧标题", NewTitle = "新标题" };
            AssertEqual("新标题", renameAction.NewTitle, "native rename action carries new title");
            var visibleRecord = new ThreadNamingRecord { VisibleTitle = "一键打开Codex" };
            AssertEqual("一键打开Codex", visibleRecord.VisibleTitle, "blank native title keeps visible sidebar title");

            Console.WriteLine(passed + " tests passed");
        }

        private static void AssertEqual(string expected, string actual, string name)
        {
            if (!string.Equals(expected, actual, StringComparison.Ordinal))
                throw new Exception(name + " expected '" + expected + "' but got '" + actual + "'.");
            passed++;
        }

        private static void AssertContains(string expected, string actual, string name)
        {
            if (actual == null || actual.IndexOf(expected, StringComparison.Ordinal) < 0)
                throw new Exception(name + " did not contain '" + expected + "'.");
            passed++;
        }

        private static void AssertTrue(bool condition, string name)
        {
            if (!condition) throw new Exception(name + " was false.");
            passed++;
        }

    }
}
