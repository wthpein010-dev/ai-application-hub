# IceCream Project Memory

## Fixed Constraints

- Unity: 2022.3.62f3c1.
- Target: WeChat mini game plus WebGL preview.
- UI: UGUI, editable prefabs, 750 x 1624 reference resolution, multi-resolution adaptation.
- Preserve existing content and request confirmation before high-risk operations.
- Initial UI uses Unity color blocks. External art replacement begins only after first-pass approval.
- Pinterest source for the later art pass: `https://www.pinterest.com/sss`.
- Asset names may contain at most two underscores.
- Final public delivery includes the WebGL preview, WeChat build archive, complete Unity source archive, and instructional video.
- Website target: `wthpein010-dev/ai-application-hub`, game section.

## Rollback Points

- `c4dc2ee`: original IceCream project baseline.
- `403ffdf`: Unity MCP v10 package integration.
- `f9d993d`: Unity MCP Bridge auto-connect support.
- `f9fefcd`: complete color-block first-pass game flow and MCP Play Mode verification.

## Current Milestone

- Incremental implementation is active on `feature/icecream-full-production`.
- Gameplay validation, ten level configurations, local progress persistence, the editable 750 x 1624 UGUI prefab, and next-level flow are complete.
- Official WeChat mini-game SDK `com.qq.weixin.minigame` is pinned to commit `ed4ad28f433c6b52b5fd3f22a6fa155a0c98c228`.
- Platform bootstrap, pause/resume hooks, storage abstraction, portrait settings, and automated WeChat build validation are complete.
- Unity 2022.3.62f3c1 WebGL Build Support was installed from the official Unity China release package and verified by MD5.
- Release automation now builds a responsive 750:1624 WebGL preview and the official SDK `minigame` project.
- WebGL browser smoke test passed with a 332.5 x 720 canvas (exact 750:1624 ratio) and zero fresh Console warnings/errors.
- WeChat and WebGL output validation passed on 2026-07-12.
- Latest verification: 18 EditMode tests passed on 2026-07-12.
- MCP Play Mode smoke check passed with zero Console warnings/errors on 2026-07-12.
- Unity MCP Scene, Hierarchy, and Console read-only checks passed on 2026-07-12.
