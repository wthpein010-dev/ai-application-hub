# IceCream Full Production Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver a ten-level IceCream WeChat mini game with editable 750 x 1624 UGUI, WebGL preview, public downloads, website integration, and a teaching video.

**Architecture:** Preserve the existing Core and Gameplay systems while adding tested configuration validation, prefab-backed presentation, a platform abstraction, and isolated publishing outputs. Complete and commit each subsystem independently so every milestone remains runnable and reversible.

**Tech Stack:** Unity 2022.3.62f3c1, C#, UGUI, Unity Test Framework, JSON Resources, WeChat Unity conversion tooling, WebGL, Git, GitHub Pages.

## Global Constraints

- Unity version is exactly 2022.3.62f3c1.
- Reference resolution is exactly 750 x 1624.
- UI uses UGUI and editable prefabs.
- First UI pass uses Unity color blocks and basic shapes.
- Existing content is preserved; destructive or unrelated changes require confirmation.
- External art replacement starts only after first-pass approval.
- Asset names contain no more than two underscores.
- Major milestones update `PROJECT_MEMORY.md` and receive a Git commit.
- Final public delivery includes WebGL preview, WeChat build archive, complete Unity source archive, and instructional video.

---

### Task 1: Gameplay Test Foundation and Configuration Validation

**Files:**
- Create: `Assets/ColorCreamFlow/Tests/EditMode/ColorCreamFlow.EditModeTests.asmdef`
- Create: `Assets/ColorCreamFlow/Tests/EditMode/MatchingSystemTests.cs`
- Create: `Assets/ColorCreamFlow/Tests/EditMode/LevelConfigValidationTests.cs`
- Create: `Assets/ColorCreamFlow/Scripts/Gameplay/LevelConfigValidator.cs`
- Modify: `Assets/ColorCreamFlow/Scripts/Gameplay/LevelConfigLoader.cs`

**Interfaces:**
- Produces: `LevelConfigValidator.Validate(LevelConfig config): IReadOnlyList<string>`.
- Produces: `LevelConfigLoader.Load(int levelId): LevelConfig` that rejects invalid data with a descriptive exception.

- [ ] Write edit-mode tests for ordered matching, unordered matching, scoop limits, missing customers, invalid capacities, and impossible production limits.
- [ ] Run the Unity EditMode test assembly and verify the new validation tests fail before implementation.
- [ ] Implement `LevelConfigValidator` with explicit validation messages and call it from `LevelConfigLoader.Load`.
- [ ] Run EditMode tests and expect all tests to pass.
- [ ] Commit with `test: add gameplay configuration validation`.

### Task 2: Ten-Level Progression

**Files:**
- Modify: `Assets/ColorCreamFlow/Resources/Configs/Levels/level_001.json`
- Modify: `Assets/ColorCreamFlow/Resources/Configs/Levels/level_002.json`
- Create: `Assets/ColorCreamFlow/Resources/Configs/Levels/level_003.json` through `level_010.json`
- Create: `Assets/ColorCreamFlow/Tests/EditMode/TenLevelProgressionTests.cs`
- Modify: `Assets/ColorCreamFlow/Scripts/Gameplay/LevelController.cs`

**Interfaces:**
- Consumes: `LevelConfigValidator.Validate`.
- Produces: valid level IDs 1 through 10 and `LevelController.StartLevel(int levelId)` progression.

- [ ] Add a test that loads IDs 1 through 10, validates every configuration, and asserts increasing recipe/customer complexity.
- [ ] Run the test and verify it fails because levels 3 through 10 are missing.
- [ ] Author ten deterministic configurations with sufficient production limits for every required order.
- [ ] Add next-level progression after success while retaining restart behavior.
- [ ] Run the complete EditMode suite and manually play representative levels 1, 5, and 10.
- [ ] Commit with `feat: add ten-level progression` and update `PROJECT_MEMORY.md`.

### Task 3: Persistence and Platform Boundary

**Files:**
- Create: `Assets/ColorCreamFlow/Scripts/Platform/IGameStorage.cs`
- Create: `Assets/ColorCreamFlow/Scripts/Platform/PlayerPrefsGameStorage.cs`
- Create: `Assets/ColorCreamFlow/Scripts/Platform/GameProgress.cs`
- Create: `Assets/ColorCreamFlow/Scripts/Platform/GameProgressService.cs`
- Create: `Assets/ColorCreamFlow/Tests/EditMode/GameProgressServiceTests.cs`
- Modify: `Assets/ColorCreamFlow/Scripts/Gameplay/LevelController.cs`

**Interfaces:**
- Produces: `IGameStorage.GetString(string key, string fallback)` and `SetString(string key, string value)`.
- Produces: `GameProgressService.Load()`, `Save(GameProgress progress)`, and `UnlockAfterSuccess(int completedLevel)`.

- [ ] Write fake-storage tests for first launch, coin persistence, unlock progression, and corrupted JSON fallback.
- [ ] Verify tests fail before the service exists.
- [ ] Implement storage and inject the service into level flow with PlayerPrefs as the default fallback.
- [ ] Run tests and verify progress survives a level restart and editor relaunch.
- [ ] Commit with `feat: persist player progression`.

### Task 4: Editable 750 x 1624 UGUI Prefab Structure

**Files:**
- Create: `Assets/ColorCreamFlow/Prefabs/UI/GameplayCanvas.prefab`
- Create: `Assets/ColorCreamFlow/Prefabs/UI/TopHud.prefab`
- Create: `Assets/ColorCreamFlow/Prefabs/UI/CustomerPanel.prefab`
- Create: `Assets/ColorCreamFlow/Prefabs/UI/ConveyorPanel.prefab`
- Create: `Assets/ColorCreamFlow/Prefabs/UI/MachinePanel.prefab`
- Create: `Assets/ColorCreamFlow/Prefabs/UI/FooterPanel.prefab`
- Create: `Assets/ColorCreamFlow/Prefabs/UI/ResultPopup.prefab`
- Create: `Assets/ColorCreamFlow/Scripts/UI/SafeAreaFitter.cs`
- Modify: `Assets/ColorCreamFlow/Scripts/UI/LevelGameplayView.cs`
- Modify: `Assets/ColorCreamFlow/Scenes/LevelGameplay.unity`

**Interfaces:**
- Produces: serialized `LevelGameplayView` references to prefab-owned regions.
- Produces: `SafeAreaFitter.Apply(Rect safeArea, Vector2Int screenSize)`.

- [ ] Add EditMode tests for safe-area normalization at 750 x 1624, tall phone, short phone, and tablet ratios.
- [ ] Verify current `720 x 1280` runtime-built layout fails the reference-resolution assertion.
- [ ] Build the color-block prefab hierarchy with anchors and a CanvasScaler reference resolution of 750 x 1624.
- [ ] Change `LevelGameplayView` to bind prefab references and create only dynamic repeated content at runtime.
- [ ] Verify the scene hierarchy exposes Canvas, panels, EventSystem, and LevelController without runtime replacement.
- [ ] Capture comparison screenshots at representative ratios and commit with `feat: rebuild gameplay UI for 750x1624`.

### Task 5: UI Interaction, Results, and Ten-Level Navigation

**Files:**
- Modify: `Assets/ColorCreamFlow/Scripts/UI/LevelGameplayView.cs`
- Modify: `Assets/ColorCreamFlow/Scripts/UI/ResultPopupView.cs`
- Create: `Assets/ColorCreamFlow/Scripts/UI/LevelSelectView.cs`
- Create: `Assets/ColorCreamFlow/Prefabs/UI/LevelSelect.prefab`
- Create: `Assets/ColorCreamFlow/Tests/PlayMode/GameplayFlowTests.cs`

**Interfaces:**
- Produces: level selection for unlocked levels, next-level action, restart action, and visible locked state.

- [ ] Write PlayMode tests for making a product, serving a customer, success, failure, restart, and next-level navigation.
- [ ] Verify tests fail against the current popup and single-level flow.
- [ ] Implement event binding and color-block feedback without external art.
- [ ] Run PlayMode tests and manually complete levels 1 and 2 through the UI.
- [ ] Commit with `feat: complete first-pass game flow` and pause for first-pass approval.

### Task 6: WeChat Mini Game Integration and Build Validation

**Files:**
- Modify: `Packages/manifest.json`
- Modify: `Packages/packages-lock.json`
- Create: `Assets/ColorCreamFlow/Scripts/Platform/WeChatGameStorage.cs`
- Create: `Assets/ColorCreamFlow/Scripts/Platform/PlatformBootstrap.cs`
- Create: `Assets/ColorCreamFlow/Editor/WeChatBuildValidator.cs`
- Modify: relevant `ProjectSettings` files through Unity APIs.

**Interfaces:**
- Produces: platform bootstrap that selects WeChat APIs only when available and otherwise uses PlayerPrefs.
- Produces: an editor validation command that reports missing SDK, scenes, orientation, compression, and memory settings.

- [ ] Verify the current official Unity 2022.3-compatible WeChat conversion package and installation instructions before changing dependencies.
- [ ] Add platform-boundary tests that run without the WeChat SDK in EditMode.
- [ ] Install and configure the compatible official package once; do not duplicate an existing installation.
- [ ] Validate portrait orientation, touch input, audio unlock, pause/resume, storage fallback, and package settings.
- [ ] Produce a WeChat build archive and commit with `feat: add WeChat mini game delivery`.

### Task 7: WebGL Preview and Release Packaging

**Files:**
- Create: `Assets/ColorCreamFlow/Editor/ReleaseBuildPipeline.cs`
- Create: `docs/release/RELEASE_CHECKLIST.md`
- Generate: `Builds/WebGL/IceCream/`
- Generate: `Releases/IceCream-WeChat.zip`
- Generate: `Releases/IceCream-Unity-Source.zip`

**Interfaces:**
- Produces: deterministic editor commands for WebGL build and release archives.

- [ ] Add build preflight checks for clean Console, enabled gameplay scene, ten valid levels, portrait resolution, and output paths.
- [ ] Run preflight and fix every blocking diagnostic.
- [ ] Build WebGL and smoke-test loading, input, audio, gameplay, and persistence locally.
- [ ] Create WeChat and source archives while excluding Library, Temp, Logs, Obj, and UserSettings.
- [ ] Record checksums and commit build scripts/checklist with `build: add release packaging pipeline`.

### Task 8: GitHub Pages Game Card and Teaching Video

**Files:**
- Clone and inspect: `wthpein010-dev/ai-application-hub`
- Modify only the repository files that implement the existing game-card pattern.
- Add preview files under the repository's established `projects` structure.
- Add archives under the repository's established `downloads` structure.
- Add the teaching video under the repository's established `videos` structure.

**Interfaces:**
- Produces: an IceCream card in `#games` with preview, WeChat download, source download, and video controls matching other games.

- [ ] Inspect the live repository structure and identify the exact existing card/data pattern before editing.
- [ ] Record a concise teaching video showing rules, controls, one success, one failure, and download locations.
- [ ] Add IceCream using the existing site conventions without modifying unrelated cards.
- [ ] Test every local link, then deploy through a dedicated branch and review the patch.
- [ ] Verify the public page, WebGL preview, downloads, and video playback.
- [ ] Commit and push the website changes, then update `PROJECT_MEMORY.md` with public URLs and rollback commits.

## Final Verification

- [ ] Run all EditMode and PlayMode tests.
- [ ] Verify Unity Console contains zero errors.
- [ ] Inspect Scene and Hierarchy through read-only Unity MCP.
- [ ] Verify all ten levels are reachable and valid.
- [ ] Verify WebGL at representative portrait ratios.
- [ ] Verify the GitHub Pages game card, preview, two downloads, and video.
- [ ] Tag the source repository milestone and record the final rollback information.
