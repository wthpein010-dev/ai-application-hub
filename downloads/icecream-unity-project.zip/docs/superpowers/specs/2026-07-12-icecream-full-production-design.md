# IceCream Full Production Design

## Objective

Turn the existing Color Cream Flow prototype into a ten-level WeChat mini game with editable UGUI prefabs, a 750 x 1624 reference canvas, multi-resolution support, downloadable builds and source, an online WebGL preview, and an instructional video published through `wthpein010-dev/ai-application-hub`.

## Delivery Stages

1. Stabilize the existing gameplay and expand it to ten validated levels.
2. Rebuild the first UI pass with Unity color blocks and editable UGUI prefabs.
3. Add WeChat mini game platform support, WebGL delivery, performance checks, and packaging.
4. Publish the preview, WeChat build, source archive, and teaching video in the existing website game section.
5. After first-pass approval, source relevant references from the specified Pinterest page, crop and losslessly optimize the selected assets, create atlases where useful, and replace placeholder art.

## Architecture

- `Core`: Unity-independent models, color combinations, and level configuration types.
- `Gameplay`: machine input, product creation, conveyor movement, customer matching, and result evaluation. `LevelController` orchestrates these systems without absorbing their internal rules.
- `UI`: editable UGUI prefabs for the gameplay screen, HUD, customers, products, machine buttons, settings, and result popup.
- `Configs`: ten JSON levels loaded through the existing configuration loader.
- `Platform`: WeChat lifecycle, storage, and platform APIs behind interfaces with Editor and WebGL fallbacks.
- `Editor`: setup and validation utilities. Editor scripts must not overwrite manually edited production prefabs or scenes without an explicit command.
- `Docs`: design, implementation plan, memory, milestone history, and rollback references.

## Gameplay

The retained loop is:

1. Tap unlocked color machines to add up to three scoops.
2. Confirm the product and place it on the conveyor.
3. Products move through the judge zone.
4. Waiting customers automatically take a matching product.
5. Serving every customer succeeds; belt overflow or exhausting the production allowance without a possible match fails.

The ten-level progression gradually increases unlocked colors, customer count, recipe complexity, ordered matching requirements, conveyor pressure, capacity constraints, and production limits. Every level must be deterministically completable from its supplied orders and constraints.

## UI and Resolution Adaptation

- Reference resolution: `750 x 1624`.
- Technology: UGUI only.
- `CanvasScaler`: Scale With Screen Size.
- Layout policy: width-led scaling for portrait phones, safe-area padding at the top and bottom, anchored content regions, and guarded behavior for wider tablets and shorter screens.
- The first implementation uses Unity color blocks and basic shapes.
- Production UI is assembled from editable prefabs rather than being recreated entirely at runtime.
- Runtime code binds data and events; it does not silently replace hand-edited layout values.

## Persistence and Platform

Persist highest unlocked level, current level, coins, and basic settings. The platform layer uses WeChat storage when available and falls back to local storage in the Editor and WebGL preview. Platform initialization failures must not prevent local gameplay.

The WeChat delivery uses a Unity 2022.3.62f3c1-compatible official conversion workflow. Touch input, audio unlock, lifecycle pause/resume, loading, memory, and package-size behavior are verified on the target platform.

## Publishing

The public delivery contains:

- Browser-playable WebGL preview.
- Downloadable WeChat mini game build archive.
- Downloadable complete Unity source archive.
- Instructional video covering the rules, controls, example play, success/failure states, and download links.

The IceCream entry is added to the existing `#games` section of `wthpein010-dev/ai-application-hub` using the same visual and interaction conventions as the other mini-game cards.

## Asset Rules

The initial version does not fetch external art. After user approval, references are searched from `https://www.pinterest.com/sss` using project-relevant terms. Selected assets are cropped, organized, losslessly compressed, and atlased where appropriate. Asset names follow the project naming convention and contain no more than two underscores.

## Error Handling

- Missing or invalid level data falls back to a safe error screen and logs a clear diagnostic.
- Platform API failures fall back to local implementations.
- Missing optional art uses placeholder visuals instead of breaking gameplay.
- Build and runtime Console errors block milestone completion.
- Publishing does not overwrite unrelated website content.

## Verification

- Automated tests cover recipe matching, machine limits, result rules, and level configuration validity.
- All ten levels are checked for valid data and practical completion.
- Play-mode checks cover the full gameplay loop and persistence.
- UI is visually checked at 750 x 1624 plus representative tall, short, and tablet ratios.
- Unity Scene, Hierarchy, and Console are inspected through read-only Unity MCP access before and after major milestones.
- WebGL preview, public downloads, video playback, and website navigation are verified after deployment.

## Versioning and Rollback

Each major stage receives a dedicated Git commit and a matching entry in `PROJECT_MEMORY.md`. Existing baseline commits remain valid rollback points. High-risk destructive operations, public replacements, and unrelated repository changes require explicit confirmation.
