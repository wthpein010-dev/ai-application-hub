# IceCream Release Checklist

## Automated verification

1. Run all EditMode tests and confirm 18/18 pass.
2. Run `Color Cream Flow/Validate WeChat Build`.
3. Build `Color Cream Flow/Build/WebGL Preview`.
4. Build `Color Cream Flow/Build/WeChat Mini Game`.
5. Run `Color Cream Flow/Build/Validate Release Outputs`.

## Manual smoke checks

- Open the WebGL preview at a portrait viewport matching 750 x 1624.
- Complete one order and advance to the next level.
- Refresh the page and confirm progress is restored.
- Resize to a wide and a narrow phone viewport; confirm the safe area remains usable.
- Import the `minigame` directory into WeChat DevTools and confirm portrait launch.

## Public artifacts

- WebGL browser preview.
- WeChat mini-game archive.
- Complete Unity 2022.3.62f3c1 source archive.
- Instructional video.
