# Color Cream Flow

Unity project for the ice cream conveyor puzzle prototype.

## Unity Version

Open this folder with Unity `2022.3.62f3c1`.

The project is configured by `ProjectSettings/ProjectVersion.txt`. If Unity prompts to regenerate settings, accept it.

## First Open

When the project opens, `Assets/ColorCreamFlow/Editor/ColorCreamFlowProjectBootstrapper.cs` automatically:

- imports PNG art under `Assets/ColorCreamFlow/Resources/Art` as Sprites;
- creates `Assets/ColorCreamFlow/Scenes/LevelGameplay.unity`;
- creates starter prefabs under `Assets/ColorCreamFlow/Prefabs`;
- adds the gameplay scene to Build Settings.

You can manually rerun this with:

`Color Cream Flow > Rebuild Gameplay Scene And Prefabs`

## Current Gameplay

- Tap colored machine buttons to stack up to three scoops on the cone.
- Tap Confirm to place the product onto the conveyor.
- Customers automatically take matching products in the judge zone.
- All customers served results in success.
- Belt overflow or using all allowed products before serving everyone results in failure.
- Footer buttons currently provide prototype utility actions: undo last scoop, add belt capacity, and clear the oldest belt product.

## Important Paths

- Gameplay scene: `Assets/ColorCreamFlow/Scenes/LevelGameplay.unity`
- Level configs: `Assets/ColorCreamFlow/Resources/Configs/Levels`
- Art: `Assets/ColorCreamFlow/Resources/Art`
- Scripts: `Assets/ColorCreamFlow/Scripts`
- Prefab generation: `Assets/ColorCreamFlow/Editor/ColorCreamFlowProjectBootstrapper.cs`
