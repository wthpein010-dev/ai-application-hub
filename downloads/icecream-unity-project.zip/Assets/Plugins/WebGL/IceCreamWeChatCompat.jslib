mergeInto(LibraryManager.library, {
  WX_SyncFunction_tnnt: function(functionName, returnType, param1, param2, param3) {
    var result = '';
    if (typeof window !== 'undefined' &&
        window.WXWASMSDK &&
        typeof window.WXWASMSDK.WX_SyncFunction_tnnt === 'function') {
      result = window.WXWASMSDK.WX_SyncFunction_tnnt(
        UTF8ToString(functionName),
        UTF8ToString(returnType),
        param1,
        param2,
        UTF8ToString(param3));
    }

    var value = result || '';
    var size = lengthBytesUTF8(value) + 1;
    var buffer = _malloc(size);
    stringToUTF8(value, buffer, size);
    return buffer;
  }
});
