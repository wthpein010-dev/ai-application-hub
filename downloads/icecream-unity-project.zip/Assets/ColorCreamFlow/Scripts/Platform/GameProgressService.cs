using System;
using UnityEngine;

namespace ColorCreamFlow.Platform
{
    public sealed class GameProgressService
    {
        public const string StorageKey = "ColorCreamFlow.Progress";
        private const int MaxLevel = 10;
        private readonly IGameStorage storage;

        public GameProgressService(IGameStorage storage)
        {
            this.storage = storage ?? throw new ArgumentNullException(nameof(storage));
        }

        public GameProgress Load()
        {
            var json = storage.GetString(StorageKey, string.Empty);
            if (string.IsNullOrWhiteSpace(json))
            {
                return Defaults();
            }

            try
            {
                return Normalize(JsonUtility.FromJson<GameProgress>(json));
            }
            catch (ArgumentException)
            {
                return Defaults();
            }
        }

        public void Save(GameProgress progress)
        {
            storage.SetString(StorageKey, JsonUtility.ToJson(Normalize(progress)));
        }

        public GameProgress UnlockAfterSuccess(int completedLevel)
        {
            var progress = Load();
            var nextLevel = Mathf.Clamp(completedLevel + 1, 1, MaxLevel);
            progress.highestUnlockedLevel = Mathf.Max(progress.highestUnlockedLevel, nextLevel);
            progress.currentLevel = nextLevel;
            Save(progress);
            return progress;
        }

        private static GameProgress Normalize(GameProgress progress)
        {
            if (progress == null)
            {
                return Defaults();
            }

            progress.highestUnlockedLevel = Mathf.Clamp(progress.highestUnlockedLevel, 1, MaxLevel);
            progress.currentLevel = Mathf.Clamp(progress.currentLevel, 1, progress.highestUnlockedLevel);
            progress.coins = Mathf.Max(0, progress.coins);
            return progress;
        }

        private static GameProgress Defaults()
        {
            return new GameProgress();
        }
    }
}
