using System;

namespace ColorCreamFlow.Platform
{
    [Serializable]
    public sealed class GameProgress
    {
        public int highestUnlockedLevel = 1;
        public int currentLevel = 1;
        public int coins;
    }
}
