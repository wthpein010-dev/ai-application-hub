namespace ColorCreamFlow.Platform
{
    public interface IGameStorage
    {
        string GetString(string key, string fallback);
        void SetString(string key, string value);
    }
}
