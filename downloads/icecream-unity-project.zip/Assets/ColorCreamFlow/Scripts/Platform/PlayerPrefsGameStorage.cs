using UnityEngine;

namespace ColorCreamFlow.Platform
{
    public sealed class PlayerPrefsGameStorage : IGameStorage
    {
        public string GetString(string key, string fallback)
        {
            return PlayerPrefs.GetString(key, fallback);
        }

        public void SetString(string key, string value)
        {
            PlayerPrefs.SetString(key, value);
            PlayerPrefs.Save();
        }
    }
}
