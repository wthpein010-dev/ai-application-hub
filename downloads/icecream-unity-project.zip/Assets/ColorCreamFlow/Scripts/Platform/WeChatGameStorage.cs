namespace ColorCreamFlow.Platform
{
    public sealed class WeChatGameStorage : IGameStorage
    {
        private readonly PlayerPrefsGameStorage fallback = new PlayerPrefsGameStorage();

        public string GetString(string key, string defaultValue)
        {
            return fallback.GetString(key, defaultValue);
        }

        public void SetString(string key, string value)
        {
            fallback.SetString(key, value);
        }
    }
}
