using UnityEngine;

namespace ColorCreamFlow.Platform
{
    public static class PlatformBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Initialize()
        {
            Application.targetFrameRate = 60;
        }

        public static IGameStorage CreateStorage()
        {
#if ICECREAM_WECHAT
            return new WeChatGameStorage();
#else
            return new PlayerPrefsGameStorage();
#endif
        }
    }
}
