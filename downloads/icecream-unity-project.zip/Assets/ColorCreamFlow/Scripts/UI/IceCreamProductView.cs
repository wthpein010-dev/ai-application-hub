using System;
using System.Collections.Generic;
using ColorCreamFlow.Core;
using UnityEngine;
using UnityEngine.UI;

namespace ColorCreamFlow.UI
{
    public sealed class IceCreamProductView : MonoBehaviour
    {
        private readonly List<Image> scoopImages = new List<Image>();
        private SpriteResourceCatalog catalog;
        private RectTransform rectTransform;
        private Image coneImage;

        public int ProductId { get; private set; } = -1;
        public Action<int> Clicked;

        public RectTransform RectTransform
        {
            get
            {
                if (rectTransform == null)
                {
                    rectTransform = GetComponent<RectTransform>();
                }

                return rectTransform;
            }
        }

        public static IceCreamProductView Create(string name, Transform parent, SpriteResourceCatalog catalog, Vector2 size)
        {
            var rect = UiFactory.Rect(name, parent, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, size);
            var view = rect.gameObject.AddComponent<IceCreamProductView>();
            view.catalog = catalog;
            view.Build();
            return view;
        }

        public void Bind(SpriteResourceCatalog resourceCatalog)
        {
            catalog = resourceCatalog;
            rectTransform = GetComponent<RectTransform>();
            coneImage = transform.Find("Cone")?.GetComponent<Image>();
            scoopImages.Clear();
            for (var index = 0; index < transform.childCount; index++)
            {
                var child = transform.GetChild(index);
                if (child.name.StartsWith("Scoop_", StringComparison.Ordinal))
                {
                    scoopImages.Add(child.GetComponent<Image>());
                }
            }
        }

        public void Initialize(int productId, IReadOnlyList<IceCreamColor> scoops)
        {
            ProductId = productId;
            SetScoops(scoops);
        }

        public void SetScoops(IReadOnlyList<IceCreamColor> scoops)
        {
            EnsureScoopCount(scoops.Count);

            for (var i = 0; i < scoopImages.Count; i++)
            {
                var visible = i < scoops.Count;
                scoopImages[i].gameObject.SetActive(visible);
                if (!visible)
                {
                    continue;
                }

                scoopImages[i].sprite = catalog.Scoop(scoops[i]);
                scoopImages[i].color = Color.white;
            }
        }

        private void Build()
        {
            var button = gameObject.AddComponent<Button>();
            button.transition = Selectable.Transition.None;
            button.onClick.AddListener(() => Clicked?.Invoke(ProductId));

            coneImage = UiFactory.Image("Cone", transform, catalog.Cone, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, -20f), new Vector2(74f, 74f));
            coneImage.raycastTarget = false;
            EnsureScoopCount(3);
            Bind(catalog);
        }

        private void EnsureScoopCount(int count)
        {
            while (scoopImages.Count < Math.Max(3, count))
            {
                var index = scoopImages.Count;
                var y = 10f + index * 18f;
                var image = UiFactory.Image($"Scoop_{index}", transform, null, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, y), new Vector2(76f, 64f));
                image.raycastTarget = false;
                scoopImages.Add(image);
            }
        }
    }
}
