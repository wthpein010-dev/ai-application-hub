using UnityEngine;

namespace ColorCreamFlow.UI
{
    [ExecuteAlways]
    [RequireComponent(typeof(RectTransform))]
    public sealed class SafeAreaFitter : MonoBehaviour
    {
        private RectTransform rectTransform;
        private Rect lastSafeArea;
        private Vector2Int lastScreenSize;

        private void OnEnable()
        {
            rectTransform = GetComponent<RectTransform>();
            ApplyCurrentSafeArea();
        }

        private void Update()
        {
            var screenSize = new Vector2Int(Screen.width, Screen.height);
            if (lastSafeArea != Screen.safeArea || lastScreenSize != screenSize)
            {
                ApplyCurrentSafeArea();
            }
        }

        public void ApplyCurrentSafeArea()
        {
            lastSafeArea = Screen.safeArea;
            lastScreenSize = new Vector2Int(Screen.width, Screen.height);
            Apply(lastSafeArea, lastScreenSize);
        }

        public void Apply(Rect safeArea, Vector2Int screenSize)
        {
            if (rectTransform == null)
            {
                rectTransform = GetComponent<RectTransform>();
            }

            var anchors = CalculateAnchors(safeArea, screenSize);
            rectTransform.anchorMin = new Vector2(anchors.x, anchors.y);
            rectTransform.anchorMax = new Vector2(anchors.z, anchors.w);
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;
        }

        public static Vector4 CalculateAnchors(Rect safeArea, Vector2Int screenSize)
        {
            if (screenSize.x <= 0 || screenSize.y <= 0)
            {
                return new Vector4(0f, 0f, 1f, 1f);
            }

            return new Vector4(
                Mathf.Clamp01(safeArea.xMin / screenSize.x),
                Mathf.Clamp01(safeArea.yMin / screenSize.y),
                Mathf.Clamp01(safeArea.xMax / screenSize.x),
                Mathf.Clamp01(safeArea.yMax / screenSize.y));
        }
    }
}
