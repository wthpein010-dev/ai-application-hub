using System;
using System.Collections.Generic;
using ColorCreamFlow.Core;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ColorCreamFlow.UI
{
    public sealed class LevelGameplayView : MonoBehaviour
    {
        private readonly Dictionary<int, IceCreamProductView> beltProductViews = new Dictionary<int, IceCreamProductView>();
        private readonly List<CustomerView> customerViews = new List<CustomerView>();
        private SpriteResourceCatalog catalog;
        [SerializeField] private RectTransform beltTrackRect;
        [SerializeField] private RectTransform beltProductRoot;
        [SerializeField] private RectTransform customerRoot;
        [SerializeField] private RectTransform machineRoot;
        [SerializeField] private IceCreamProductView buildingPreview;
        [SerializeField] private ResultPopupView resultPopup;
        [SerializeField] private Text levelText;
        [SerializeField] private Text coinText;
        [SerializeField] private Text capacityText;
        [SerializeField] private Text productionText;

        public event Action<IceCreamColor> MachineClicked;
        public event Action ConfirmClicked;
        public event Action UndoClicked;
        public event Action RemoveClicked;
        public event Action CapacityClicked;
        public event Action RestartClicked;
        public event Action NextLevelClicked;

        public void Build()
        {
            if (IsBuilt())
            {
                catalog = new SpriteResourceCatalog();
                buildingPreview.Bind(catalog);
                resultPopup.Bind();
                resultPopup.RestartClicked = () => RestartClicked?.Invoke();
                resultPopup.NextClicked = () => NextLevelClicked?.Invoke();
                EnsureEventSystem();
                return;
            }

            catalog = new SpriteResourceCatalog();

            var canvas = gameObject.GetComponent<Canvas>();
            if (canvas == null)
            {
                canvas = gameObject.AddComponent<Canvas>();
            }

            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 0;

            var scaler = gameObject.GetComponent<CanvasScaler>() ?? gameObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(750f, 1624f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0f;

            if (gameObject.GetComponent<GraphicRaycaster>() == null)
            {
                gameObject.AddComponent<GraphicRaycaster>();
            }
            EnsureEventSystem();

            var canvasRoot = transform;
            UiFactory.ClearChildren(canvasRoot);

            var bg = UiFactory.Image("Background", canvasRoot, null, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, false);
            bg.color = new Color(0.72f, 0.92f, 0.98f, 1f);
            bg.rectTransform.offsetMin = Vector2.zero;
            bg.rectTransform.offsetMax = Vector2.zero;

            var root = UiFactory.Rect("SafeArea", canvasRoot, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            root.offsetMin = Vector2.zero;
            root.offsetMax = Vector2.zero;
            root.gameObject.AddComponent<SafeAreaFitter>();

            BuildTopHud(root);
            BuildCustomerArea(root);
            BuildConveyor(root);
            BuildMachineArea(root);
            BuildFooter(root);
            BuildResultPopup(root);
        }

        private bool IsBuilt()
        {
            return beltTrackRect != null && beltProductRoot != null && customerRoot != null &&
                   machineRoot != null && buildingPreview != null && resultPopup != null &&
                   levelText != null && coinText != null && capacityText != null && productionText != null;
        }

        public void RenderLevel(LevelConfig config)
        {
            levelText.text = config.displayName;
            SetCoins(config.startingCoins);
            SetCapacity(0, config.beltCapacity);
            SetProduction(0, config.maxProductsToMake);
        }

        public void RenderCustomers(IReadOnlyList<CustomerModel> customers)
        {
            while (customerViews.Count < customers.Count)
            {
                var index = customerViews.Count;
                var x = -220f + index * 220f;
                var rect = UiFactory.Rect($"Customer_{index}", customerRoot, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(x, 0f), new Vector2(180f, 310f));
                var view = rect.gameObject.AddComponent<CustomerView>();
                view.Build(catalog);
                customerViews.Add(view);
            }

            for (var i = 0; i < customerViews.Count; i++)
            {
                customerViews[i].gameObject.SetActive(i < customers.Count);
                if (i < customers.Count)
                {
                    customerViews[i].Render(customers[i]);
                }
            }
        }

        public void RenderMachines(IReadOnlyList<IceCreamColor> colors)
        {
            UiFactory.ClearChildren(machineRoot);

            var spacing = 120f;
            var startX = -(colors.Count - 1) * spacing * 0.5f;
            for (var i = 0; i < colors.Count; i++)
            {
                var rect = UiFactory.Rect($"Machine_{colors[i]}", machineRoot, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(startX + i * spacing, 0f), new Vector2(112f, 112f));
                var button = rect.gameObject.AddComponent<MachineButtonView>();
                button.Build(catalog, colors[i], color => MachineClicked?.Invoke(color));
            }
        }

        public void SetBuildingScoops(IReadOnlyList<IceCreamColor> scoops)
        {
            buildingPreview.SetScoops(scoops);
        }

        public void AddBeltProduct(ProductModel product)
        {
            var view = IceCreamProductView.Create($"Product_{product.ProductId}", beltProductRoot, catalog, new Vector2(86f, 110f));
            view.Initialize(product.ProductId, product.Scoops);
            view.RectTransform.localScale = Vector3.one * 1.15f;
            beltProductViews[product.ProductId] = view;
            UpdateBeltProductPosition(product);
        }

        public void RemoveBeltProduct(int productId)
        {
            if (!beltProductViews.TryGetValue(productId, out var view))
            {
                return;
            }

            beltProductViews.Remove(productId);
            Destroy(view.gameObject);
        }

        public void UpdateBeltProductPosition(ProductModel product)
        {
            if (!beltProductViews.TryGetValue(product.ProductId, out var view))
            {
                return;
            }

            var width = beltTrackRect.rect.width <= 1f ? 640f : beltTrackRect.rect.width;
            var x = Mathf.Lerp(-width * 0.45f, width * 0.45f, product.BeltPosition);
            view.RectTransform.anchoredPosition = new Vector2(x, 4f + Mathf.Sin(product.BeltPosition * Mathf.PI * 2f) * 4f);
        }

        public void SetCoins(int coins)
        {
            coinText.text = coins.ToString();
        }

        public void SetCapacity(int count, int capacity)
        {
            capacityText.text = $"{count}/{capacity}";
        }

        public void SetProduction(int produced, int max)
        {
            productionText.text = max > 0 ? $"{produced}/{max}" : produced.ToString();
        }

        public void ShowSuccess(int coins)
        {
            resultPopup.ShowSuccess(coins);
        }

        public void ShowFail(string reason)
        {
            resultPopup.ShowFail(reason);
        }

        public void HideResult()
        {
            resultPopup.Hide();
        }

        private void BuildTopHud(Transform root)
        {
            var coinBg = UiFactory.Image("CoinBg", root, catalog.Ui("Ui_coinAddBg"), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(132f, -76f), new Vector2(238f, 63f));
            coinBg.raycastTarget = false;
            UiFactory.Image("CoinIcon", coinBg.transform, catalog.Coin, new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(24f, 0f), new Vector2(58f, 58f));
            coinText = UiFactory.Text("CoinText", coinBg.transform, "9999", 32, Color.white, TextAnchor.MiddleCenter, new Vector2(0f, 0f), new Vector2(1f, 1f), new Vector2(20f, 0f), new Vector2(-54f, 0f));

            var levelBg = UiFactory.Image("LevelBg", root, catalog.LevelBackground, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -84f), new Vector2(210f, 88f));
            levelText = UiFactory.Text("LevelText", levelBg.transform, "Level 1", 36, new Color(0.38f, 0.18f, 0.15f), TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);

            UiFactory.Button("Settings", root, catalog.Setting, new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-72f, -76f), new Vector2(84f, 84f));
        }

        private static void EnsureEventSystem()
        {
            if (FindObjectOfType<EventSystem>() != null)
            {
                return;
            }

            var eventSystem = new GameObject("EventSystem");
            eventSystem.AddComponent<EventSystem>();
            eventSystem.AddComponent<StandaloneInputModule>();
        }

        private void BuildCustomerArea(Transform root)
        {
            customerRoot = UiFactory.Rect("Customers", root, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -330f), new Vector2(700f, 340f));
        }

        private void BuildConveyor(Transform root)
        {
            var counter = UiFactory.Image("CounterFrame", root, null, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -520f), new Vector2(720f, 120f), false);
            counter.color = new Color(1f, 0.84f, 0.55f, 1f);
            var conveyorBg = UiFactory.Image("ConveyorBg", root, null, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -650f), new Vector2(720f, 180f), false);
            conveyorBg.color = new Color(0.35f, 0.22f, 0.18f, 1f);
            var conveyor = UiFactory.Image("Conveyor", root, null, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -650f), new Vector2(680f, 88f), false);
            conveyor.color = new Color(0.16f, 0.18f, 0.22f, 1f);

            beltTrackRect = UiFactory.Rect("BeltTrack", root, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -610f), new Vector2(680f, 128f));
            beltProductRoot = UiFactory.Rect("BeltProducts", beltTrackRect, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            beltProductRoot.offsetMin = Vector2.zero;
            beltProductRoot.offsetMax = Vector2.zero;
        }

        private void BuildMachineArea(Transform root)
        {
            var machineBody = UiFactory.Image("MachineBody", root, null, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 460f), new Vector2(520f, 360f));
            machineBody.color = new Color(0.95f, 0.35f, 0.55f, 1f);
            buildingPreview = IceCreamProductView.Create("BuildingPreview", root, catalog, new Vector2(120f, 150f));
            buildingPreview.RectTransform.anchorMin = new Vector2(0.5f, 0f);
            buildingPreview.RectTransform.anchorMax = new Vector2(0.5f, 0f);
            buildingPreview.RectTransform.anchoredPosition = new Vector2(0f, 470f);
            buildingPreview.RectTransform.localScale = Vector3.one * 1.45f;

            machineRoot = UiFactory.Rect("MachineButtons", root, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 720f), new Vector2(620f, 132f));

            var confirm = UiFactory.Button("ConfirmButton", root, null, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 230f), new Vector2(460f, 140f));
            confirm.image.color = new Color(0.18f, 0.72f, 0.42f, 1f);
            confirm.onClick.AddListener(() => ConfirmClicked?.Invoke());
            UiFactory.Text("ConfirmText", confirm.transform, "Confirm", 48, Color.white, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            UiFactory.Image("GuideHand", confirm.transform, catalog.GuideHand, new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(64f, -12f), new Vector2(154f, 110f));
        }

        private void BuildFooter(Transform root)
        {
            var footer = UiFactory.Rect("Footer", root, new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0f, 74f), new Vector2(0f, 148f));
            var bg = footer.gameObject.AddComponent<Image>();
            bg.color = new Color(0.76f, 0.05f, 0.35f, 0.98f);

            var undo = BuildBoosterButton("Undo", footer, -150f, catalog.BoosterIcon(0), "Undo");
            undo.onClick.AddListener(() => UndoClicked?.Invoke());
            var capacity = BuildBoosterButton("Capacity", footer, 0f, catalog.BoosterIcon(1), "+Cap");
            capacity.onClick.AddListener(() => CapacityClicked?.Invoke());
            var remove = BuildBoosterButton("Remove", footer, 150f, catalog.BoosterIcon(2), "Clear");
            remove.onClick.AddListener(() => RemoveClicked?.Invoke());

            capacityText = UiFactory.Text("CapacityText", root, "0/0", 24, Color.white, TextAnchor.MiddleLeft, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(26f, -122f), new Vector2(160f, 32f));
            productionText = UiFactory.Text("ProductionText", root, "0/0", 24, Color.white, TextAnchor.MiddleRight, new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-26f, -122f), new Vector2(160f, 32f));
        }

        private Button BuildBoosterButton(string name, Transform parent, float x, Sprite icon, string label)
        {
            var button = UiFactory.Button(name, parent, catalog.Ui("Ui_button0"), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(x, 8f), new Vector2(104f, 104f));
            UiFactory.Image("Icon", button.transform, icon, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, 12f), new Vector2(72f, 72f));
            UiFactory.Text("Label", button.transform, label, 18, Color.white, TextAnchor.MiddleCenter, new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0f, 14f), new Vector2(0f, 26f));
            return button;
        }

        private void BuildResultPopup(Transform root)
        {
            var popupRect = UiFactory.Rect("ResultPopup", root, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            popupRect.offsetMin = Vector2.zero;
            popupRect.offsetMax = Vector2.zero;
            resultPopup = popupRect.gameObject.AddComponent<ResultPopupView>();
            resultPopup.Build(catalog);
            resultPopup.RestartClicked += () => RestartClicked?.Invoke();
            resultPopup.NextClicked += () => NextLevelClicked?.Invoke();
        }
    }
}
