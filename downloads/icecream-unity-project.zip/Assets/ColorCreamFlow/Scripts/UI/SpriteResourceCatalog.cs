using ColorCreamFlow.Core;
using UnityEngine;

namespace ColorCreamFlow.UI
{
    public sealed class SpriteResourceCatalog
    {
        public Sprite Ui(string name) => Resources.Load<Sprite>($"Art/UI/{name}");
        public Sprite Customer(string name) => Resources.Load<Sprite>($"Art/Customers/{name}");

        public Sprite Cone => Ui("Icecream0");
        public Sprite Background => Ui("Bg_001");
        public Sprite LevelBackground => Ui("Ui_levelBg");
        public Sprite Coin => Ui("Ui_coin");
        public Sprite Setting => Ui("Ui_setting");
        public Sprite Bubble => Ui("Ui_bubble");
        public Sprite Machine => Ui("Ui_machine");
        public Sprite MachineButton => Ui("Ui_button0");
        public Sprite ConfirmButton => Ui("Ui_ConfirmButton");
        public Sprite Conveyor => Ui("Ui_transmit");
        public Sprite ConveyorBackground => Ui("Ui_transmitBg");
        public Sprite Frame => Ui("Ui_frame");
        public Sprite GuideHand => Ui("Ui_guidehand");

        public Sprite Scoop(IceCreamColor color)
        {
            switch (color)
            {
                case IceCreamColor.Yellow:
                    return Ui("Icecream2");
                case IceCreamColor.Blue:
                    return Ui("Icecream3");
                case IceCreamColor.Green:
                    return Ui("Icecream4");
                default:
                    return Ui("Icecream1");
            }
        }

        public Sprite BoosterIcon(int index)
        {
            switch (index)
            {
                case 1:
                    return Ui("Icon_item2");
                case 2:
                    return Ui("Icon_item3");
                default:
                    return Ui("Icon_item1");
            }
        }
    }
}
