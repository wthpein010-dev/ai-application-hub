using System;
using UnityEngine;
using UnityEngine.UI;

namespace ColorCreamFlow.UI
{
    public sealed class ResultPopupView : MonoBehaviour
    {
        [SerializeField] private Text title;
        [SerializeField] private Text detail;
        [SerializeField] private Button restartButton;
        [SerializeField] private Button nextButton;

        public Action RestartClicked;
        public Action NextClicked;

        public void Build(SpriteResourceCatalog catalog)
        {
            var blocker = gameObject.AddComponent<Image>();
            blocker.color = new Color(0f, 0f, 0f, 0.48f);

            var panel = UiFactory.Rect("Panel", transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(560f, 420f));
            var panelImage = panel.gameObject.AddComponent<Image>();
            panelImage.sprite = catalog.LevelBackground;
            panelImage.type = Image.Type.Sliced;
            panelImage.color = Color.white;

            title = UiFactory.Text("Title", panel, "Success", 58, new Color(0.38f, 0.18f, 0.15f), TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, 90f), new Vector2(430f, 80f));
            detail = UiFactory.Text("Detail", panel, string.Empty, 32, new Color(0.38f, 0.18f, 0.15f), TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, 10f), new Vector2(430f, 86f));
            restartButton = UiFactory.Button("RestartButton", panel, null, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(-170f, -116f), new Vector2(220f, 104f));
            restartButton.image.color = new Color(0.92f, 0.36f, 0.42f, 1f);
            UiFactory.Text("RestartText", restartButton.transform, "Restart", 44, Color.white, TextAnchor.MiddleCenter, new Vector2(0f, 0f), new Vector2(1f, 1f), Vector2.zero, Vector2.zero);
            nextButton = UiFactory.Button("NextButton", panel, null, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(170f, -116f), new Vector2(220f, 104f));
            nextButton.image.color = new Color(0.18f, 0.72f, 0.42f, 1f);
            UiFactory.Text("NextText", nextButton.transform, "Next", 44, Color.white, TextAnchor.MiddleCenter, new Vector2(0f, 0f), new Vector2(1f, 1f), Vector2.zero, Vector2.zero);
            Bind();
            gameObject.SetActive(false);
        }

        public void Bind()
        {
            title = title != null ? title : transform.Find("Panel/Title")?.GetComponent<Text>();
            detail = detail != null ? detail : transform.Find("Panel/Detail")?.GetComponent<Text>();
            restartButton = restartButton != null ? restartButton : transform.Find("Panel/RestartButton")?.GetComponent<Button>();
            nextButton = nextButton != null ? nextButton : transform.Find("Panel/NextButton")?.GetComponent<Button>();
            restartButton.onClick.RemoveAllListeners();
            restartButton.onClick.AddListener(() => RestartClicked?.Invoke());
            nextButton.onClick.RemoveAllListeners();
            nextButton.onClick.AddListener(() => NextClicked?.Invoke());
        }

        public void ShowSuccess(int coins)
        {
            title.text = "Success";
            detail.text = $"Coins +{coins}";
            nextButton.gameObject.SetActive(true);
            gameObject.SetActive(true);
        }

        public void ShowFail(string reason)
        {
            title.text = "Failed";
            detail.text = reason;
            nextButton.gameObject.SetActive(false);
            gameObject.SetActive(true);
        }

        public void Hide()
        {
            gameObject.SetActive(false);
        }
    }
}
