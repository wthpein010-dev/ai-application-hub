using System;
using ColorCreamFlow.Core;
using UnityEngine;
using UnityEngine.UI;

namespace ColorCreamFlow.UI
{
    public sealed class MachineButtonView : MonoBehaviour
    {
        private IceCreamColor color;

        public void Build(SpriteResourceCatalog catalog, IceCreamColor machineColor, Action<IceCreamColor> onClicked)
        {
            color = machineColor;
            var button = gameObject.AddComponent<Button>();
            var bg = gameObject.AddComponent<Image>();
            bg.sprite = catalog.MachineButton;
            bg.preserveAspect = true;
            button.targetGraphic = bg;
            button.onClick.AddListener(() => onClicked?.Invoke(color));

            var icon = UiFactory.Image("ScoopIcon", transform, catalog.Scoop(color), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(76f, 70f));
            icon.raycastTarget = false;
        }
    }
}
