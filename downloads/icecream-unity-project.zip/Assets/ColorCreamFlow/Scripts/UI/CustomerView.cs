using System.Collections.Generic;
using ColorCreamFlow.Core;
using UnityEngine;
using UnityEngine.UI;

namespace ColorCreamFlow.UI
{
    public sealed class CustomerView : MonoBehaviour
    {
        private SpriteResourceCatalog catalog;
        private Image characterImage;
        private Text valueText;
        private GameObject servedMark;
        private IceCreamProductView orderView;

        public void Build(SpriteResourceCatalog spriteCatalog)
        {
            catalog = spriteCatalog;

            UiFactory.Image("Bubble", transform, catalog.Bubble, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, 82f), new Vector2(168f, 132f));
            orderView = IceCreamProductView.Create("OrderProduct", transform, catalog, new Vector2(100f, 100f));
            orderView.RectTransform.anchoredPosition = new Vector2(0f, 86f);
            orderView.RectTransform.localScale = Vector3.one * 0.7f;

            characterImage = UiFactory.Image("Character", transform, null, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, -12f), new Vector2(132f, 210f));
            valueText = UiFactory.Text("Value", transform, string.Empty, 28, new Color(1f, 0.86f, 0.18f), TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, -130f), new Vector2(110f, 38f));

            var markRect = UiFactory.Rect("ServedMark", transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, 8f), new Vector2(130f, 130f));
            var markText = markRect.gameObject.AddComponent<Text>();
            markText.font = UiFactory.DefaultFont;
            markText.text = "OK";
            markText.fontStyle = FontStyle.Bold;
            markText.fontSize = 46;
            markText.alignment = TextAnchor.MiddleCenter;
            markText.color = new Color(0.2f, 0.85f, 0.22f, 0.95f);
            servedMark = markRect.gameObject;
            servedMark.SetActive(false);
        }

        public void Render(CustomerModel customer)
        {
            characterImage.sprite = catalog.Customer(customer.SpriteName);
            orderView.Initialize(-1, customer.Order);
            valueText.text = $"+{customer.Value}";
            servedMark.SetActive(customer.State == CustomerState.Served);
            characterImage.color = customer.State == CustomerState.Served ? new Color(1f, 1f, 1f, 0.45f) : Color.white;
        }
    }
}
