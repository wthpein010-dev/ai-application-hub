using System.Collections.Generic;
using System.Linq;
using ColorCreamFlow.Core;

namespace ColorCreamFlow.Gameplay
{
    public sealed class MatchingSystem
    {
        public ProductModel FindMatch(CustomerModel customer, IEnumerable<ProductModel> candidates)
        {
            return candidates
                .Where(product => Matches(customer, product))
                .OrderBy(product => product.SpawnTime)
                .FirstOrDefault();
        }

        private static bool Matches(CustomerModel customer, ProductModel product)
        {
            if (customer.Order.Count != product.Scoops.Count)
            {
                return false;
            }

            if (customer.OrderStrict)
            {
                for (var i = 0; i < customer.Order.Count; i++)
                {
                    if (customer.Order[i] != product.Scoops[i])
                    {
                        return false;
                    }
                }

                return true;
            }

            return SameMultiset(customer.Order, product.Scoops);
        }

        private static bool SameMultiset(IReadOnlyList<IceCreamColor> a, IReadOnlyList<IceCreamColor> b)
        {
            var counts = new Dictionary<IceCreamColor, int>();
            foreach (var color in a)
            {
                counts[color] = counts.TryGetValue(color, out var count) ? count + 1 : 1;
            }

            foreach (var color in b)
            {
                if (!counts.TryGetValue(color, out var count) || count == 0)
                {
                    return false;
                }

                counts[color] = count - 1;
            }

            return counts.Values.All(count => count == 0);
        }
    }
}
