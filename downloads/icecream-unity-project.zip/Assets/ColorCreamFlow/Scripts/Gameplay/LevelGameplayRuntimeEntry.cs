using UnityEngine;

namespace ColorCreamFlow.Gameplay
{
    public static class LevelGameplayRuntimeEntry
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void EnsureGameplayExists()
        {
            if (Object.FindObjectOfType<LevelController>() != null)
            {
                return;
            }

            var controllerObject = new GameObject("LevelController");
            Object.DontDestroyOnLoad(controllerObject);
            controllerObject.AddComponent<LevelController>();
        }
    }
}
