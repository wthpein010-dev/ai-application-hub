using ColorCreamFlow.Core;
using System;
using System.Linq;
using UnityEngine;

namespace ColorCreamFlow.Gameplay
{
    public sealed class LevelConfigLoader
    {
        public LevelConfig Load(int levelId)
        {
            var asset = Resources.Load<TextAsset>($"Configs/Levels/level_{levelId:000}");
            if (asset == null)
            {
                asset = Resources.Load<TextAsset>("Configs/Levels/level_001");
            }

            if (asset == null)
            {
                Debug.LogError("No level config found under Resources/Configs/Levels.");
                return new LevelConfig
                {
                    levelId = 1,
                    displayName = "Level 1",
                    unlockedColors = new[] { "Pink", "Yellow", "Blue", "Green" },
                    customers = new CustomerConfig[0],
                    beltCapacity = 6,
                    maxProductsToMake = 8
                };
            }

            var config = JsonUtility.FromJson<LevelConfig>(asset.text);
            var errors = LevelConfigValidator.Validate(config);
            if (errors.Count > 0)
            {
                throw new InvalidOperationException(
                    $"Level {levelId:000} is invalid: {string.Join("; ", errors.ToArray())}");
            }

            return config;
        }
    }
}
