using ColorCreamFlow.UI;
using UnityEngine;

namespace ColorCreamFlow.Gameplay
{
    public sealed class LevelGameplayBootstrap : MonoBehaviour
    {
        private void Awake()
        {
            if (FindObjectOfType<LevelController>() != null)
            {
                return;
            }

            var canvasObject = new GameObject("LevelGameplayCanvas");
            var view = canvasObject.AddComponent<LevelGameplayView>();
            var controller = gameObject.AddComponent<LevelController>();

            var field = typeof(LevelController).GetField("view", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            field?.SetValue(controller, view);
        }
    }
}
