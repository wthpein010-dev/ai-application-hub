using System.Collections.Generic;
using System.Linq;
using ColorCreamFlow.Core;

namespace ColorCreamFlow.Gameplay
{
    public sealed class MachineSystem
    {
        private const int MaxScoopsPerProduct = 3;
        private readonly List<IceCreamColor> unlockedColors = new List<IceCreamColor>();
        private readonly List<IceCreamColor> buildingScoops = new List<IceCreamColor>();

        public IReadOnlyList<IceCreamColor> UnlockedColors => unlockedColors;
        public IReadOnlyList<IceCreamColor> BuildingScoops => buildingScoops;

        public void Initialize(IEnumerable<string> colors)
        {
            unlockedColors.Clear();
            buildingScoops.Clear();

            foreach (var value in colors ?? Enumerable.Empty<string>())
            {
                if (IceCreamColorUtility.TryParse(value, out var color) && !unlockedColors.Contains(color))
                {
                    unlockedColors.Add(color);
                }
            }

            if (unlockedColors.Count == 0)
            {
                unlockedColors.AddRange(new[] { IceCreamColor.Pink, IceCreamColor.Yellow, IceCreamColor.Blue, IceCreamColor.Green });
            }
        }

        public bool TryAddScoop(IceCreamColor color)
        {
            if (!unlockedColors.Contains(color) || buildingScoops.Count >= MaxScoopsPerProduct)
            {
                return false;
            }

            buildingScoops.Add(color);
            GameEvents.RaiseScoopAdded(color);
            return true;
        }

        public bool CanConfirm()
        {
            return buildingScoops.Count > 0;
        }

        public List<IceCreamColor> ConsumeBuildingScoops()
        {
            var result = new List<IceCreamColor>(buildingScoops);
            buildingScoops.Clear();
            return result;
        }

        public void UndoLastScoop()
        {
            if (buildingScoops.Count > 0)
            {
                buildingScoops.RemoveAt(buildingScoops.Count - 1);
            }
        }

        public void Clear()
        {
            buildingScoops.Clear();
        }
    }
}
