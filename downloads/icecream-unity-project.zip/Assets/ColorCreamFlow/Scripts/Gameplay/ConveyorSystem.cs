using ColorCreamFlow.Core;
using UnityEngine;

namespace ColorCreamFlow.Gameplay
{
    public sealed class ConveyorSystem
    {
        private ProductSystem productSystem;
        private float beltSpeed;

        public void Initialize(ProductSystem products, float speed)
        {
            productSystem = products;
            beltSpeed = speed;
        }

        public void Tick(float deltaTime)
        {
            if (productSystem == null)
            {
                return;
            }

            foreach (var product in productSystem.ActiveOnBelt())
            {
                product.Move(beltSpeed * deltaTime);
            }
        }

        public bool IsInJudgeZone(ProductModel product, float center, float radius)
        {
            var distance = Mathf.Abs(Mathf.DeltaAngle(product.BeltPosition * 360f, center * 360f)) / 360f;
            return distance <= radius;
        }
    }
}
