namespace ColorCreamFlow.Gameplay
{
    public enum LevelState
    {
        Init,
        Ready,
        Playing,
        Paused,
        Failed,
        Success
    }
}
