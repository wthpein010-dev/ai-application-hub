using System.Collections.Generic;
using System.Linq;
using ColorCreamFlow.Core;

namespace ColorCreamFlow.Gameplay
{
    public static class LevelConfigValidator
    {
        public static IReadOnlyList<string> Validate(LevelConfig config)
        {
            var errors = new List<string>();
            if (config == null)
            {
                errors.Add("config is required");
                return errors;
            }

            if (config.levelId <= 0)
            {
                errors.Add("levelId must be positive");
            }

            if (string.IsNullOrWhiteSpace(config.displayName))
            {
                errors.Add("displayName is required");
            }

            var unlocked = new HashSet<IceCreamColor>();
            foreach (var value in config.unlockedColors ?? new string[0])
            {
                if (IceCreamColorUtility.TryParse(value, out var color))
                {
                    unlocked.Add(color);
                }
                else
                {
                    errors.Add($"unlockedColors contains unknown color '{value}'");
                }
            }

            if (unlocked.Count == 0)
            {
                errors.Add("unlockedColors must contain at least one valid color");
            }

            if (config.customers == null || config.customers.Length == 0)
            {
                errors.Add("at least one customer is required");
            }
            else
            {
                for (var index = 0; index < config.customers.Length; index++)
                {
                    ValidateCustomer(config.customers[index], index, unlocked, errors);
                }
            }

            if (config.beltCapacity <= 0)
            {
                errors.Add("beltCapacity must be positive");
            }

            if (config.maxProductsToMake > 0 && config.customers != null &&
                config.maxProductsToMake < config.customers.Length)
            {
                errors.Add("maxProductsToMake cannot be lower than the customer count");
            }

            if (config.beltSpeed <= 0f)
            {
                errors.Add("beltSpeed must be positive");
            }

            if (config.judgeZoneCenter < 0f || config.judgeZoneCenter > 1f)
            {
                errors.Add("judgeZoneCenter must be between 0 and 1");
            }

            if (config.judgeZoneRadius <= 0f || config.judgeZoneRadius > 0.5f)
            {
                errors.Add("judgeZoneRadius must be greater than 0 and no greater than 0.5");
            }

            return errors;
        }

        private static void ValidateCustomer(
            CustomerConfig customer,
            int index,
            HashSet<IceCreamColor> unlocked,
            ICollection<string> errors)
        {
            if (customer == null)
            {
                errors.Add($"customer[{index}] is required");
                return;
            }

            if (string.IsNullOrWhiteSpace(customer.id))
            {
                errors.Add($"customer[{index}].id is required");
            }

            if (customer.order == null || customer.order.Length == 0 || customer.order.Length > 3)
            {
                errors.Add($"customer[{index}].order must contain between 1 and 3 colors");
                return;
            }

            foreach (var value in customer.order)
            {
                if (!IceCreamColorUtility.TryParse(value, out var color))
                {
                    errors.Add($"customer[{index}].order contains unknown color '{value}'");
                }
                else if (!unlocked.Contains(color))
                {
                    errors.Add($"customer[{index}].order uses locked color '{value}'");
                }
            }
        }
    }
}
