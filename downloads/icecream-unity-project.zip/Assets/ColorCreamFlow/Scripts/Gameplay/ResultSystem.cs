using ColorCreamFlow.Core;

namespace ColorCreamFlow.Gameplay
{
    public sealed class ResultSystem
    {
        public bool ShouldFailByCapacity(int activeProducts, int beltCapacity)
        {
            return activeProducts > beltCapacity;
        }

        public bool ShouldFailByProductionLimit(int producedCount, int maxProducts, bool allCustomersServed, bool hasPossibleBeltMatch)
        {
            return maxProducts > 0 && producedCount >= maxProducts && !allCustomersServed && !hasPossibleBeltMatch;
        }

        public void Success(int totalCoins)
        {
            GameEvents.RaiseLevelSuccess(totalCoins);
        }

        public void Fail(string reason)
        {
            GameEvents.RaiseLevelFail(reason);
        }
    }
}
