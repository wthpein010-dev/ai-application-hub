using System.Collections.Generic;
using System.Linq;
using ColorCreamFlow.Core;

namespace ColorCreamFlow.Gameplay
{
    public sealed class CustomerSystem
    {
        private readonly List<CustomerModel> customers = new List<CustomerModel>();

        public IReadOnlyList<CustomerModel> Customers => customers;

        public void Initialize(IEnumerable<CustomerConfig> configs)
        {
            customers.Clear();
            foreach (var config in configs ?? Enumerable.Empty<CustomerConfig>())
            {
                customers.Add(new CustomerModel(config));
            }
        }

        public IEnumerable<CustomerModel> WaitingCustomers()
        {
            return customers.Where(customer => customer.State == CustomerState.Waiting);
        }

        public bool AllServed()
        {
            return customers.Count > 0 && customers.All(customer => customer.State == CustomerState.Served);
        }
    }
}
