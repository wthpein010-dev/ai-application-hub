using System.Collections.Generic;
using System.Linq;
using ColorCreamFlow.Core;
using UnityEngine;

namespace ColorCreamFlow.Gameplay
{
    public sealed class ProductSystem
    {
        private readonly List<ProductModel> products = new List<ProductModel>();
        private int nextProductId = 1;

        public IReadOnlyList<ProductModel> Products => products;
        public int ProducedCount { get; private set; }

        public void Reset()
        {
            products.Clear();
            nextProductId = 1;
            ProducedCount = 0;
        }

        public ProductModel CreateCommittedProduct(IEnumerable<IceCreamColor> scoops)
        {
            var product = new ProductModel(nextProductId++, scoops, Time.time);
            product.CommitToBelt(0f);
            products.Add(product);
            ProducedCount++;
            GameEvents.RaiseProductConfirmed(product);
            GameEvents.RaiseProductEnteredBelt(product);
            return product;
        }

        public IEnumerable<ProductModel> ActiveOnBelt()
        {
            return products.Where(product => product.State == ProductState.OnBelt);
        }

        public int ActiveCount()
        {
            return products.Count(product => product.State == ProductState.OnBelt);
        }

        public void MarkSold(ProductModel product)
        {
            product.MarkSold();
        }

        public ProductModel DiscardOldest()
        {
            var product = ActiveOnBelt().OrderBy(item => item.SpawnTime).FirstOrDefault();
            if (product == null)
            {
                return null;
            }

            product.MarkDiscarded();
            return product;
        }
    }
}
