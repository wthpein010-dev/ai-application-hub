using System.Collections.Generic;
using System.Linq;
using ColorCreamFlow.Core;
using ColorCreamFlow.UI;
using ColorCreamFlow.Platform;
using UnityEngine;

namespace ColorCreamFlow.Gameplay
{
    public sealed class LevelController : MonoBehaviour
    {
        [SerializeField] private int startLevelId = 1;
        [SerializeField] private LevelGameplayView view;

        private readonly LevelConfigLoader configLoader = new LevelConfigLoader();
        private readonly MachineSystem machineSystem = new MachineSystem();
        private readonly ProductSystem productSystem = new ProductSystem();
        private readonly ConveyorSystem conveyorSystem = new ConveyorSystem();
        private readonly CustomerSystem customerSystem = new CustomerSystem();
        private readonly MatchingSystem matchingSystem = new MatchingSystem();
        private readonly ResultSystem resultSystem = new ResultSystem();

        private LevelConfig config;
        private LevelState state;
        private int coins;
        private int levelEarnedCoins;
        private int beltCapacityBonus;
        private GameProgressService progressService;
        private GameProgress progress;

        private void Awake()
        {
            if (view == null)
            {
                view = FindObjectOfType<LevelGameplayView>();
            }

            if (view == null)
            {
                var canvasObject = new GameObject("LevelGameplayCanvas");
                view = canvasObject.AddComponent<LevelGameplayView>();
            }

            view.Build();
            progressService = new GameProgressService(PlatformBootstrap.CreateStorage());
            progress = progressService.Load();
            BindViewEvents();
            StartLevel(Mathf.Clamp(progress.currentLevel, 1, 10));
        }

        private void Update()
        {
            if (state != LevelState.Playing && state != LevelState.Ready)
            {
                return;
            }

            conveyorSystem.Tick(Time.deltaTime);
            foreach (var product in productSystem.ActiveOnBelt())
            {
                view.UpdateBeltProductPosition(product);
            }

            TryServeCustomers();
            EvaluateEndConditions();
        }

        public void StartLevel(int levelId)
        {
            state = LevelState.Init;
            config = configLoader.Load(levelId);
            coins = progress != null && progress.coins > 0 ? progress.coins : config.startingCoins;
            levelEarnedCoins = 0;
            beltCapacityBonus = 0;

            productSystem.Reset();
            machineSystem.Initialize(config.unlockedColors);
            customerSystem.Initialize(config.customers);
            conveyorSystem.Initialize(productSystem, config.beltSpeed);

            view.HideResult();
            view.RenderLevel(config);
            view.RenderMachines(machineSystem.UnlockedColors);
            view.SetBuildingScoops(machineSystem.BuildingScoops);
            view.RenderCustomers(customerSystem.Customers);
            RefreshCounters();

            state = LevelState.Ready;
        }

        private void BindViewEvents()
        {
            view.MachineClicked += HandleMachineClicked;
            view.ConfirmClicked += HandleConfirmClicked;
            view.UndoClicked += HandleUndoClicked;
            view.RemoveClicked += HandleRemoveClicked;
            view.CapacityClicked += HandleCapacityClicked;
            view.RestartClicked += () => StartLevel(config != null ? config.levelId : startLevelId);
            view.NextLevelClicked += HandleNextLevelClicked;
        }

        private void HandleMachineClicked(IceCreamColor color)
        {
            if (state == LevelState.Failed || state == LevelState.Success)
            {
                return;
            }

            state = LevelState.Playing;
            if (machineSystem.TryAddScoop(color))
            {
                view.SetBuildingScoops(machineSystem.BuildingScoops);
            }
        }

        private void HandleConfirmClicked()
        {
            if (state == LevelState.Failed || state == LevelState.Success || !machineSystem.CanConfirm())
            {
                return;
            }

            if (config.maxProductsToMake > 0 && productSystem.ProducedCount >= config.maxProductsToMake)
            {
                EvaluateEndConditions();
                return;
            }

            state = LevelState.Playing;
            var scoops = machineSystem.ConsumeBuildingScoops();
            var product = productSystem.CreateCommittedProduct(scoops);
            view.SetBuildingScoops(machineSystem.BuildingScoops);
            view.AddBeltProduct(product);
            RefreshCounters();
            EvaluateEndConditions();
        }

        private void HandleUndoClicked()
        {
            machineSystem.UndoLastScoop();
            view.SetBuildingScoops(machineSystem.BuildingScoops);
        }

        private void HandleRemoveClicked()
        {
            var discarded = productSystem.DiscardOldest();
            if (discarded != null)
            {
                view.RemoveBeltProduct(discarded.ProductId);
            }

            RefreshCounters();
        }

        private void HandleCapacityClicked()
        {
            beltCapacityBonus++;
            RefreshCounters();
        }

        private void TryServeCustomers()
        {
            var candidates = productSystem
                .ActiveOnBelt()
                .Where(product => conveyorSystem.IsInJudgeZone(product, config.judgeZoneCenter, config.judgeZoneRadius))
                .ToList();

            if (candidates.Count == 0)
            {
                return;
            }

            foreach (var customer in customerSystem.WaitingCustomers().ToList())
            {
                var matched = matchingSystem.FindMatch(customer, candidates);
                if (matched == null)
                {
                    continue;
                }

                customer.MarkServed();
                productSystem.MarkSold(matched);
                candidates.Remove(matched);
                view.RemoveBeltProduct(matched.ProductId);
                coins += customer.Value;
                levelEarnedCoins += customer.Value;
                GameEvents.RaiseCustomerServed(customer, matched, customer.Value);
                view.SetCoins(coins);
                view.RenderCustomers(customerSystem.Customers);
                RefreshCounters();
            }
        }

        private void EvaluateEndConditions()
        {
            if (state == LevelState.Failed || state == LevelState.Success)
            {
                return;
            }

            if (customerSystem.AllServed())
            {
                state = LevelState.Success;
                resultSystem.Success(levelEarnedCoins);
                progress.coins = coins;
                progressService.Save(progress);
                progress = progressService.UnlockAfterSuccess(config.levelId);
                view.ShowSuccess(levelEarnedCoins);
                return;
            }

            var capacity = EffectiveBeltCapacity();
            var activeCount = productSystem.ActiveCount();
            if (resultSystem.ShouldFailByCapacity(activeCount, capacity))
            {
                state = LevelState.Failed;
                resultSystem.Fail("BELT_OVERFLOW");
                view.ShowFail("Belt overflow");
                return;
            }

            if (activeCount >= capacity)
            {
                GameEvents.RaiseCapacityWarning(activeCount, capacity);
            }

            if (resultSystem.ShouldFailByProductionLimit(productSystem.ProducedCount, config.maxProductsToMake, customerSystem.AllServed(), HasPossibleBeltMatch()))
            {
                state = LevelState.Failed;
                resultSystem.Fail("OUT_OF_PRODUCE_LIMIT");
                view.ShowFail("No products left");
            }
        }

        private void HandleNextLevelClicked()
        {
            var nextLevel = Mathf.Clamp(config.levelId + 1, 1, 10);
            progress.currentLevel = nextLevel;
            progressService.Save(progress);
            StartLevel(nextLevel);
        }

        private void RefreshCounters()
        {
            view.SetCapacity(productSystem.ActiveCount(), EffectiveBeltCapacity());
            view.SetProduction(productSystem.ProducedCount, config.maxProductsToMake);
        }

        private int EffectiveBeltCapacity()
        {
            return config.beltCapacity + beltCapacityBonus;
        }

        private bool HasPossibleBeltMatch()
        {
            var activeProducts = productSystem.ActiveOnBelt().ToList();
            if (activeProducts.Count == 0)
            {
                return false;
            }

            return customerSystem.WaitingCustomers().Any(customer => matchingSystem.FindMatch(customer, activeProducts) != null);
        }
    }
}
