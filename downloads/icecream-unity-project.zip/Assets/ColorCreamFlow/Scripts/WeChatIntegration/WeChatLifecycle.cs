using UnityEngine;
using WeChatWASM;

namespace ColorCreamFlow.WeChat
{
    public static class WeChatLifecycle
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Initialize()
        {
            WX.GetSystemInfoSync();
            WX.OnHide(_ => AudioListener.pause = true);
            WX.OnShow(_ => AudioListener.pause = false);
        }
    }
}
