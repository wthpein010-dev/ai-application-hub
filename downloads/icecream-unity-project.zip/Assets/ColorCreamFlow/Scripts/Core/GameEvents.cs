using System;
using ColorCreamFlow.Core;

namespace ColorCreamFlow.Core
{
    public static class GameEvents
    {
        public static event Action<IceCreamColor> ScoopAdded;
        public static event Action<ProductModel> ProductConfirmed;
        public static event Action<ProductModel> ProductEnteredBelt;
        public static event Action<CustomerModel, ProductModel, int> CustomerServed;
        public static event Action<int, int> CapacityWarning;
        public static event Action<int> LevelSuccess;
        public static event Action<string> LevelFail;

        public static void RaiseScoopAdded(IceCreamColor color) => ScoopAdded?.Invoke(color);
        public static void RaiseProductConfirmed(ProductModel product) => ProductConfirmed?.Invoke(product);
        public static void RaiseProductEnteredBelt(ProductModel product) => ProductEnteredBelt?.Invoke(product);
        public static void RaiseCustomerServed(CustomerModel customer, ProductModel product, int value) => CustomerServed?.Invoke(customer, product, value);
        public static void RaiseCapacityWarning(int current, int max) => CapacityWarning?.Invoke(current, max);
        public static void RaiseLevelSuccess(int totalCoins) => LevelSuccess?.Invoke(totalCoins);
        public static void RaiseLevelFail(string reason) => LevelFail?.Invoke(reason);
    }
}
