using System;

namespace ColorCreamFlow.Core
{
    [Serializable]
    public sealed class LevelConfig
    {
        public int levelId;
        public string displayName;
        public string[] unlockedColors;
        public CustomerConfig[] customers;
        public int maxProductsToMake = 8;
        public int beltCapacity = 6;
        public float beltSpeed = 0.08f;
        public float judgeZoneCenter = 0.5f;
        public float judgeZoneRadius = 0.25f;
        public string matchPolicy = "FIFO";
        public int startingCoins = 9999;
    }

    [Serializable]
    public sealed class CustomerConfig
    {
        public string id;
        public string customerSprite;
        public string[] order;
        public bool orderStrict;
        public int value;
        public bool isKey;
        public float patience;
    }
}
