using System;
using UnityEngine;

namespace ColorCreamFlow.Core
{
    public enum IceCreamColor
    {
        Pink,
        Yellow,
        Blue,
        Green
    }

    public static class IceCreamColorUtility
    {
        public static bool TryParse(string value, out IceCreamColor color)
        {
            return Enum.TryParse(value, true, out color);
        }

        public static Color ToUnityColor(this IceCreamColor color)
        {
            switch (color)
            {
                case IceCreamColor.Yellow:
                    return new Color(1f, 0.82f, 0.12f);
                case IceCreamColor.Blue:
                    return new Color(0.19f, 0.66f, 1f);
                case IceCreamColor.Green:
                    return new Color(0.42f, 0.95f, 0.16f);
                default:
                    return new Color(1f, 0.29f, 0.58f);
            }
        }

        public static string ToDisplayName(this IceCreamColor color)
        {
            return color.ToString();
        }
    }
}
