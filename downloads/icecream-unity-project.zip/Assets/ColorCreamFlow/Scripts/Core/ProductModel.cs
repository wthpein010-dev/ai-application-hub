using System;
using System.Collections.Generic;

namespace ColorCreamFlow.Core
{
    public enum ProductState
    {
        Building,
        OnBelt,
        Sold,
        Discarded
    }

    public sealed class ProductModel
    {
        public int ProductId { get; }
        public List<IceCreamColor> Scoops { get; }
        public ProductState State { get; private set; }
        public float SpawnTime { get; }
        public float BeltPosition { get; private set; }

        public ProductModel(int productId, IEnumerable<IceCreamColor> scoops, float spawnTime)
        {
            ProductId = productId;
            Scoops = new List<IceCreamColor>(scoops);
            SpawnTime = spawnTime;
            State = ProductState.Building;
        }

        public void CommitToBelt(float position)
        {
            State = ProductState.OnBelt;
            BeltPosition = Normalize(position);
        }

        public void Move(float delta)
        {
            BeltPosition = Normalize(BeltPosition + delta);
        }

        public void MarkSold()
        {
            State = ProductState.Sold;
        }

        public void MarkDiscarded()
        {
            State = ProductState.Discarded;
        }

        private static float Normalize(float value)
        {
            value %= 1f;
            return value < 0f ? value + 1f : value;
        }
    }
}
