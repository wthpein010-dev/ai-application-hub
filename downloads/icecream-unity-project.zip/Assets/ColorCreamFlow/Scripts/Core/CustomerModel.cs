using System.Collections.Generic;
using System.Linq;

namespace ColorCreamFlow.Core
{
    public enum CustomerState
    {
        Waiting,
        Served,
        Left
    }

    public sealed class CustomerModel
    {
        public string Id { get; }
        public string SpriteName { get; }
        public List<IceCreamColor> Order { get; }
        public bool OrderStrict { get; }
        public int Value { get; }
        public bool IsKey { get; }
        public CustomerState State { get; private set; }

        public CustomerModel(CustomerConfig config)
        {
            Id = config.id;
            SpriteName = config.customerSprite;
            Order = ParseOrder(config.order);
            OrderStrict = config.orderStrict;
            Value = config.value;
            IsKey = config.isKey;
            State = CustomerState.Waiting;
        }

        public void MarkServed()
        {
            State = CustomerState.Served;
        }

        private static List<IceCreamColor> ParseOrder(IEnumerable<string> order)
        {
            return order
                .Where(value => IceCreamColorUtility.TryParse(value, out _))
                .Select(value =>
                {
                    IceCreamColorUtility.TryParse(value, out var color);
                    return color;
                })
                .ToList();
        }
    }
}
