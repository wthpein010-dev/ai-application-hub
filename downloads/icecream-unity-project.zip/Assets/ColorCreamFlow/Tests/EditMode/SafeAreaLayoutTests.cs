using ColorCreamFlow.UI;
using NUnit.Framework;
using UnityEngine;

namespace ColorCreamFlow.Tests
{
    public sealed class SafeAreaLayoutTests
    {
        [Test]
        public void FullReferenceScreenUsesFullAnchors()
        {
            var anchors = SafeAreaFitter.CalculateAnchors(new Rect(0, 0, 750, 1624), new Vector2Int(750, 1624));

            Assert.That(anchors, Is.EqualTo(new Vector4(0f, 0f, 1f, 1f)));
        }

        [Test]
        public void TallPhoneSafeAreaNormalizesTopAndBottomInsets()
        {
            var anchors = SafeAreaFitter.CalculateAnchors(new Rect(0, 80, 1170, 2372), new Vector2Int(1170, 2532));

            Assert.That(anchors.x, Is.EqualTo(0f).Within(0.0001f));
            Assert.That(anchors.y, Is.EqualTo(80f / 2532f).Within(0.0001f));
            Assert.That(anchors.z, Is.EqualTo(1f).Within(0.0001f));
            Assert.That(anchors.w, Is.EqualTo(2452f / 2532f).Within(0.0001f));
        }

        [Test]
        public void InvalidScreenSizeReturnsFullAnchors()
        {
            Assert.That(SafeAreaFitter.CalculateAnchors(Rect.zero, Vector2Int.zero),
                Is.EqualTo(new Vector4(0f, 0f, 1f, 1f)));
        }
    }
}
