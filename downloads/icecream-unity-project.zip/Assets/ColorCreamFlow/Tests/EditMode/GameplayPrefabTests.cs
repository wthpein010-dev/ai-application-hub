using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace ColorCreamFlow.Tests
{
    public sealed class GameplayPrefabTests
    {
        [Test]
        public void GameplayCanvasPrefabUsesRequiredReferenceResolution()
        {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(
                "Assets/ColorCreamFlow/Prefabs/UI/GameplayCanvas.prefab");

            Assert.That(prefab, Is.Not.Null);
            var scaler = prefab.GetComponent<CanvasScaler>();
            Assert.That(scaler, Is.Not.Null);
            Assert.That(scaler.referenceResolution, Is.EqualTo(new Vector2(750f, 1624f)));
        }

        [Test]
        public void GameplayCanvasPrefabExposesEditablePanels()
        {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(
                "Assets/ColorCreamFlow/Prefabs/UI/GameplayCanvas.prefab");

            Assert.That(prefab.transform.Find("SafeArea/Customers"), Is.Not.Null);
            Assert.That(prefab.transform.Find("SafeArea/BeltTrack"), Is.Not.Null);
            Assert.That(prefab.transform.Find("SafeArea/MachineButtons"), Is.Not.Null);
            Assert.That(prefab.transform.Find("SafeArea/Footer"), Is.Not.Null);
            Assert.That(prefab.transform.Find("SafeArea/ResultPopup"), Is.Not.Null);
        }
    }
}
