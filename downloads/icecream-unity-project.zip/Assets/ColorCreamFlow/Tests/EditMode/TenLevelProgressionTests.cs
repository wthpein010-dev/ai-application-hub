using System.Linq;
using ColorCreamFlow.Gameplay;
using NUnit.Framework;

namespace ColorCreamFlow.Tests
{
    public sealed class TenLevelProgressionTests
    {
        [Test]
        public void LoadsTenDistinctValidLevels()
        {
            var loader = new LevelConfigLoader();

            for (var levelId = 1; levelId <= 10; levelId++)
            {
                var config = loader.Load(levelId);
                Assert.That(config.levelId, Is.EqualTo(levelId), $"Level {levelId:000} resolved to the wrong file.");
                Assert.That(LevelConfigValidator.Validate(config), Is.Empty);
            }
        }

        [Test]
        public void LaterLevelsIntroduceStrictOrders()
        {
            var loader = new LevelConfigLoader();

            var hasStrictOrder = Enumerable.Range(6, 5)
                .SelectMany(id => loader.Load(id).customers)
                .Any(customer => customer.orderStrict);

            Assert.That(hasStrictOrder, Is.True);
        }
    }
}
