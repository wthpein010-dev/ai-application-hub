using System.Collections.Generic;
using ColorCreamFlow.Platform;
using NUnit.Framework;

namespace ColorCreamFlow.Tests
{
    public sealed class GameProgressServiceTests
    {
        [Test]
        public void FirstLaunchStartsAtLevelOne()
        {
            var service = new GameProgressService(new MemoryStorage());

            var progress = service.Load();

            Assert.That(progress.highestUnlockedLevel, Is.EqualTo(1));
            Assert.That(progress.currentLevel, Is.EqualTo(1));
            Assert.That(progress.coins, Is.EqualTo(0));
        }

        [Test]
        public void SaveAndLoadRoundTripsProgress()
        {
            var storage = new MemoryStorage();
            var service = new GameProgressService(storage);
            service.Save(new GameProgress { highestUnlockedLevel = 4, currentLevel = 3, coins = 125 });

            var progress = service.Load();

            Assert.That(progress.highestUnlockedLevel, Is.EqualTo(4));
            Assert.That(progress.currentLevel, Is.EqualTo(3));
            Assert.That(progress.coins, Is.EqualTo(125));
        }

        [Test]
        public void UnlockAfterSuccessCapsAtLevelTen()
        {
            var storage = new MemoryStorage();
            var service = new GameProgressService(storage);
            service.Save(new GameProgress { highestUnlockedLevel = 10, currentLevel = 10, coins = 80 });

            var progress = service.UnlockAfterSuccess(10);

            Assert.That(progress.highestUnlockedLevel, Is.EqualTo(10));
            Assert.That(progress.currentLevel, Is.EqualTo(10));
        }

        [Test]
        public void CorruptedJsonFallsBackToDefaults()
        {
            var storage = new MemoryStorage();
            storage.SetString(GameProgressService.StorageKey, "not-json");

            var progress = new GameProgressService(storage).Load();

            Assert.That(progress.highestUnlockedLevel, Is.EqualTo(1));
            Assert.That(progress.currentLevel, Is.EqualTo(1));
        }

        private sealed class MemoryStorage : IGameStorage
        {
            private readonly Dictionary<string, string> values = new Dictionary<string, string>();

            public string GetString(string key, string fallback)
            {
                return values.TryGetValue(key, out var value) ? value : fallback;
            }

            public void SetString(string key, string value)
            {
                values[key] = value;
            }
        }
    }
}
