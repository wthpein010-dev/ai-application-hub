using ColorCreamFlow.Core;
using ColorCreamFlow.Gameplay;
using NUnit.Framework;

namespace ColorCreamFlow.Tests
{
    public sealed class MatchingAndMachineTests
    {
        [Test]
        public void MachineRejectsFourthScoop()
        {
            var machine = new MachineSystem();
            machine.Initialize(new[] { "Pink" });

            Assert.That(machine.TryAddScoop(IceCreamColor.Pink), Is.True);
            Assert.That(machine.TryAddScoop(IceCreamColor.Pink), Is.True);
            Assert.That(machine.TryAddScoop(IceCreamColor.Pink), Is.True);
            Assert.That(machine.TryAddScoop(IceCreamColor.Pink), Is.False);
        }

        [Test]
        public void UnorderedCustomerMatchesSameColorMultiset()
        {
            var customer = new CustomerModel(new CustomerConfig
            {
                id = "A",
                order = new[] { "Pink", "Blue", "Pink" },
                orderStrict = false
            });
            var product = new ProductModel(1, new[]
            {
                IceCreamColor.Blue,
                IceCreamColor.Pink,
                IceCreamColor.Pink
            }, 0f);

            Assert.That(new MatchingSystem().FindMatch(customer, new[] { product }), Is.SameAs(product));
        }

        [Test]
        public void StrictCustomerRejectsDifferentOrder()
        {
            var customer = new CustomerModel(new CustomerConfig
            {
                id = "A",
                order = new[] { "Pink", "Blue" },
                orderStrict = true
            });
            var product = new ProductModel(1, new[] { IceCreamColor.Blue, IceCreamColor.Pink }, 0f);

            Assert.That(new MatchingSystem().FindMatch(customer, new[] { product }), Is.Null);
        }
    }
}
