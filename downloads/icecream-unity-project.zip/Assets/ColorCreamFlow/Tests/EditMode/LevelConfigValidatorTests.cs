using System.Linq;
using ColorCreamFlow.Core;
using ColorCreamFlow.Gameplay;
using NUnit.Framework;

namespace ColorCreamFlow.Tests
{
    public sealed class LevelConfigValidatorTests
    {
        [Test]
        public void Validate_ReportsMissingCustomers()
        {
            var config = ValidConfig();
            config.customers = new CustomerConfig[0];

            var errors = LevelConfigValidator.Validate(config);

            Assert.That(errors, Has.Some.Contains("customer"));
        }

        [Test]
        public void Validate_ReportsNonPositiveBeltCapacity()
        {
            var config = ValidConfig();
            config.beltCapacity = 0;

            var errors = LevelConfigValidator.Validate(config);

            Assert.That(errors, Has.Some.Contains("beltCapacity"));
        }

        [Test]
        public void Validate_ReportsProductionLimitBelowCustomerCount()
        {
            var config = ValidConfig();
            config.maxProductsToMake = 1;
            config.customers = new[] { Customer("A"), Customer("B") };

            var errors = LevelConfigValidator.Validate(config);

            Assert.That(errors, Has.Some.Contains("maxProductsToMake"));
        }

        [Test]
        public void Validate_AcceptsValidConfig()
        {
            Assert.That(LevelConfigValidator.Validate(ValidConfig()), Is.Empty);
        }

        private static LevelConfig ValidConfig()
        {
            return new LevelConfig
            {
                levelId = 1,
                displayName = "Level 1",
                unlockedColors = new[] { "Pink", "Yellow" },
                customers = new[] { Customer("A") },
                maxProductsToMake = 2,
                beltCapacity = 3,
                beltSpeed = 0.1f,
                judgeZoneCenter = 0.5f,
                judgeZoneRadius = 0.2f
            };
        }

        private static CustomerConfig Customer(string id)
        {
            return new CustomerConfig
            {
                id = id,
                order = new[] { "Pink" },
                value = 10
            };
        }
    }
}
