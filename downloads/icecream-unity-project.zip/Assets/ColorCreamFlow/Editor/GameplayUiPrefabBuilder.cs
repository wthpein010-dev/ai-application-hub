using ColorCreamFlow.Gameplay;
using ColorCreamFlow.UI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace ColorCreamFlow.Editor
{
    public static class GameplayUiPrefabBuilder
    {
        private const string PrefabFolder = "Assets/ColorCreamFlow/Prefabs/UI";
        private const string PrefabPath = PrefabFolder + "/GameplayCanvas.prefab";
        private const string ScenePath = "Assets/ColorCreamFlow/Scenes/LevelGameplay.unity";

        [MenuItem("Color Cream Flow/Rebuild Editable Gameplay UI")]
        public static void Rebuild()
        {
            EnsureFolder("Assets/ColorCreamFlow/Prefabs", "UI");

            var canvasObject = new GameObject("GameplayCanvas");
            var view = canvasObject.AddComponent<LevelGameplayView>();
            view.Build();
            PrefabUtility.SaveAsPrefabAsset(canvasObject, PrefabPath);
            Object.DestroyImmediate(canvasObject);

            var scene = EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
            var existing = GameObject.Find("GameplayCanvas");
            if (existing != null)
            {
                Object.DestroyImmediate(existing);
            }

            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
            var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab, scene);
            instance.name = "GameplayCanvas";

            var controller = Object.FindObjectOfType<LevelController>();
            var serializedController = new SerializedObject(controller);
            serializedController.FindProperty("view").objectReferenceValue = instance.GetComponent<LevelGameplayView>();
            serializedController.ApplyModifiedPropertiesWithoutUndo();

            EditorSceneManager.MarkSceneDirty(scene);
            EditorSceneManager.SaveScene(scene);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        private static void EnsureFolder(string parent, string child)
        {
            var path = parent + "/" + child;
            if (!AssetDatabase.IsValidFolder(path))
            {
                AssetDatabase.CreateFolder(parent, child);
            }
        }
    }
}
