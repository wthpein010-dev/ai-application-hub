using MCPForUnity.Editor.Services;
using UnityEditor;
using UnityEngine;

namespace ColorCreamFlow.Editor
{
    [InitializeOnLoad]
    internal static class UnityMcpAutoConnect
    {
        private const string SessionKey = "ColorCreamFlow.UnityMcpAutoConnect";

        static UnityMcpAutoConnect()
        {
            if (Application.isBatchMode)
            {
                return;
            }

            EditorPrefs.SetBool("MCPForUnity.UseHttpTransport", true);
            EditorPrefs.SetBool("MCPForUnity.AutoStartOnLoad", true);

            if (SessionState.GetBool(SessionKey, false))
            {
                return;
            }

            SessionState.SetBool(SessionKey, true);
            EditorApplication.delayCall += Connect;
        }

        private static async void Connect()
        {
            if (!MCPServiceLocator.Bridge.IsRunning)
            {
                await MCPServiceLocator.Bridge.StartAsync();
            }
        }
    }
}
