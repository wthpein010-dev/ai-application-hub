#if UNITY_EDITOR
using System.IO;
using ColorCreamFlow.Gameplay;
using ColorCreamFlow.UI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

namespace ColorCreamFlow.Editor
{
    public static class ColorCreamFlowProjectBootstrapper
    {
        private const string ScenePath = "Assets/ColorCreamFlow/Scenes/LevelGameplay.unity";
        private const string PrefabFolder = "Assets/ColorCreamFlow/Prefabs";
        private const string ArtFolder = "Assets/ColorCreamFlow/Resources/Art";

        [InitializeOnLoadMethod]
        private static void AutoBootstrap()
        {
            EditorApplication.delayCall += () =>
            {
                if (Application.isPlaying)
                {
                    return;
                }

                ImportArtAsSprites();

                if (!File.Exists(ScenePath))
                {
                    BuildGameplayScene(openSceneAfterBuild: true);
                }
                else
                {
                    EnsureBuildSettings();
                    EnsureEditorStartScene();
                    OpenGameplaySceneIfEmpty();
                }

                EnsureStarterPrefabs();
            };
        }

        [MenuItem("Color Cream Flow/Rebuild Gameplay Scene And Prefabs")]
        public static void RebuildAll()
        {
            ImportArtAsSprites();
            BuildGameplayScene(openSceneAfterBuild: true);
            EnsureStarterPrefabs();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("Color Cream Flow scene and prefabs rebuilt.");
        }

        [MenuItem("Color Cream Flow/Open Gameplay Scene")]
        public static void OpenGameplayScene()
        {
            EnsureBuildSettings();
            EnsureEditorStartScene();
            EditorSceneManager.OpenScene(ScenePath);
        }

        private static void ImportArtAsSprites()
        {
            var guids = AssetDatabase.FindAssets("t:Texture2D", new[] { ArtFolder });
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var importer = AssetImporter.GetAtPath(path) as TextureImporter;
                if (importer == null || importer.textureType == TextureImporterType.Sprite)
                {
                    continue;
                }

                importer.textureType = TextureImporterType.Sprite;
                importer.spriteImportMode = SpriteImportMode.Single;
                importer.alphaIsTransparency = true;
                importer.mipmapEnabled = false;
                importer.filterMode = FilterMode.Bilinear;
                importer.textureCompression = TextureImporterCompression.Uncompressed;
                importer.SaveAndReimport();
            }
        }

        private static void BuildGameplayScene(bool openSceneAfterBuild)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(ScenePath));

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            scene.name = "LevelGameplay";

            var camera = new GameObject("Main Camera");
            camera.tag = "MainCamera";
            var cameraComponent = camera.AddComponent<Camera>();
            cameraComponent.clearFlags = CameraClearFlags.SolidColor;
            cameraComponent.backgroundColor = new Color(0.16f, 0.15f, 0.2f);
            cameraComponent.orthographic = true;
            camera.transform.position = new Vector3(0f, 0f, -10f);

            var eventSystem = new GameObject("EventSystem");
            eventSystem.AddComponent<EventSystem>();
            eventSystem.AddComponent<StandaloneInputModule>();

            var canvasObject = new GameObject("LevelGameplayCanvas");
            var view = canvasObject.AddComponent<LevelGameplayView>();

            var controllerObject = new GameObject("LevelController");
            var controller = controllerObject.AddComponent<LevelController>();
            var serialized = new SerializedObject(controller);
            serialized.FindProperty("view").objectReferenceValue = view;
            serialized.ApplyModifiedPropertiesWithoutUndo();

            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            EnsureEditorStartScene();

            if (openSceneAfterBuild)
            {
                EditorSceneManager.OpenScene(ScenePath);
            }
        }

        private static void EnsureBuildSettings()
        {
            var sceneGuid = AssetDatabase.AssetPathToGUID(ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            if (string.IsNullOrEmpty(sceneGuid))
            {
                Debug.LogWarning($"Gameplay scene guid not found for {ScenePath}.");
            }
        }

        private static void EnsureEditorStartScene()
        {
            var sceneAsset = AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath);
            if (sceneAsset != null)
            {
                EditorSceneManager.playModeStartScene = sceneAsset;
            }
        }

        private static void OpenGameplaySceneIfEmpty()
        {
            var activeScene = EditorSceneManager.GetActiveScene();
            if (activeScene.path == ScenePath)
            {
                return;
            }

            var isUntitledScene = string.IsNullOrEmpty(activeScene.path);
            if (isUntitledScene)
            {
                EditorSceneManager.OpenScene(ScenePath);
            }
        }

        private static void EnsureStarterPrefabs()
        {
            Directory.CreateDirectory(PrefabFolder);
            var catalog = new SpriteResourceCatalog();

            SavePrefab("CustomerView.prefab", root =>
            {
                var view = root.AddComponent<CustomerView>();
                view.Build(catalog);
            });

            SavePrefab("IceCreamProductView.prefab", root =>
            {
                IceCreamProductView.Create("IceCreamProductView", root.transform, catalog, new Vector2(100f, 130f));
            });

            SavePrefab("MachineButtonView.prefab", root =>
            {
                root.AddComponent<RectTransform>().sizeDelta = new Vector2(112f, 112f);
                var view = root.AddComponent<MachineButtonView>();
                view.Build(catalog, Core.IceCreamColor.Pink, null);
            });

            SavePrefab("ResultPopupView.prefab", root =>
            {
                var rect = root.AddComponent<RectTransform>();
                rect.sizeDelta = new Vector2(720f, 1280f);
                var view = root.AddComponent<ResultPopupView>();
                view.Build(catalog);
            });
        }

        private static void SavePrefab(string fileName, System.Action<GameObject> build)
        {
            var path = $"{PrefabFolder}/{fileName}";
            var root = new GameObject(Path.GetFileNameWithoutExtension(fileName));
            build(root);
            PrefabUtility.SaveAsPrefabAsset(root, path);
            Object.DestroyImmediate(root);
        }
    }
}
#endif
