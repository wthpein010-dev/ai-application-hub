using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using WeChatWASM;

namespace ColorCreamFlow.Editor
{
    public static class ReleaseBuildPipeline
    {
        private const string ScenePath = "Assets/ColorCreamFlow/Scenes/LevelGameplay.unity";
        private const string WeChatDefine = "ICECREAM_WECHAT";

        [MenuItem("Color Cream Flow/Build/WebGL Preview")]
        public static void BuildWebGlPreview()
        {
            SetWeChatCompilation(false);
            WeChatBuildValidator.ConfigureProject();
            PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled;
            PlayerSettings.WebGL.dataCaching = true;

            var output = AbsolutePath("Builds/WebGLPreview");
            Directory.CreateDirectory(output);
            var report = BuildPipeline.BuildPlayer(
                new[] { ScenePath },
                output,
                BuildTarget.WebGL,
                BuildOptions.None);

            if (report.summary.result != BuildResult.Succeeded)
            {
                throw new InvalidOperationException($"WebGL preview build failed: {report.summary.result}");
            }

            InstallWebGlPreviewBridge(output);
            Debug.Log($"IceCream WebGL preview built: {output}");
        }

        [MenuItem("Color Cream Flow/Build/WeChat Mini Game")]
        public static void BuildWeChatMiniGame()
        {
            if (!HasWeChatCompilation())
            {
                throw new InvalidOperationException(
                    "Run Configure WeChat Compilation, allow Unity to recompile, then build again.");
            }

            WeChatBuildValidator.ConfigureProject();
            ConfigureWeChatExporter();
            var result = WXConvertCore.DoExport(true);
            if (result != WXConvertCore.WXExportError.SUCCEED)
            {
                throw new InvalidOperationException($"WeChat mini-game export failed: {result}");
            }

            Debug.Log($"IceCream WeChat mini-game built: {AbsolutePath("Builds/WeChat/minigame")}");
        }

        [MenuItem("Color Cream Flow/Build/Configure WeChat Compilation")]
        public static void ConfigureWeChatCompilation()
        {
            SetWeChatCompilation(true);
            Debug.Log("IceCream WeChat compilation enabled. Build after script reload completes.");
        }

        [MenuItem("Color Cream Flow/Build/Configure WebGL Compilation")]
        public static void ConfigureWebGlCompilation()
        {
            SetWeChatCompilation(false);
            Debug.Log("IceCream WebGL compilation enabled. Build after script reload completes.");
        }

        [MenuItem("Color Cream Flow/Build/Validate Release Outputs")]
        public static void ValidateReleaseOutputs()
        {
            WeChatBuildValidator.ValidateOrThrow();
            RequireFile("Builds/WebGLPreview/index.html");
            RequireFile("Builds/WeChat/minigame/game.json");
            RequireFile("Builds/WeChat/minigame/project.config.json");
            Debug.Log("IceCream release output validation passed.");
        }

        private static void ConfigureWeChatExporter()
        {
            var config = UnityUtil.GetEditorConf();
            var relativeOutput = "Builds/WeChat";
            config.ProjectConf.projectName = "IceCream";
            config.ProjectConf.relativeDST = relativeOutput;
            config.ProjectConf.DST = AbsolutePath(relativeOutput);
            config.ProjectConf.assetLoadType = 1;
            config.ProjectConf.compressDataPackage = false;
            config.CompileOptions.DevelopBuild = false;
            config.CompileOptions.CleanBuild = true;
            config.CompileOptions.autoAdaptScreen = true;
            config.CompileOptions.enableRenderThread = false;
            EditorUtility.SetDirty(config);
            AssetDatabase.SaveAssets();
        }

        private static void InstallWebGlPreviewBridge(string output)
        {
            const string bridgeName = "icecream-preview-bridge.js";
            const string bridge = @"(function () {
  var prefix = 'icecream:';
  var storage = {
    WXStorageSetIntSync: function (key, value) { localStorage.setItem(prefix + key, String(value)); },
    WXStorageGetIntSync: function (key, fallback) { var value = localStorage.getItem(prefix + key); return value === null ? fallback : parseInt(value, 10); },
    WXStorageSetFloatSync: function (key, value) { localStorage.setItem(prefix + key, String(value)); },
    WXStorageGetFloatSync: function (key, fallback) { var value = localStorage.getItem(prefix + key); return value === null ? fallback : parseFloat(value); },
    WXStorageSetStringSync: function (key, value) { localStorage.setItem(prefix + key, value); },
    WXStorageGetStringSync: function (key, fallback) { var value = localStorage.getItem(prefix + key); return value === null ? fallback : value; },
    WXStorageDeleteKeySync: function (key) { localStorage.removeItem(prefix + key); },
    WXStorageHasKeySync: function (key) { return localStorage.getItem(prefix + key) !== null; },
    WXStorageDeleteAllSync: function () {
      Object.keys(localStorage).filter(function (key) { return key.indexOf(prefix) === 0; }).forEach(function (key) { localStorage.removeItem(key); });
    }
  };
  window.WXWASMSDK = new Proxy(storage, {
    get: function (target, property) {
      if (property in target) return target[property];
      return function () { return ''; };
    }
  });
})();";

            File.WriteAllText(Path.Combine(output, bridgeName), bridge);
            var indexPath = Path.Combine(output, "index.html");
            var html = File.ReadAllText(indexPath);
            var script = $"<script src=\"{bridgeName}\"></script>";
            const string portraitStyle = @"<style>
html, body { width: 100%; height: 100%; margin: 0; overflow: hidden; background: #f7f0ff; }
body { display: flex; align-items: center; justify-content: center; }
#unity-container, #unity-container.unity-desktop, #unity-container.unity-mobile {
  position: relative; left: auto; top: auto; transform: none;
  width: min(100vw, calc(100vh * 750 / 1624));
  height: min(100vh, calc(100vw * 1624 / 750));
}
#unity-canvas { width: 100% !important; height: 100% !important; background: #f7f0ff; }
#unity-footer, #unity-warning { display: none !important; }
</style>";
            if (!html.Contains(script))
            {
                html = html.Replace("</head>", $"  {script}\n</head>");
            }

            if (!html.Contains("width: min(100vw, calc(100vh * 750 / 1624))"))
            {
                html = html.Replace("</head>", $"{portraitStyle}\n</head>");
            }

            File.WriteAllText(indexPath, html);
        }

        private static string AbsolutePath(string relativePath)
        {
            var root = Directory.GetParent(Application.dataPath)?.FullName
                ?? throw new InvalidOperationException("Unity project root could not be resolved.");
            return Path.GetFullPath(Path.Combine(root, relativePath));
        }

        private static void RequireFile(string relativePath)
        {
            if (!File.Exists(AbsolutePath(relativePath)))
            {
                throw new FileNotFoundException($"Required release output is missing: {relativePath}");
            }
        }

        private static bool HasWeChatCompilation()
        {
            var symbols = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.WebGL);
            return symbols.Split(';').Any(symbol => symbol == WeChatDefine);
        }

        private static void SetWeChatCompilation(bool enabled)
        {
            var symbols = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.WebGL)
                .Split(';')
                .Where(symbol => !string.IsNullOrWhiteSpace(symbol) && symbol != WeChatDefine)
                .ToList();
            if (enabled)
            {
                symbols.Add(WeChatDefine);
            }

            PlayerSettings.SetScriptingDefineSymbolsForGroup(BuildTargetGroup.WebGL, string.Join(";", symbols));
        }
    }
}
