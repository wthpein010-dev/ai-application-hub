using System;
using System.Linq;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEngine;

namespace ColorCreamFlow.Editor
{
    public static class WeChatBuildValidator
    {
        private const string ScenePath = "Assets/ColorCreamFlow/Scenes/LevelGameplay.unity";

        [MenuItem("Color Cream Flow/Configure WeChat Build")]
        public static void ConfigureProject()
        {
            PlayerSettings.productName = "IceCream";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.runInBackground = false;
            PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Brotli;
            PlayerSettings.WebGL.dataCaching = true;
            PlayerSettings.WebGL.exceptionSupport = WebGLExceptionSupport.ExplicitlyThrownExceptionsOnly;
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.WebGL, BuildTarget.WebGL);
            AssetDatabase.SaveAssets();
        }

        [MenuItem("Color Cream Flow/Validate WeChat Build")]
        public static void ValidateOrThrow()
        {
            var issues = Validate();
            if (issues.Length > 0)
            {
                throw new InvalidOperationException(string.Join("\n", issues));
            }

            Debug.Log("IceCream WeChat build validation passed.");
        }

        public static string[] Validate()
        {
            var issues = new System.Collections.Generic.List<string>();
            var sdkPackage = UnityEditor.PackageManager.PackageInfo.FindForAssetPath("Packages/com.qq.weixin.minigame");
            if (sdkPackage == null || sdkPackage.name != "com.qq.weixin.minigame")
            {
                issues.Add("Official WeChat mini game SDK is missing.");
            }

            if (!EditorBuildSettings.scenes.Any(scene => scene.enabled && scene.path == ScenePath))
            {
                issues.Add("LevelGameplay scene is not enabled in Build Settings.");
            }

            if (PlayerSettings.defaultInterfaceOrientation != UIOrientation.Portrait)
            {
                issues.Add("Default orientation must be Portrait.");
            }

            return issues.ToArray();
        }
    }
}
