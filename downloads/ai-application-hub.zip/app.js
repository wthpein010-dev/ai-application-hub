const STORAGE_KEY = "ai-competition-hub-v2-apps";
const SELECTED_KEY = "ai-competition-hub-v2-selected";
const PROJECT_ROOT_URL = "./projects/";

const statusLabel = {
  hub: "集合主页",
  main: "主推作品",
  candidate: "备选作品",
  tool: "辅助工具"
};

const defaultApps = [
  {
    id: "hub",
    name: "AI 应用方案整理器",
    category: "项目总览",
    status: "hub",
    brief: "把所有参赛应用、体验入口、提交材料和评分判断集中在一个本地页面中，方便审核和维护。",
    problem: "参赛材料分散在多个文件夹，临近提交时难以快速判断哪个项目最完整、入口在哪里、还缺什么。",
    aiUse: "AI 用于整理应用说明、维护建议、评分维度和提交材料清单。",
    folder: "./",
    entry: "./index.html",
    video: "./视频资源/演示视频占位.html",
    tags: ["总览", "导航", "评分", "维护"],
    speed: 9,
    impact: 8,
    risk: 9,
    polish: 9
  },
  {
    id: "travel-generator",
    name: "朋友圈发图神器",
    category: "AI 内容生成",
    status: "main",
    brief: "输入旅行心情和目的地，生成拍照任务、九宫格结构、预算建议和可直接发布的朋友圈文案。",
    problem: "旅行后照片很多，但整理成可发布的内容费时，文案、配图和节奏经常不统一。",
    aiUse: "AI 理解场景与情绪，生成拍照任务、图片收集建议、预算提醒和多风格分享文案。",
    folder: "../朋友圈发图神器/",
    entry: "../朋友圈发图神器/01_作品体验入口/app/index.html",
    video: "../朋友圈发图神器/03_演示视频/index.html",
    package: "../朋友圈发图神器/07_发布提交包/travel-generator-submission.zip",
    tags: ["旅行", "朋友圈", "文案", "九宫格"],
    speed: 9,
    impact: 9,
    risk: 8,
    polish: 9
  },
  {
    id: "feishu-downloader",
    name: "飞书文件批量下载插件",
    category: "浏览器插件",
    status: "main",
    brief: "面向飞书文档和文件资源整理场景，提供更清晰的批量下载和插件说明入口。",
    problem: "飞书资料分散在不同文档和文件里，手动逐个下载效率低，交付审核时也难以复查。",
    aiUse: "AI 参与需求拆解、交互文案、安装说明和审核材料梳理。",
    folder: "../飞书文件批量下载插件/",
    entry: "../飞书文件批量下载插件/index.html",
    video: "../飞书文件批量下载插件/视频资源/演示视频占位.html",
    package: "../飞书文件批量下载插件/feishu-batch-downloader-extension.zip",
    tags: ["飞书", "插件", "批量下载", "资料整理"],
    speed: 8,
    impact: 9,
    risk: 7,
    polish: 8
  },
  {
    id: "codex-reviewer",
    name: "Codex 对话评分工具",
    category: "效率工具",
    status: "tool",
    brief: "读取 Codex 对话记录并进行整理、评分和导出，帮助复盘 AI 协作过程。",
    problem: "长对话里有大量决策、修改和验证记录，人工复盘成本高，也不容易发现质量波动。",
    aiUse: "AI 用于总结对话、抽取任务进展、检查风险点并形成评分报告。",
    folder: "../Codex对话评分工具/",
    entry: "../Codex对话评分工具/index.html",
    video: "../Codex对话评分工具/视频资源/演示视频占位.html",
    tags: ["Codex", "评分", "复盘", "报告"],
    speed: 8,
    impact: 8,
    risk: 8,
    polish: 7
  },
  {
    id: "mistake-game",
    name: "AI 错题变小游戏",
    category: "学习辅助",
    status: "candidate",
    brief: "拍一道错题，生成闯关练习、知识点讲解和同类题，让复习过程更像小游戏。",
    problem: "错题经常停留在抄答案，学生很难主动复习同类知识点。",
    aiUse: "AI 用于识别题意、拆解知识点、生成讲解、同类题和闯关反馈。",
    folder: "../AI错题变小游戏/",
    entry: "../AI错题变小游戏/index.html",
    video: "../AI错题变小游戏/视频资源/演示视频占位.html",
    tags: ["学习", "错题", "闯关", "讲解"],
    speed: 6,
    impact: 9,
    risk: 6,
    polish: 7
  },
  {
    id: "emotion-translator",
    name: "AI 情绪翻译器",
    category: "创意互动",
    status: "candidate",
    brief: "把混乱心情翻译成真实需求、温和表达和下一步行动建议。",
    problem: "很多情绪不是没道理，而是没被说清楚，容易变成误会或内耗。",
    aiUse: "AI 提取情绪线索，识别潜在需求，改写表达方式并给出行动建议。",
    folder: "../AI情绪翻译器/",
    entry: "../AI情绪翻译器/index.html",
    video: "../AI情绪翻译器/视频资源/演示视频占位.html",
    tags: ["情绪", "表达", "行动建议", "卡片"],
    speed: 8,
    impact: 8,
    risk: 7,
    polish: 8
  },
  {
    id: "life-manual",
    name: "AI 生活说明书",
    category: "生活工具",
    status: "candidate",
    brief: "把物品、药品或说明书图片转成老人和小孩也能看懂的步骤卡。",
    problem: "说明书信息密、术语多，家庭场景里经常看不懂、找不到重点。",
    aiUse: "AI 用于图片理解、关键信息提取、风险提醒和步骤口语化改写。",
    folder: "../AI生活说明书/",
    entry: "../AI生活说明书/index.html",
    video: "../AI生活说明书/视频资源/演示视频占位.html",
    tags: ["说明书", "步骤卡", "家庭", "图片理解"],
    speed: 7,
    impact: 8,
    risk: 6,
    polish: 7
  },
  {
    id: "interview-theater",
    name: "AI 面试陪练小剧场",
    category: "职业工具",
    status: "candidate",
    brief: "选择岗位后，AI 扮演面试官连续追问，并给出复盘评分。",
    problem: "普通面试题库缺少真实追问压力，练完也不知道回答哪里需要改。",
    aiUse: "AI 用于岗位画像、角色扮演追问、答案评估和复盘建议生成。",
    folder: "../AI面试陪练小剧场/",
    entry: "../AI面试陪练小剧场/index.html",
    video: "../AI面试陪练小剧场/视频资源/演示视频占位.html",
    tags: ["面试", "追问", "复盘", "评分"],
    speed: 7,
    impact: 8,
    risk: 7,
    polish: 7
  },
  {
    id: "idea-library",
    name: "备选应用工具创意库",
    category: "方案库",
    status: "tool",
    brief: "保存更多 AI 小工具方向，用于后续筛选、扩展和补充展示。",
    problem: "创意很多但容易丢失，缺少统一的价值、风险和实现范围判断。",
    aiUse: "AI 用于生成方向、归纳适用场景、评估 MVP 范围和整理说明。",
    folder: "../备选应用工具创意库/",
    entry: "../备选应用工具创意库/index.html",
    video: "../备选应用工具创意库/视频资源/演示视频占位.html",
    tags: ["创意库", "备选", "MVP", "筛选"],
    speed: 9,
    impact: 7,
    risk: 9,
    polish: 7
  }
];

let apps = loadApps();

const state = {
  query: "",
  category: "all",
  status: "all",
  sort: "score",
  selectedId: localStorage.getItem(SELECTED_KEY) || "travel-generator",
  editing: false
};

const nodes = {
  statApps: document.querySelector("#statApps"),
  statMain: document.querySelector("#statMain"),
  statReady: document.querySelector("#statReady"),
  statScore: document.querySelector("#statScore"),
  spotlight: document.querySelector("#spotlightCard"),
  dots: document.querySelector("#showcaseDots"),
  prevApp: document.querySelector("#prevApp"),
  nextApp: document.querySelector("#nextApp"),
  search: document.querySelector("#searchInput"),
  category: document.querySelector("#categoryFilter"),
  status: document.querySelector("#statusFilter"),
  sort: document.querySelector("#sortMode"),
  grid: document.querySelector("#appGrid"),
  resultCount: document.querySelector("#resultCount"),
  compare: document.querySelector("#compareBars"),
  detail: document.querySelector("#detailPanel"),
  command: document.querySelector("#commandInput"),
  log: document.querySelector("#responseLog"),
  commandRun: document.querySelector("#commandRun"),
  runUpdate: document.querySelector("#runUpdate"),
  streamButton: document.querySelector("#streamButton"),
  exportButton: document.querySelector("#exportButton"),
  editToggle: document.querySelector("#editToggle"),
  editPanel: document.querySelector("#editPanel"),
  editClose: document.querySelector("#editClose"),
  editSave: document.querySelector("#editSave"),
  editReset: document.querySelector("#editReset"),
  editAppSelect: document.querySelector("#editAppSelect"),
  editName: document.querySelector("#editName"),
  editCategory: document.querySelector("#editCategory"),
  editBrief: document.querySelector("#editBrief"),
  editStatus: document.querySelector("#editStatus"),
  editTags: document.querySelector("#editTags"),
  editProblem: document.querySelector("#editProblem"),
  editAiUse: document.querySelector("#editAiUse"),
  editFolder: document.querySelector("#editFolder"),
  editEntry: document.querySelector("#editEntry"),
  editSpeed: document.querySelector("#editSpeed"),
  editImpact: document.querySelector("#editImpact"),
  editRisk: document.querySelector("#editRisk"),
  editPolish: document.querySelector("#editPolish")
};

bindEvents();
renderCategoryOptions();
render();
log("页面已加载。输入 1 或点击更新，可刷新当前应用清单。");

function bindEvents() {
  nodes.search.addEventListener("input", event => {
    state.query = event.target.value.trim().toLowerCase();
    render();
  });

  nodes.category.addEventListener("change", event => {
    state.category = event.target.value;
    render();
  });

  nodes.status.addEventListener("change", event => {
    state.status = event.target.value;
    render();
  });

  nodes.sort.addEventListener("change", event => {
    state.sort = event.target.value;
    render();
  });

  nodes.grid.addEventListener("click", event => {
    const card = event.target.closest("[data-app-id]");
    if (!card) return;
    selectApp(card.dataset.appId);
  });

  nodes.dots.addEventListener("click", event => {
    const dot = event.target.closest("[data-dot-id]");
    if (!dot) return;
    selectApp(dot.dataset.dotId);
  });

  nodes.prevApp.addEventListener("click", () => switchApp(-1));
  nodes.nextApp.addEventListener("click", () => switchApp(1));

  nodes.command.addEventListener("keydown", event => {
    if (event.key === "Enter") runCommand();
  });

  nodes.commandRun.addEventListener("click", runCommand);
  nodes.runUpdate.addEventListener("click", runMaintenance);
  nodes.streamButton.addEventListener("click", streamMaintenance);
  nodes.exportButton.addEventListener("click", exportList);
  nodes.editToggle.addEventListener("click", toggleEditMode);
  nodes.editClose.addEventListener("click", closeEditMode);
  nodes.editSave.addEventListener("click", saveEditForm);
  nodes.editReset.addEventListener("click", resetEdits);

  nodes.editAppSelect.addEventListener("change", event => {
    selectApp(event.target.value);
    renderEditForm();
  });
}

function render() {
  const filtered = getFilteredApps();
  ensureSelectedApp(filtered);
  renderStats();
  renderSpotlight();
  renderDots();
  renderGrid(filtered);
  renderCompare(filtered);
  renderDetail();
  renderEditForm();
}

function renderCategoryOptions() {
  const categories = [...new Set(apps.map(app => app.category))].sort((a, b) => a.localeCompare(b, "zh-CN"));
  nodes.category.innerHTML = [
    `<option value="all">全部分类</option>`,
    ...categories.map(category => `<option value="${escapeHtml(category)}">${escapeHtml(category)}</option>`)
  ].join("");
  nodes.category.value = state.category;
}

function getFilteredApps() {
  const query = state.query;
  return apps
    .filter(app => {
      const haystack = [app.name, app.category, app.brief, app.problem, app.aiUse, ...app.tags].join(" ").toLowerCase();
      const matchesQuery = !query || haystack.includes(query);
      const matchesCategory = state.category === "all" || app.category === state.category;
      const matchesStatus = state.status === "all" || app.status === state.status;
      return matchesQuery && matchesCategory && matchesStatus;
    })
    .sort((a, b) => {
      if (state.sort === "impact") return b.impact - a.impact || score(b) - score(a);
      if (state.sort === "polish") return b.polish - a.polish || score(b) - score(a);
      if (state.sort === "risk") return b.risk - a.risk || score(b) - score(a);
      return score(b) - score(a);
    });
}

function renderStats() {
  const readyCount = apps.filter(app => app.entry).length;
  const avgScore = Math.round(apps.reduce((sum, app) => sum + score(app), 0) / apps.length);
  nodes.statApps.textContent = apps.length;
  nodes.statMain.textContent = apps.filter(app => app.status === "main").length;
  nodes.statReady.textContent = readyCount;
  nodes.statScore.textContent = avgScore;
}

function renderSpotlight() {
  const app = getSelectedApp();
  nodes.spotlight.innerHTML = `
    <div class="selected-meta">
      <span class="status-badge status-${escapeHtml(app.status)}">${escapeHtml(statusLabel[app.status])}</span>
      <span>${escapeHtml(app.category)}</span>
      <span>综合 ${score(app)}/10</span>
    </div>
    <strong>${escapeHtml(app.name)}</strong>
    <p>${escapeHtml(app.brief)}</p>
    <div class="showcase-stats">
      <span><b>${app.speed}</b>速度</span>
      <span><b>${app.impact}</b>价值</span>
      <span><b>${app.risk}</b>低风险</span>
      <span><b>${app.polish}</b>完成度</span>
    </div>
    <div class="showcase-score-line" aria-hidden="true"><span style="width:${score(app) * 10}%"></span></div>
    <div class="tag-row">${app.tags.map(tag => `<span>${escapeHtml(tag)}</span>`).join("")}</div>
    ${renderActions(app)}
  `;
}

function renderDots() {
  nodes.dots.innerHTML = apps.map((app, index) => `
    <button class="showcase-dot ${app.id === state.selectedId ? "active" : ""}" type="button" data-dot-id="${escapeHtml(app.id)}" aria-label="${escapeHtml(app.name)}">
      <span>${String(index + 1).padStart(2, "0")}</span>
      <strong>${escapeHtml(app.name)}</strong>
    </button>
  `).join("");
}

function renderGrid(filtered) {
  nodes.resultCount.textContent = `${filtered.length} 个应用`;
  if (!filtered.length) {
    nodes.grid.innerHTML = `<article class="app-card"><h3>没有匹配结果</h3><p>换个关键词或重置筛选条件再试。</p></article>`;
    return;
  }

  nodes.grid.innerHTML = filtered.map((app, index) => `
    <article class="app-card ${app.id === state.selectedId ? "selected" : ""}" data-app-id="${escapeHtml(app.id)}" style="--card-order:${index}">
      <div class="card-topline">
        <span class="status-badge status-${escapeHtml(app.status)}">${escapeHtml(statusLabel[app.status])}</span>
        <strong>${score(app)}</strong>
      </div>
      <h3>${escapeHtml(app.name)}</h3>
      <p>${escapeHtml(app.brief)}</p>
      <div class="tag-row">${app.tags.slice(0, 4).map(tag => `<span>${escapeHtml(tag)}</span>`).join("")}</div>
      <div class="score-row">
        <span>速度 ${app.speed}</span>
        <span>价值 ${app.impact}</span>
        <span>风险 ${app.risk}</span>
        <span>完成 ${app.polish}</span>
      </div>
      <div class="card-score-meter" aria-hidden="true"><span style="width:${score(app) * 10}%"></span></div>
      ${renderActions(app, true)}
    </article>
  `).join("");
}

function renderCompare(filtered) {
  const list = (filtered.length ? filtered : apps).slice(0, 9);
  nodes.compare.innerHTML = list.map(app => `
    <div class="bar-item">
      <div>
        <strong>${escapeHtml(app.name)}</strong>
        <span>${escapeHtml(app.category)} / ${escapeHtml(statusLabel[app.status])}</span>
      </div>
      <div class="bar-track"><i style="width:${score(app) * 10}%"></i></div>
      <b>${score(app)}</b>
    </div>
  `).join("");
}

function renderDetail() {
  const app = getSelectedApp();
  nodes.detail.innerHTML = `
    <span class="status-badge status-${escapeHtml(app.status)}">${escapeHtml(statusLabel[app.status])}</span>
    <h2>${escapeHtml(app.name)}</h2>
    <p>${escapeHtml(app.brief)}</p>
    <div class="detail-stats">
      <span class="detail-stat"><strong>${app.speed}</strong>开发速度</span>
      <span class="detail-stat"><strong>${app.impact}</strong>价值密度</span>
      <span class="detail-stat"><strong>${app.risk}</strong>低风险</span>
      <span class="detail-stat"><strong>${app.polish}</strong>完成度</span>
    </div>
    ${renderActions(app)}
    <section>
      <h3>解决的问题</h3>
      <p>${escapeHtml(app.problem)}</p>
    </section>
    <section>
      <h3>AI 使用方式</h3>
      <p>${escapeHtml(app.aiUse)}</p>
    </section>
    <section>
      <h3>提交建议</h3>
      <p>${escapeHtml(getAdvice(app))}</p>
    </section>
  `;
}

function renderActions(app, stopPropagation = false) {
  const stop = stopPropagation ? ` onclick="event.stopPropagation()"` : "";
  const video = app.video ? `<a href="${escapeHtml(projectHref(app.video))}"${stop}>视频</a>` : "";
  const pack = app.package ? `<a href="${escapeHtml(projectHref(app.package))}"${stop}>发布包</a>` : "";
  return `
    <div class="card-actions">
      <a href="${escapeHtml(projectHref(app.folder))}"${stop}>文件夹</a>
      <a class="primary-link" href="${escapeHtml(projectHref(app.entry))}"${stop}>演示</a>
      ${video}
      ${pack}
    </div>
  `;
}

function renderEditForm() {
  const app = getSelectedApp();
  nodes.editAppSelect.innerHTML = apps.map(item => (
    `<option value="${escapeHtml(item.id)}">${escapeHtml(item.name)}</option>`
  )).join("");
  nodes.editAppSelect.value = app.id;
  nodes.editName.value = app.name;
  nodes.editCategory.value = app.category;
  nodes.editBrief.value = app.brief;
  nodes.editStatus.value = app.status;
  nodes.editTags.value = app.tags.join(", ");
  nodes.editProblem.value = app.problem;
  nodes.editAiUse.value = app.aiUse;
  nodes.editFolder.value = app.folder;
  nodes.editEntry.value = app.entry;
  nodes.editSpeed.value = app.speed;
  nodes.editImpact.value = app.impact;
  nodes.editRisk.value = app.risk;
  nodes.editPolish.value = app.polish;
}

function selectApp(id) {
  if (!apps.some(app => app.id === id)) return;
  state.selectedId = id;
  localStorage.setItem(SELECTED_KEY, id);
  document.querySelector(".hero-board")?.classList.remove("is-swapping");
  void document.querySelector(".hero-board")?.offsetWidth;
  document.querySelector(".hero-board")?.classList.add("is-swapping");
  render();
}

function switchApp(direction) {
  const currentIndex = Math.max(0, apps.findIndex(app => app.id === state.selectedId));
  const nextIndex = (currentIndex + direction + apps.length) % apps.length;
  selectApp(apps[nextIndex].id);
}

function ensureSelectedApp(filtered) {
  if (apps.some(app => app.id === state.selectedId)) return;
  state.selectedId = (filtered[0] || apps[0]).id;
}

function getSelectedApp() {
  return apps.find(app => app.id === state.selectedId) || apps[0];
}

function score(app) {
  return Math.round(app.speed * 0.24 + app.impact * 0.34 + app.risk * 0.18 + app.polish * 0.24);
}

function getAdvice(app) {
  if (app.status === "hub") return "作为总览入口使用，重点保证所有链接可打开、文案清晰、评分可解释。";
  if (app.status === "main") return "建议作为当前重点提交对象继续打磨：补齐演示视频、AI 使用说明、发布包和一分钟讲解脚本。";
  if (app.status === "tool") return "适合作为辅助能力展示，强调它如何支持主项目或提高协作效率。";
  if (app.impact >= 9) return "价值密度较高，适合继续推进；需要控制实现范围，避免在比赛周期内扩散。";
  return "适合作为补充方向展示，优先保留清晰说明和可视化入口。";
}

function runCommand() {
  if (nodes.command.value.trim() === "1") {
    nodes.command.value = "";
    runMaintenance();
  } else {
    log("未知命令。当前维护命令是 1。");
  }
}

function runMaintenance() {
  renderCategoryOptions();
  render();
  log(`维护完成：已刷新 ${apps.length} 个应用，主推 ${apps.filter(app => app.status === "main").length} 个，入口 ${apps.filter(app => app.entry).length} 个。`);
}

async function streamMaintenance() {
  const lines = [
    "正在读取应用集合...",
    "正在检查演示入口和提交材料入口...",
    "正在刷新综合评分与对比条...",
    "正在重绘当前应用详情...",
    "维护预览完成。"
  ];
  for (const line of lines) {
    log(line);
    await wait(180);
  }
}

function toggleEditMode() {
  state.editing = !state.editing;
  document.body.classList.toggle("editing", state.editing);
  nodes.editPanel.setAttribute("aria-hidden", String(!state.editing));
  nodes.editToggle.textContent = state.editing ? "退出编辑" : "编辑";
  renderEditForm();
}

function closeEditMode() {
  state.editing = false;
  document.body.classList.remove("editing");
  nodes.editPanel.setAttribute("aria-hidden", "true");
  nodes.editToggle.textContent = "编辑";
}

function saveEditForm() {
  apps = apps.map(app => {
    if (app.id !== state.selectedId) return app;
    return {
      ...app,
      name: nodes.editName.value.trim() || app.name,
      category: nodes.editCategory.value.trim() || app.category,
      brief: nodes.editBrief.value.trim() || app.brief,
      status: nodes.editStatus.value,
      tags: nodes.editTags.value.split(/[,，]/).map(tag => tag.trim()).filter(Boolean),
      problem: nodes.editProblem.value.trim() || app.problem,
      aiUse: nodes.editAiUse.value.trim() || app.aiUse,
      folder: nodes.editFolder.value.trim() || app.folder,
      entry: nodes.editEntry.value.trim() || app.entry,
      speed: clampScore(nodes.editSpeed.value),
      impact: clampScore(nodes.editImpact.value),
      risk: clampScore(nodes.editRisk.value),
      polish: clampScore(nodes.editPolish.value)
    };
  });
  localStorage.setItem(STORAGE_KEY, JSON.stringify(apps));
  renderCategoryOptions();
  render();
  log("已保存到当前浏览器本地存储。");
}

function resetEdits() {
  localStorage.removeItem(STORAGE_KEY);
  apps = defaultApps.map(cloneApp);
  renderCategoryOptions();
  render();
  log("已恢复默认应用数据。");
}

function exportList() {
  const markdown = [
    "# AI 应用项目清单",
    "",
    ...apps.map(app => [
      `## ${app.name}`,
      `- 状态：${statusLabel[app.status]}`,
      `- 分类：${app.category}`,
      `- 简介：${app.brief}`,
      `- 综合分：${score(app)}`,
      `- 文件夹：${app.folder}`,
      `- 演示：${app.entry}`,
      app.video ? `- 视频：${app.video}` : ""
    ].filter(Boolean).join("\n"))
  ].join("\n\n");

  navigator.clipboard?.writeText(markdown).then(() => {
    log("已复制 Markdown 清单到剪贴板。");
  }).catch(() => {
    log(markdown);
  });
}

function loadApps() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
    if (Array.isArray(stored) && stored.length) return stored.map(normalizeApp);
  } catch {
    localStorage.removeItem(STORAGE_KEY);
  }
  return defaultApps.map(cloneApp);
}

function normalizeApp(app) {
  return {
    ...cloneApp(defaultApps.find(item => item.id === app.id) || defaultApps[0]),
    ...app,
    tags: Array.isArray(app.tags) ? app.tags : []
  };
}

function cloneApp(app) {
  return {
    ...app,
    tags: [...app.tags]
  };
}

function clampScore(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return 5;
  return Math.max(1, Math.min(10, Math.round(number)));
}

function projectHref(value) {
  if (!value) return "#";
  if (/^(https?:|file:|#)/i.test(value)) return value;
  if (value.startsWith("../")) return PROJECT_ROOT_URL + encodeURI(value.slice(3));
  return value;
}

function log(message) {
  const time = new Date().toLocaleTimeString("zh-CN", { hour12: false });
  nodes.log.textContent += `[${time}] ${message}\n`;
  nodes.log.scrollTop = nodes.log.scrollHeight;
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
