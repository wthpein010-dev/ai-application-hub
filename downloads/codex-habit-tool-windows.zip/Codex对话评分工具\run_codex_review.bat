@echo off
setlocal
cd /d "%~dp0"

if not exist outputs mkdir outputs

"%~dp0Codex对话评分工具.exe"

echo.
echo Finished. The Excel file is in:
echo %~dp0outputs
echo.
pause
