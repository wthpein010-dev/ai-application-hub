@echo off
setlocal
set "PROJECT_DIR=%~dp0"
set "HUB=%ProgramFiles%\Unity Hub\Unity Hub.exe"

if defined UNITY_EDITOR if exist "%UNITY_EDITOR%" (
  start "" "%UNITY_EDITOR%" -projectPath "%PROJECT_DIR%"
  exit /b 0
)

set "UNITY=D:\unity\2022.3.62f3c1\Editor\Unity.exe"
if exist "%UNITY%" (
  start "" "%UNITY%" -projectPath "%PROJECT_DIR%"
  exit /b 0
)

if exist "%HUB%" (
  start "" "%HUB%" "%PROJECT_DIR%"
  exit /b 0
)

echo Unity Editor was not found.
echo Set UNITY_EDITOR to your Unity.exe path, or open Unity Hub manually.
echo Project:
echo %PROJECT_DIR%
pause
