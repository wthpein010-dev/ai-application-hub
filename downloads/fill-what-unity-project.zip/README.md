# 《装了个啥》Unity H5 小游戏原型

Unity 版本：`2022.3.62f3c1`

本工程当前默认启动《装了个啥》：一款竖屏 2D 安检审核小游戏。玩家扮演安检员，在普通、X 光、轮廓三种视图之间切换，判断行李能否放行。旧《填了个啥》填字原型仍保留在 `Assets/Scripts/FillWhatGame.cs`，但已不再默认自动启动。

## 打开工程

工程目录：`FillWhat_Unity`

Windows：

```bat
OpenProject.bat
```

macOS：

```bash
sh ./open_project.command
```

也可以在 Unity Hub 中选择 `FillWhat_Unity` 文件夹打开。请保持 Unity Editor 版本为 `2022.3.62f3c1`。

## 已实现内容

- 竖屏 UGUI 运行时，参考分辨率 `750 x 1624`。
- 作品名：《装了个啥》。
- 20 个关卡，每关 3-6 件行李，数据位于 `Assets/Resources/Data/security_content.json`。
- 三种检查视图：普通、X 光、轮廓。
- 无倒计时，玩家点击“放行”或“拦截”作出判断。
- 难度从明显危险品逐步过渡到干扰物、藏匿物、超量液体、鼓包电池和混合规则。
- 轻 IAA 循环：体力、提示、金币、模拟激励广告补体力/拿提示。
- `WechatMiniGameBridge.cs` 当前为本地模拟接口，后续接入微信/抖音小游戏 SDK 时替换实现即可。
- `FillWhatBuild.BuildWebGL` 构建前会校验安检内容必须包含 20 关。

## 关键文件

- `Assets/Scripts/SecurityCheck/SecurityCheckGame.cs`：默认启动、关卡地图、检查流程、反馈和结算。
- `Assets/Scripts/SecurityCheck/SecurityViewRenderer.cs`：普通/X 光/轮廓视图的程序化 UGUI 绘制。
- `Assets/Scripts/SecurityCheck/SecurityRuleEngine.cs`：纯规则判定逻辑。
- `Assets/Scripts/SecurityCheck/SecurityContent.cs`：Resources JSON 加载与运行时转换。
- `Assets/Scripts/SecurityCheck/SecurityEconomy.cs`：PlayerPrefs 经济层。
- `Assets/Editor/SecurityCheckSmokeTests.cs`：批处理烟测。
- `Assets/Editor/FillWhatBuild.cs`：WebGL 构建脚本。

## 运行烟测

```bat
"D:\unity\2022.3.62f3c1\Editor\Unity.exe" -batchmode -quit -projectPath "C:\Users\ASUS\Documents\AI Project\FillWhat_Unity" -executeMethod SecurityCheckSmokeTests.RunAll
```

烟测覆盖危险品规则、干扰物放行、超量液体、20 关内容、经济默认值/消耗/奖励，以及《装了个啥》默认启动开关。

## 构建 WebGL

Unity 菜单：

`装了个啥 -> 构建 WebGL`

Windows 命令行：

```bat
"D:\unity\2022.3.62f3c1\Editor\Unity.exe" -batchmode -quit -projectPath "C:\Users\ASUS\Documents\AI Project\FillWhat_Unity" -executeMethod FillWhatBuild.BuildWebGL
```

输出目录：

`Builds/WebGL`

## 本地预览 WebGL

Windows：

```bat
PreviewWebGL.bat
```

macOS：

```bash
sh ./preview_webgl.command
```

WebGL 不建议直接用 `file://` 打开，请使用脚本启动本地静态服务。

## 后续美术方向

当前原型使用程序化 UGUI 色块和文字标签，目标风格是中国大众向、明亮、简单、偏卡通的安检场景：公交/机场安检通道、柔和蓝绿灰、暖黄色提示、高风险物品用橙红高亮。避免欧美写实、硬科幻和过重暗色调。
