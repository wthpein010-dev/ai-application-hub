@echo off
setlocal
set "PROJECT_DIR=%~dp0"
set "WEBGL_DIR=%PROJECT_DIR%Builds\WebGL"
set "PORT=5173"

if not exist "%WEBGL_DIR%\index.html" (
  echo Builds\WebGL\index.html was not found. Build WebGL first.
  pause
  exit /b 1
)

cd /d "%WEBGL_DIR%"
echo Serving WebGL preview at http://127.0.0.1:%PORT%
python -m http.server %PORT%
