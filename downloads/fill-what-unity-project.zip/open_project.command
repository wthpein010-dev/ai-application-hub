#!/bin/sh
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if command -v open >/dev/null 2>&1; then
  open -a "Unity Hub" "$PROJECT_DIR" 2>/dev/null && exit 0
fi

UNITY="/Applications/Unity/Hub/Editor/2022.3.62f3c1/Unity.app/Contents/MacOS/Unity"
if [ -x "$UNITY" ]; then
  "$UNITY" -projectPath "$PROJECT_DIR"
else
  printf '%s\n' "Open Unity Hub, choose Add project from disk, then select:"
  printf '%s\n' "$PROJECT_DIR"
fi
