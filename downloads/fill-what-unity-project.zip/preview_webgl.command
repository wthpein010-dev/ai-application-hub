#!/bin/sh
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
WEBGL_DIR="$PROJECT_DIR/Builds/WebGL"
PORT="${PORT:-5173}"

if [ ! -f "$WEBGL_DIR/index.html" ]; then
  printf '%s\n' "Builds/WebGL/index.html was not found. Build WebGL first."
  exit 1
fi

cd "$WEBGL_DIR" || exit 1
printf '%s\n' "Serving WebGL preview at http://127.0.0.1:$PORT"
python3 -m http.server "$PORT"
