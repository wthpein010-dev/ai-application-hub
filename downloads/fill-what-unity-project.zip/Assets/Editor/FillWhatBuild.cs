using System.IO;
using System;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class FillWhatBuild
{
    private const string OutputPath = "Builds/WebGL";
    private const int DesignWidth = 750;
    private const int DesignHeight = 1624;

    [MenuItem("装了个啥/构建 WebGL")]
    public static void BuildWebGL()
    {
        FillWhatUGUIPrefabBuilder.BuildAll();
        PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled;
        PlayerSettings.WebGL.dataCaching = true;
        PlayerSettings.productName = "装了个啥";
        PlayerSettings.defaultScreenWidth = DesignWidth;
        PlayerSettings.defaultScreenHeight = DesignHeight;
        PlayerSettings.defaultWebScreenWidth = DesignWidth;
        PlayerSettings.defaultWebScreenHeight = DesignHeight;

        if (!Directory.Exists(OutputPath))
        {
            Directory.CreateDirectory(OutputPath);
        }

        SecurityContentPack pack = SecurityContent.Load();
        if (pack == null || pack.levels == null || pack.levels.Length != 20)
        {
            throw new Exception("Security content must contain 20 levels before WebGL build.");
        }

        BuildPlayerOptions options = new BuildPlayerOptions
        {
            scenes = new[] { "Assets/Scenes/Main.unity" },
            locationPathName = OutputPath,
            target = BuildTarget.WebGL,
            options = BuildOptions.None
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result != BuildResult.Succeeded)
        {
            throw new Exception("WebGL build failed: " + report.summary.result);
        }

        PatchWebGLResponsiveCss();
        Debug.Log("WebGL build completed: " + Path.GetFullPath(OutputPath));
    }

    private static void PatchWebGLResponsiveCss()
    {
        string cssPath = Path.Combine(OutputPath, "TemplateData", "style.css");
        if (!File.Exists(cssPath))
        {
            Debug.LogWarning("WebGL style.css was not found: " + Path.GetFullPath(cssPath));
            return;
        }

        string css = File.ReadAllText(cssPath);
        const string marker = "ZhuanglegeSha responsive patch";
        int existingPatch = css.IndexOf("/* " + marker, StringComparison.Ordinal);
        if (existingPatch >= 0)
        {
            css = css.Substring(0, existingPatch).TrimEnd() + Environment.NewLine;
            File.WriteAllText(cssPath, css);
        }

        string patch = @"

/* ZhuanglegeSha responsive patch: keep the 750x1624 WeChat Mini Game frame playable. */
html, body { width: 100%; min-height: 100%; overflow-x: hidden; background: #263C4A }
#unity-container.unity-desktop {
  width: min(100vw, calc((100vh - 48px) * 0.46182266), 750px);
}
#unity-container.unity-desktop #unity-canvas {
  display: block;
  width: 100% !important;
  height: auto !important;
  aspect-ratio: 750 / 1624;
}
#unity-container.unity-desktop #unity-footer {
  width: 100%;
}
";
        File.AppendAllText(cssPath, patch);
    }
}
