using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public static class FillWhatUGUIPrefabBuilder
{
    private const int DesignWidth = 750;
    private const int DesignHeight = 1624;
    private const string EditorPrefabRoot = "Assets/Prefabs/UGUI";
    private const string RuntimePrefabRoot = "Assets/Resources/Prefabs/UGUI";
    private static Font font;

    [MenuItem("FillWhat/Build UGUI Prefabs")]
    public static void BuildAll()
    {
        font = AssetDatabase.LoadAssetAtPath<Font>("Assets/Resources/Fonts/HarmonyOS_Sans_SC_Bold.ttf");
        EnsureFolders();
        ConfigureTextureImporters();
        ApplyProjectSettings();

        CreateIconButtonPrefab();
        CreateBlueButtonPrefab();
        CreateGreenButtonPrefab();
        CreateResourcePillPrefab();
        CreateLetterSlotPrefab();
        CreateLetterTilePrefab();
        CreatePopupPrefab();
        CreateDebugPanelPrefab();
        CreateLoadingScreenPrefab();
        CreateLoginScreenPrefab();
        CreateGameScreenPrefab();
        CreateScenePreview();

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("FillWhat UGUI prefabs generated for 750x1624.");
    }

    private static void EnsureFolders()
    {
        EnsureFolder("Assets", "Prefabs");
        EnsureFolder("Assets/Prefabs", "UGUI");
        EnsureFolder(EditorPrefabRoot, "Atoms");
        EnsureFolder(EditorPrefabRoot, "Screens");
        EnsureFolder(EditorPrefabRoot, "Popups");

        EnsureFolder("Assets", "Resources");
        EnsureFolder("Assets/Resources", "Prefabs");
        EnsureFolder("Assets/Resources/Prefabs", "UGUI");
        EnsureFolder(RuntimePrefabRoot, "Atoms");
        EnsureFolder(RuntimePrefabRoot, "Screens");
        EnsureFolder(RuntimePrefabRoot, "Popups");
    }

    private static void EnsureFolder(string parent, string child)
    {
        string path = parent + "/" + child;
        if (!AssetDatabase.IsValidFolder(path))
        {
            AssetDatabase.CreateFolder(parent, child);
        }
    }

    private static void ConfigureTextureImporters()
    {
        string[] guids = AssetDatabase.FindAssets("t:Texture2D", new[] { "Assets/Resources/Art" });
        for (int i = 0; i < guids.Length; i++)
        {
            string path = AssetDatabase.GUIDToAssetPath(guids[i]);
            TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer == null)
            {
                continue;
            }

            importer.textureType = TextureImporterType.Sprite;
            importer.spriteImportMode = SpriteImportMode.Single;
            importer.spritePixelsPerUnit = 100f;
            importer.alphaIsTransparency = true;
            importer.mipmapEnabled = false;
            importer.npotScale = TextureImporterNPOTScale.None;

            string normalized = path.Replace("\\", "/");
            if (normalized.Contains("/Art/Tiles/"))
            {
                importer.spriteBorder = new Vector4(16, 16, 16, 16);
            }
            else if (normalized.Contains("button_") || normalized.Contains("popup_panel") || normalized.Contains("paper_"))
            {
                importer.spriteBorder = new Vector4(24, 24, 24, 24);
            }

            importer.SaveAndReimport();
        }
    }

    private static void ApplyProjectSettings()
    {
        PlayerSettings.defaultScreenWidth = DesignWidth;
        PlayerSettings.defaultScreenHeight = DesignHeight;
        PlayerSettings.defaultWebScreenWidth = DesignWidth;
        PlayerSettings.defaultWebScreenHeight = DesignHeight;
        PlayerSettings.productName = "填了个啥";
    }

    private static void CreateIconButtonPrefab()
    {
        GameObject root = UIObject("IconButton", typeof(Image), typeof(Button));
        Rect(root).sizeDelta = new Vector2(72, 72);
        Image image = root.GetComponent<Image>();
        image.sprite = Sprite("Assets/Resources/Art/Common/icon_settings.png");
        image.preserveAspect = true;
        SavePrefab(root, "Atoms/IconButton.prefab");
    }

    private static void CreateBlueButtonPrefab()
    {
        GameObject root = UIObject("BlueTextButton", typeof(Image), typeof(Button));
        Rect(root).sizeDelta = new Vector2(360, 105);
        Image image = root.GetComponent<Image>();
        image.sprite = Sprite("Assets/Resources/Art/Common/button_blue.png");
        image.type = Image.Type.Sliced;
        Text label = AddText(root.transform, "Label", "开始答题", 36, Color.black, TextAnchor.MiddleCenter);
        Stretch(label.rectTransform);
        label.resizeTextForBestFit = true;
        label.resizeTextMinSize = 20;
        label.resizeTextMaxSize = 36;
        SavePrefab(root, "Atoms/BlueTextButton.prefab");
    }

    private static void CreateGreenButtonPrefab()
    {
        GameObject root = UIObject("GreenTextButton", typeof(Image), typeof(Button));
        Rect(root).sizeDelta = new Vector2(220, 72);
        Image image = root.GetComponent<Image>();
        image.sprite = Sprite("Assets/Resources/Art/Common/button_green.png");
        image.type = Image.Type.Sliced;
        Text label = AddText(root.transform, "Label", "确认", 28, Color.black, TextAnchor.MiddleCenter);
        Stretch(label.rectTransform);
        label.resizeTextForBestFit = true;
        label.resizeTextMinSize = 18;
        label.resizeTextMaxSize = 28;
        SavePrefab(root, "Atoms/GreenTextButton.prefab");
    }

    private static void CreateResourcePillPrefab()
    {
        GameObject root = UIObject("ResourcePill", typeof(Image));
        Rect(root).sizeDelta = new Vector2(168, 56);
        Image bg = root.GetComponent<Image>();
        bg.color = new Color(1f, 0.94f, 0.82f, 0.88f);

        Image icon = AddImage(root.transform, "Icon", "Assets/Resources/Art/Common/icon_coin.png");
        icon.preserveAspect = true;
        SetRect(icon.rectTransform, new Vector2(0, 0.5f), new Vector2(0, 0.5f), new Vector2(32, 0), new Vector2(42, 42));

        Text value = AddText(root.transform, "Value", "999", 24, new Color(0.33f, 0.18f, 0.12f), TextAnchor.MiddleLeft);
        SetRect(value.rectTransform, Vector2.zero, Vector2.one, new Vector2(54, 0), new Vector2(-70, 0));
        SavePrefab(root, "Atoms/ResourcePill.prefab");
    }

    private static void CreateLetterSlotPrefab()
    {
        GameObject root = UIObject("LetterSlot", typeof(Image), typeof(Button), typeof(LayoutElement));
        Rect(root).sizeDelta = new Vector2(64, 64);
        Image image = root.GetComponent<Image>();
        image.sprite = Sprite("Assets/Resources/Art/Tiles/slot_empty.png");
        image.type = Image.Type.Sliced;
        LayoutElement layout = root.GetComponent<LayoutElement>();
        layout.preferredWidth = 64;
        layout.preferredHeight = 64;
        Text label = AddText(root.transform, "Letter", "", 34, new Color(0.26f, 0.15f, 0.1f), TextAnchor.MiddleCenter);
        Stretch(label.rectTransform);
        SavePrefab(root, "Atoms/LetterSlot.prefab");
    }

    private static void CreateLetterTilePrefab()
    {
        GameObject root = UIObject("LetterTile", typeof(Image), typeof(Button));
        Rect(root).sizeDelta = new Vector2(82, 82);
        Image image = root.GetComponent<Image>();
        image.sprite = Sprite("Assets/Resources/Art/Tiles/letter_tile.png");
        image.type = Image.Type.Sliced;
        Text label = AddText(root.transform, "Letter", "字", 36, new Color(0.27f, 0.14f, 0.09f), TextAnchor.MiddleCenter);
        Stretch(label.rectTransform);
        SavePrefab(root, "Atoms/LetterTile.prefab");
    }

    private static void CreatePopupPrefab()
    {
        GameObject root = UIObject("PopupPanel", typeof(Image));
        Rect(root).sizeDelta = new Vector2(620, 480);
        Image panel = root.GetComponent<Image>();
        panel.sprite = Sprite("Assets/Resources/Art/Popup/popup_panel.png");
        panel.type = Image.Type.Sliced;

        Text title = AddText(root.transform, "Title", "弹窗标题", 36, new Color(0.35f, 0.17f, 0.09f), TextAnchor.MiddleCenter);
        SetRect(title.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -76), new Vector2(470, 62));

        Text body = AddText(root.transform, "Body", "弹窗内容", 26, new Color(0.33f, 0.24f, 0.18f), TextAnchor.UpperCenter);
        body.horizontalOverflow = HorizontalWrapMode.Wrap;
        SetRect(body.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, 38), new Vector2(490, 150));

        GameObject close = PrefabInstance(EditorPrefabRoot + "/Atoms/IconButton.prefab", root.transform, "CloseButton");
        close.GetComponent<Image>().sprite = Sprite("Assets/Resources/Art/Popup/popup_close.png");
        SetRect(Rect(close), new Vector2(1, 1), new Vector2(1, 1), new Vector2(-44, -44), new Vector2(60, 60));

        GameObject action = PrefabInstance(EditorPrefabRoot + "/Atoms/BlueTextButton.prefab", root.transform, "ActionButton");
        SetRect(Rect(action), new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 78), new Vector2(300, 82));
        SavePrefab(root, "Popups/PopupPanel.prefab");
    }

    private static void CreateDebugPanelPrefab()
    {
        GameObject root = UIObject("DebugPanel", typeof(Image));
        Rect(root).sizeDelta = new Vector2(690, 1240);
        root.GetComponent<Image>().color = new Color(0.96f, 0.93f, 0.86f, 0.98f);

        Text title = AddText(root.transform, "Title", "调试面板", 38, new Color(0.16f, 0.12f, 0.09f), TextAnchor.MiddleCenter);
        SetRect(title.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -58), new Vector2(360, 58));

        Text resources = AddText(root.transform, "ResourceEditorPreview", "体力 / 金币 / 提示 数值调整", 26, new Color(0.20f, 0.16f, 0.12f), TextAnchor.MiddleCenter);
        SetRect(resources.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -210), new Vector2(560, 70));

        Text actions = AddText(root.transform, "ActionPreview", "应用数值    直接通关", 25, new Color(0.20f, 0.16f, 0.12f), TextAnchor.MiddleCenter);
        SetRect(actions.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -372), new Vector2(560, 62));

        Text listTitle = AddText(root.transform, "LevelListTitle", "关卡快照", 28, new Color(0.22f, 0.15f, 0.10f), TextAnchor.MiddleLeft);
        SetRect(listTitle.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -448), new Vector2(580, 44));

        GameObject grid = UIObject("EnvelopeGridPreview", typeof(GridLayoutGroup));
        grid.transform.SetParent(root.transform, false);
        SetRect(Rect(grid), new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -790), new Vector2(600, 600));
        GridLayoutGroup layout = grid.GetComponent<GridLayoutGroup>();
        layout.cellSize = new Vector2(178, 132);
        layout.spacing = new Vector2(20, 18);
        layout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
        layout.constraintCount = 3;
        layout.childAlignment = TextAnchor.UpperCenter;

        for (int i = 0; i < 9; i++)
        {
            GameObject card = UIObject("LevelEnvelope_" + (i + 1), typeof(Image));
            card.transform.SetParent(grid.transform, false);
            Image bg = card.GetComponent<Image>();
            bg.sprite = Sprite("Assets/Resources/Art/Game/paper_small.png");
            bg.type = Image.Type.Sliced;
            bg.color = new Color(1f, 0.96f, 0.84f, 1f);

            Text label = AddText(card.transform, "Label", "第" + (i + 1) + "关", 20, new Color(0.47f, 0.24f, 0.12f), TextAnchor.MiddleCenter);
            SetRect(label.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(130, 44));
        }

        SavePrefab(root, "Popups/DebugPanel.prefab");
    }

    private static void CreateLoadingScreenPrefab()
    {
        GameObject root = UIObject("LoadingScreen");
        Stretch(Rect(root));
        AddCoverImage(root.transform, "Background", "Assets/Resources/Art/Login/login_bg.png");

        Image title = AddImage(root.transform, "TitleLogo", "Assets/Resources/Art/Common/title_logo.png");
        title.preserveAspect = true;
        SetRect(title.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -255), new Vector2(520, 178));

        Text subtitle = AddText(root.transform, "Subtitle", "正在准备来信", 28, new Color(0.48f, 0.25f, 0.16f), TextAnchor.MiddleCenter);
        SetRect(subtitle.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -370), new Vector2(520, 54));

        Image track = AddImage(root.transform, "ProgressTrack", null);
        track.color = new Color(0.34f, 0.18f, 0.12f, 0.22f);
        SetRect(track.rectTransform, new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 380), new Vector2(460, 26));

        Image fill = AddImage(track.transform, "ProgressFill", null);
        fill.color = new Color(0.22f, 0.58f, 0.83f, 1f);
        fill.type = Image.Type.Filled;
        fill.fillMethod = Image.FillMethod.Horizontal;
        fill.fillOrigin = (int)Image.OriginHorizontal.Left;
        fill.fillAmount = 0f;
        Stretch(fill.rectTransform);

        Text progress = AddText(root.transform, "ProgressText", "0%", 24, new Color(0.34f, 0.16f, 0.08f), TextAnchor.MiddleCenter);
        SetRect(progress.rectTransform, new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 336), new Vector2(220, 42));
        SavePrefab(root, "Screens/LoadingScreen.prefab");
    }

    private static void CreateLoginScreenPrefab()
    {
        GameObject root = UIObject("LoginScreen");
        Stretch(Rect(root));
        AddCoverImage(root.transform, "Background", "Assets/Resources/Art/Login/login_bg.png");
        CreateTopBar(root.transform, false);

        Image title = AddImage(root.transform, "TitleLogo", "Assets/Resources/Art/Common/title_logo.png");
        title.preserveAspect = true;
        SetRect(title.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -255), new Vector2(520, 178));

        Text subtitle = AddText(root.transform, "Subtitle", "补全成语，翻开一封写给你的诗意来信", 26, new Color(0.48f, 0.25f, 0.16f), TextAnchor.MiddleCenter);
        SetRect(subtitle.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -370), new Vector2(630, 70));

        GameObject start = PrefabInstance(EditorPrefabRoot + "/Atoms/BlueTextButton.prefab", root.transform, "StartButton");
        start.GetComponentInChildren<Text>().text = "开始答题";
        SetRect(Rect(start), new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 236), new Vector2(360, 105));

        Text footer = AddText(root.transform, "Footer", "体力不足时可观看激励视频补充", 22, new Color(0.43f, 0.23f, 0.14f), TextAnchor.MiddleCenter);
        SetRect(footer.rectTransform, new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 150), new Vector2(610, 52));
        CreateToast(root.transform);
        SavePrefab(root, "Screens/LoginScreen.prefab");
    }

    private static void CreateGameScreenPrefab()
    {
        GameObject root = UIObject("GameScreen");
        Stretch(Rect(root));
        AddCoverImage(root.transform, "Background", "Assets/Resources/Art/Game/game_bg_1.png");
        CreateTopBar(root.transform, true);

        Image paper = AddImage(root.transform, "Paper", "Assets/Resources/Art/Game/paper_large.png");
        paper.type = Image.Type.Sliced;
        SetRect(paper.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -650), new Vector2(660, 900));

        Text title = AddText(paper.transform, "LevelTitle", "第一封信 · 春日初见", 34, new Color(0.34f, 0.16f, 0.09f), TextAnchor.MiddleCenter);
        SetRect(title.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(35, -66), new Vector2(500, 58));

        Text theme = AddText(paper.transform, "Theme", "校园樱花", 22, new Color(0.62f, 0.39f, 0.25f), TextAnchor.MiddleCenter);
        SetRect(theme.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(35, -112), new Vector2(440, 42));

        Text prompt = AddText(paper.transform, "Prompt", "春风拂过旧庭院，你的来信落在案前。", 25, new Color(0.28f, 0.20f, 0.15f), TextAnchor.UpperLeft);
        prompt.horizontalOverflow = HorizontalWrapMode.Wrap;
        SetRect(prompt.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(35, -210), new Vector2(500, 120));

        GameObject groups = UIObject("AnswerGroups");
        groups.transform.SetParent(paper.transform, false);
        SetRect(Rect(groups), new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(35, -458), new Vector2(530, 370));

        Text ending = AddText(paper.transform, "EndingPreview", "明日的风若也这样温柔，我们就在旧亭边再读下一封信。", 23, new Color(0.45f, 0.27f, 0.17f), TextAnchor.UpperLeft);
        ending.horizontalOverflow = HorizontalWrapMode.Wrap;
        SetRect(ending.rectTransform, new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(35, 102), new Vector2(500, 112));

        GameObject hint = PrefabInstance(EditorPrefabRoot + "/Atoms/GreenTextButton.prefab", root.transform, "HintButton");
        hint.GetComponentInChildren<Text>().text = "提示";
        hint.GetComponentInChildren<Text>().color = Color.black;
        SetRect(Rect(hint), new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(-135, 470), new Vector2(190, 70));

        GameObject reset = PrefabInstance(EditorPrefabRoot + "/Atoms/GreenTextButton.prefab", root.transform, "ResetButton");
        reset.GetComponentInChildren<Text>().text = "重置";
        reset.GetComponentInChildren<Text>().color = Color.black;
        SetRect(Rect(reset), new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(135, 470), new Vector2(190, 70));

        GameObject rack = UIObject("TileRack", typeof(GridLayoutGroup));
        rack.transform.SetParent(root.transform, false);
        SetRect(Rect(rack), new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 220), new Vector2(640, 280));
        GridLayoutGroup grid = rack.GetComponent<GridLayoutGroup>();
        grid.cellSize = new Vector2(82, 82);
        grid.spacing = new Vector2(10, 10);
        grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
        grid.constraintCount = 7;
        grid.childAlignment = TextAnchor.UpperCenter;

        CreateToast(root.transform);
        SavePrefab(root, "Screens/GameScreen.prefab");
    }

    private static void CreateTopBar(Transform parent, bool inGame)
    {
        GameObject bar = UIObject("TopBar");
        bar.transform.SetParent(parent, false);
        SetRect(Rect(bar), new Vector2(0, 1), new Vector2(1, 1), new Vector2(0, -58), new Vector2(0, 116));

        GameObject left = PrefabInstance(EditorPrefabRoot + "/Atoms/IconButton.prefab", bar.transform, inGame ? "BackButton" : "SettingsButton");
        left.GetComponent<Image>().sprite = Sprite(inGame ? "Assets/Resources/Art/Popup/popup_close.png" : "Assets/Resources/Art/Common/icon_settings.png");
        SetRect(Rect(left), new Vector2(0, 0.5f), new Vector2(0, 0.5f), new Vector2(50, 0), new Vector2(64, 64));

        GameObject coin = PrefabInstance(EditorPrefabRoot + "/Atoms/ResourcePill.prefab", bar.transform, "CoinPill");
        coin.transform.Find("Icon").GetComponent<Image>().sprite = Sprite("Assets/Resources/Art/Common/icon_coin.png");
        SetRect(Rect(coin), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(-145, 0), new Vector2(160, 54));

        GameObject energy = PrefabInstance(EditorPrefabRoot + "/Atoms/ResourcePill.prefab", bar.transform, "EnergyPill");
        energy.transform.Find("Icon").GetComponent<Image>().sprite = Sprite("Assets/Resources/Art/Common/icon_energy.png");
        energy.transform.Find("Value").GetComponent<Text>().text = "5/5";
        SetRect(Rect(energy), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(35, 0), new Vector2(160, 54));

        GameObject hint = PrefabInstance(EditorPrefabRoot + "/Atoms/ResourcePill.prefab", bar.transform, "HintPill");
        hint.transform.Find("Icon").GetComponent<Image>().sprite = Sprite("Assets/Resources/Art/Common/icon_hint.png");
        hint.transform.Find("Value").GetComponent<Text>().text = "3";
        SetRect(Rect(hint), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(215, 0), new Vector2(150, 54));

    }

    private static void CreateToast(Transform parent)
    {
        Image bg = AddImage(parent, "Toast", null);
        bg.color = new Color(0.18f, 0.12f, 0.08f, 0.78f);
        SetRect(bg.rectTransform, new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 720), new Vector2(600, 62));
        Text toast = AddText(bg.transform, "ToastText", "", 23, Color.white, TextAnchor.MiddleCenter);
        Stretch(toast.rectTransform);
        bg.gameObject.SetActive(false);
    }

    private static void CreateScenePreview()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        GameObject camera = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener));
        camera.tag = "MainCamera";
        camera.transform.position = new Vector3(0, 0, -10);
        Camera cam = camera.GetComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.96f, 0.82f, 0.72f, 1f);
        cam.orthographic = true;

        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        GameObject canvas = UIObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas c = canvas.GetComponent<Canvas>();
        c.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvas.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(DesignWidth, DesignHeight);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 1;

        GameObject designRoot = UIObject("DesignRoot");
        designRoot.transform.SetParent(canvas.transform, false);
        RectTransform designRect = Rect(designRoot);
        designRect.anchorMin = new Vector2(0.5f, 0.5f);
        designRect.anchorMax = new Vector2(0.5f, 0.5f);
        designRect.pivot = new Vector2(0.5f, 0.5f);
        designRect.anchoredPosition = Vector2.zero;
        designRect.sizeDelta = new Vector2(DesignWidth, DesignHeight);

        GameObject loading = PrefabInstance(EditorPrefabRoot + "/Screens/LoadingScreen.prefab", designRoot.transform, "LoadingScreen");
        Stretch(Rect(loading));

        GameObject popupLayer = UIObject("PopupLayer");
        popupLayer.transform.SetParent(designRoot.transform, false);
        Stretch(Rect(popupLayer));
        popupLayer.SetActive(false);

        GameObject runtime = new GameObject("GameRoot_Runtime");
        runtime.AddComponent<FillWhatGame>();

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/Main.unity");
    }

    private static GameObject UIObject(string name, params System.Type[] components)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        for (int i = 0; i < components.Length; i++)
        {
            if (components[i] != typeof(RectTransform))
            {
                go.AddComponent(components[i]);
            }
        }

        return go;
    }

    private static Image AddImage(Transform parent, string name, string spritePath)
    {
        GameObject go = UIObject(name, typeof(Image));
        go.transform.SetParent(parent, false);
        Image image = go.GetComponent<Image>();
        image.sprite = Sprite(spritePath);
        return image;
    }

    private static Image AddCoverImage(Transform parent, string name, string spritePath)
    {
        Image image = AddImage(parent, name, spritePath);
        Stretch(image.rectTransform);
        Sprite sprite = image.sprite;
        if (sprite != null)
        {
            AspectRatioFitter fitter = image.gameObject.AddComponent<AspectRatioFitter>();
            fitter.aspectMode = AspectRatioFitter.AspectMode.EnvelopeParent;
            fitter.aspectRatio = sprite.rect.width / sprite.rect.height;
        }

        return image;
    }

    private static Text AddText(Transform parent, string name, string value, int size, Color color, TextAnchor anchor)
    {
        GameObject go = UIObject(name, typeof(Text));
        go.transform.SetParent(parent, false);
        Text text = go.GetComponent<Text>();
        text.text = value;
        text.font = font;
        text.fontSize = size;
        text.color = color;
        text.alignment = anchor;
        text.horizontalOverflow = HorizontalWrapMode.Overflow;
        text.verticalOverflow = VerticalWrapMode.Truncate;
        text.raycastTarget = false;
        return text;
    }

    private static GameObject PrefabInstance(string path, Transform parent, string name)
    {
        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
        GameObject instance = prefab != null ? (GameObject)PrefabUtility.InstantiatePrefab(prefab) : UIObject(name);
        instance.name = name;
        instance.transform.SetParent(parent, false);
        return instance;
    }

    private static void SavePrefab(GameObject root, string relativePath)
    {
        string editorPath = EditorPrefabRoot + "/" + relativePath;
        string runtimePath = RuntimePrefabRoot + "/" + relativePath;
        PrefabUtility.SaveAsPrefabAsset(root, editorPath);
        PrefabUtility.SaveAsPrefabAsset(root, runtimePath);
        Object.DestroyImmediate(root);
    }

    private static RectTransform Rect(GameObject go)
    {
        return go.GetComponent<RectTransform>();
    }

    private static Sprite Sprite(string path)
    {
        return string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<Sprite>(path);
    }

    private static void Stretch(RectTransform rect)
    {
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        rect.pivot = new Vector2(0.5f, 0.5f);
    }

    private static void SetRect(RectTransform rect, Vector2 anchorMin, Vector2 anchorMax, Vector2 position, Vector2 size)
    {
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.pivot = new Vector2(0.5f, 0.5f);
        rect.anchoredPosition = position;
        rect.sizeDelta = size;
    }
}
