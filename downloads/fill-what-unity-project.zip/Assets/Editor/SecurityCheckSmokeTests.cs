using System;
using UnityEditor;
using UnityEngine;

public static class SecurityCheckSmokeTests
{
    public static void RunAll()
    {
        TestDangerousItemBlocksBag();
        TestSafeDistractorPassesBag();
        TestOversizeLiquidBlocksBag();
        TestContentHasTwentyLevels();
        TestContentEveryLevelHasBags();
        TestEconomyDefaults();
        TestEconomySpendAndAdRefill();
        TestEconomyHintsAndRewards();
        TestSecurityGameIsDefaultBoot();
        Debug.Log("SecurityCheckSmokeTests passed.");
    }

    private static void TestDangerousItemBlocksBag()
    {
        SecurityBagRuntime bag = new SecurityBagRuntime(
            "test-knife",
            new[]
            {
                new SecurityItemRuntime("shirt", SecurityItemCategory.Safe, SecurityRuleTag.Safe),
                new SecurityItemRuntime("knife", SecurityItemCategory.Dangerous, SecurityRuleTag.Dangerous)
            },
            SecurityDecision.Block,
            "发现刀具"
        );

        SecurityDecisionResult result = SecurityRuleEngine.Evaluate(bag);
        if (result.correctDecision != SecurityDecision.Block || !result.reason.Contains("刀"))
        {
            throw new Exception("Knife bag should be blocked with a knife reason.");
        }
    }

    private static void TestSafeDistractorPassesBag()
    {
        SecurityBagRuntime bag = new SecurityBagRuntime(
            "test-umbrella",
            new[] { new SecurityItemRuntime("umbrella", SecurityItemCategory.Distractor, SecurityRuleTag.ToyLookalike) },
            SecurityDecision.Pass,
            "雨伞可放行"
        );

        SecurityDecisionResult result = SecurityRuleEngine.Evaluate(bag);
        if (result.correctDecision != SecurityDecision.Pass)
        {
            throw new Exception("Safe distractor bag should pass.");
        }
    }

    private static void TestOversizeLiquidBlocksBag()
    {
        SecurityBagRuntime bag = new SecurityBagRuntime(
            "test-liquid",
            new[] { new SecurityItemRuntime("large-water", SecurityItemCategory.Conditional, SecurityRuleTag.OversizeLiquid) },
            SecurityDecision.Block,
            "液体超量"
        );

        SecurityDecisionResult result = SecurityRuleEngine.Evaluate(bag);
        if (result.correctDecision != SecurityDecision.Block || !result.reason.Contains("液体"))
        {
            throw new Exception("Oversize liquid should be blocked.");
        }
    }

    private static void TestContentHasTwentyLevels()
    {
        SecurityContentPack pack = SecurityContent.Load();
        if (pack.levels == null || pack.levels.Length != 20)
        {
            throw new Exception("Security content must contain exactly 20 first-version levels.");
        }
    }

    private static void TestContentEveryLevelHasBags()
    {
        SecurityContentPack pack = SecurityContent.Load();
        for (int i = 0; i < pack.levels.Length; i++)
        {
            if (pack.levels[i].bags == null || pack.levels[i].bags.Length < 3 || pack.levels[i].bags.Length > 6)
            {
                throw new Exception("Level " + (i + 1) + " must contain 3-6 bags.");
            }
        }
    }

    private static void TestEconomyDefaults()
    {
        SecurityEconomy.ResetForTests();
        if (SecurityEconomy.Energy != 5 || SecurityEconomy.Hints != 3 || SecurityEconomy.Coins != 0)
        {
            throw new Exception("Security economy defaults should be 5 energy, 3 hints, 0 coins.");
        }
    }

    private static void TestEconomySpendAndAdRefill()
    {
        SecurityEconomy.ResetForTests();
        if (!SecurityEconomy.TrySpendEnergy() || SecurityEconomy.Energy != 4)
        {
            throw new Exception("Spending one energy should leave 4 energy.");
        }

        SecurityEconomy.AddEnergyFromAd();
        if (SecurityEconomy.Energy != 5)
        {
            throw new Exception("Rewarded ad should refill energy to max.");
        }
    }

    private static void TestEconomyHintsAndRewards()
    {
        SecurityEconomy.ResetForTests();
        if (!SecurityEconomy.TrySpendHint() || SecurityEconomy.Hints != 2)
        {
            throw new Exception("Spending one hint should leave 2 hints.");
        }

        SecurityEconomy.AddRewards(25, 2);
        if (SecurityEconomy.Coins != 25 || SecurityEconomy.Hints != 4)
        {
            throw new Exception("Rewards should add coins and hints.");
        }
    }

    private static void TestSecurityGameIsDefaultBoot()
    {
        if (!SecurityCheckGame.UseSecurityCheckAsDefault)
        {
            throw new Exception("SecurityCheckGame must be the default boot for this project.");
        }
    }
}
