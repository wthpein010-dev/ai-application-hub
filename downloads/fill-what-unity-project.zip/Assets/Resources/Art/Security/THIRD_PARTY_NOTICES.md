# Third-party art notices

The PNG icons in `Items/`, `Bags/`, and `UI/` are sourced from Google Noto Emoji.

- Source: https://github.com/googlefonts/noto-emoji
- License: Apache License 2.0
- Downloaded size: `png/128`

The filenames were renamed to match the local security-check item and UI ids.