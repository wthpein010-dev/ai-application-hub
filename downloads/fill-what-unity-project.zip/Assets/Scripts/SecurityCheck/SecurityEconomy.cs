using System;
using UnityEngine;

public static class SecurityEconomy
{
    public const int EnergyMax = 5;

    private const string EnergyKey = "SecurityCheck.Energy";
    private const string CoinKey = "SecurityCheck.Coins";
    private const string HintKey = "SecurityCheck.Hints";

    public static int Energy
    {
        get { return PlayerPrefs.GetInt(EnergyKey, EnergyMax); }
    }

    public static int Coins
    {
        get { return PlayerPrefs.GetInt(CoinKey, 0); }
    }

    public static int Hints
    {
        get { return PlayerPrefs.GetInt(HintKey, 3); }
    }

    public static bool TrySpendEnergy()
    {
        if (Energy <= 0)
        {
            return false;
        }

        PlayerPrefs.SetInt(EnergyKey, Energy - 1);
        PlayerPrefs.Save();
        return true;
    }

    public static bool TrySpendHint()
    {
        if (Hints <= 0)
        {
            return false;
        }

        PlayerPrefs.SetInt(HintKey, Hints - 1);
        PlayerPrefs.Save();
        return true;
    }

    public static void AddRewards(int coins, int hints)
    {
        PlayerPrefs.SetInt(CoinKey, Math.Max(0, Coins + coins));
        PlayerPrefs.SetInt(HintKey, Math.Max(0, Hints + hints));
        PlayerPrefs.Save();
    }

    public static void AddEnergyFromAd()
    {
        PlayerPrefs.SetInt(EnergyKey, EnergyMax);
        PlayerPrefs.Save();
    }

    public static void ResetForTests()
    {
        PlayerPrefs.DeleteKey(EnergyKey);
        PlayerPrefs.DeleteKey(CoinKey);
        PlayerPrefs.DeleteKey(HintKey);
        PlayerPrefs.Save();
    }
}
