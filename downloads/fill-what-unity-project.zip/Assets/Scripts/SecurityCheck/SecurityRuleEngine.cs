public static class SecurityRuleEngine
{
    public static SecurityDecisionResult Evaluate(SecurityBagRuntime bag)
    {
        if (bag == null)
        {
            return new SecurityDecisionResult(SecurityDecision.Block, "发现未登记行李", string.Empty);
        }

        for (int i = 0; i < bag.items.Length; i++)
        {
            SecurityItemRuntime item = bag.items[i];
            if (item == null)
            {
                return new SecurityDecisionResult(SecurityDecision.Block, "发现未登记物品", string.Empty);
            }

            if ((item.tags & SecurityRuleTag.Dangerous) != 0)
            {
                return new SecurityDecisionResult(SecurityDecision.Block, ReasonForDangerousItem(item.id, bag.configuredReason), item.id);
            }

            if ((item.tags & SecurityRuleTag.OversizeLiquid) != 0)
            {
                return new SecurityDecisionResult(SecurityDecision.Block, "随身液体单瓶超过100ml，按安检规定需移交复检", item.id);
            }

            if ((item.tags & SecurityRuleTag.DamagedBattery) != 0)
            {
                return new SecurityDecisionResult(SecurityDecision.Block, "充电宝外壳鼓包，存在电池风险，需移交复检", item.id);
            }

            if ((item.tags & SecurityRuleTag.SharpHidden) != 0)
            {
                return new SecurityDecisionResult(SecurityDecision.Block, "夹层出现细薄尖锐轮廓，疑似藏匿刀片，需移交复检", item.id);
            }
        }

        if (ContainsLiquid(bag))
        {
            return new SecurityDecisionResult(SecurityDecision.Pass, "液体单瓶未超过100ml，且未发现限制携带物，可准予放行", string.Empty);
        }

        return new SecurityDecisionResult(SecurityDecision.Pass, bag.configuredReason, string.Empty);
    }

    private static bool ContainsLiquid(SecurityBagRuntime bag)
    {
        if (bag == null || bag.items == null)
        {
            return false;
        }

        for (int i = 0; i < bag.items.Length; i++)
        {
            SecurityItemRuntime item = bag.items[i];
            if (item != null && (item.tags & SecurityRuleTag.Liquid) != 0)
            {
                return true;
            }
        }

        return false;
    }

    private static string ReasonForDangerousItem(string itemId, string fallback)
    {
        if (!string.IsNullOrEmpty(itemId) && itemId.Contains("knife"))
        {
            return "X光机发现刀具轮廓，属于限制携带物，需移交复检";
        }

        if (!string.IsNullOrEmpty(itemId) && itemId.Contains("lighter"))
        {
            return "发现火种类物品，按安检口径需移交复检";
        }

        if (!string.IsNullOrEmpty(itemId) && itemId.Contains("scissors"))
        {
            return "发现剪刀尖锐金属轮廓，需移交复检";
        }

        return string.IsNullOrEmpty(fallback) ? "发现限制携带物，需移交复检" : fallback;
    }
}
