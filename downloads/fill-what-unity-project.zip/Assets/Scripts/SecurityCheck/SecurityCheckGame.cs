using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class SecurityCheckGame : MonoBehaviour
{
    public static readonly bool UseSecurityCheckAsDefault = true;

    private const int DesignWidth = 750;
    private const int DesignHeight = 1624;

    private static SecurityCheckGame instance;

    private Canvas canvas;
    private RectTransform root;
    private Font gameFont;
    private readonly Dictionary<string, Sprite> spriteCache = new Dictionary<string, Sprite>();
    private SecurityContentPack content;
    private SecurityLevelConfig currentLevel;
    private SecurityBagConfig currentBagConfig;
    private SecurityBagRuntime currentBag;
    private SecurityViewMode currentViewMode;
    private string hintMessage;
    private int currentLevelIndex;
    private int currentBagIndex;
    private int correctCount;
    private bool rewardGranted;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if (!UseSecurityCheckAsDefault || instance != null)
        {
            return;
        }

        GameObject host = new GameObject("SecurityCheck_Runtime");
        DontDestroyOnLoad(host);
        instance = host.AddComponent<SecurityCheckGame>();
    }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }

        instance = this;
        gameFont = Resources.Load<Font>("Fonts/HarmonyOS_Sans_SC_Bold") ?? Resources.GetBuiltinResource<Font>("Arial.ttf");
        content = SecurityContent.Load();
        BuildOrAdoptCanvas();
        EnsureEventSystem();
        ShowMainScreen();
    }

    private void ShowMainScreen()
    {
        RectTransform screen = CreateScreen("MainScreen", ColorFromHex(0xF4F0E5));
        AddTopResourceBar(screen, "今日安检值班");

        CreateImage(screen, "HallBand", ColorFromHex(0xA7C7D9), new Vector2(0f, 0.66f), new Vector2(1f, 0.86f), Vector2.zero, Vector2.zero);
        CreateImage(screen, "Conveyor", ColorFromHex(0xD6C2AA), new Vector2(0f, 0.49f), new Vector2(1f, 0.61f), Vector2.zero, Vector2.zero);
        CreateImage(screen, "Scanner", ColorFromHex(0x5C83A2), new Vector2(0.13f, 0.52f), new Vector2(0.42f, 0.74f), Vector2.zero, Vector2.zero);
        CreateImage(screen, "ScannerGlow", ColorFromHex(0xF0D07B, 0.6f), new Vector2(0.43f, 0.54f), new Vector2(0.73f, 0.72f), Vector2.zero, Vector2.zero);
        CreateImage(screen, "OfficerDesk", ColorFromHex(0x7FA76C), new Vector2(0.56f, 0.36f), new Vector2(0.93f, 0.52f), Vector2.zero, Vector2.zero);
        CreateImage(screen, "ScannerShadow", ColorFromHex(0x2B4656, 0.18f), new Vector2(0.1f, 0.5f), new Vector2(0.45f, 0.525f), Vector2.zero, Vector2.zero);
        CreateImage(screen, "DeskShadow", ColorFromHex(0x2B4656, 0.16f), new Vector2(0.54f, 0.34f), new Vector2(0.95f, 0.365f), Vector2.zero, Vector2.zero);
        CreateSprite(screen, "HeroSuitcase", "Art/Security/Bags/suitcase", ColorFromHex(0xFFFFFF, 0.95f), new Vector2(0.46f, 0.5f), new Vector2(0.72f, 0.71f));
        CreateSprite(screen, "HeroShield", "Art/Security/UI/shield", ColorFromHex(0xFFFFFF, 0.95f), new Vector2(0.15f, 0.745f), new Vector2(0.28f, 0.815f));
        CreateSprite(screen, "HeroSearch", "Art/Security/UI/search", ColorFromHex(0xFFFFFF, 0.95f), new Vector2(0.72f, 0.735f), new Vector2(0.85f, 0.81f));

        CreateText(screen, "装了个啥", 64, ColorFromHex(0x253C4A), new Vector2(0.08f, 0.82f), new Vector2(0.92f, 0.91f), TextAnchor.MiddleCenter, FontStyle.Bold);
        CreateText(screen, "看X光、辨轮廓、判行李", 30, ColorFromHex(0x52636F), new Vector2(0.08f, 0.77f), new Vector2(0.92f, 0.82f), TextAnchor.MiddleCenter, FontStyle.Normal);

        CreateButton(screen, "开始安检", new Vector2(0.16f, 0.24f), new Vector2(0.84f, 0.31f), ColorFromHex(0xE56F4F), delegate { StartLevel(0); });
        CreateButton(screen, "关卡地图", new Vector2(0.16f, 0.15f), new Vector2(0.84f, 0.22f), ColorFromHex(0x4F8DB3), ShowLevelMap);
        CreateButton(screen, "分享值班", new Vector2(0.16f, 0.06f), new Vector2(0.84f, 0.13f), ColorFromHex(0x81A35B), delegate
        {
            WechatMiniGameBridge.ShareChallenge("装了个啥", "from=security_check");
        });
    }

    private void ShowLevelMap()
    {
        RectTransform screen = CreateScreen("LevelMap", ColorFromHex(0xEEF3EA));
        CreateImage(screen, "MapBoard", ColorFromHex(0xFFFFFF, 0.72f), new Vector2(0.05f, 0.17f), new Vector2(0.95f, 0.85f), Vector2.zero, Vector2.zero);
        CreateSprite(screen, "MapIcon", "Art/Security/UI/map", ColorFromHex(0xFFFFFF, 0.95f), new Vector2(0.43f, 0.81f), new Vector2(0.57f, 0.88f));
        AddTopResourceBar(screen, "关卡地图");
        CreateText(screen, "装了个啥", 42, ColorFromHex(0x253C4A), new Vector2(0.06f, 0.87f), new Vector2(0.94f, 0.94f), TextAnchor.MiddleCenter, FontStyle.Bold);

        for (int i = 0; i < content.levels.Length; i++)
        {
            int levelIndex = i;
            int column = i % 4;
            int row = i / 4;
            float x = 0.08f + column * 0.23f;
            float y = 0.74f - row * 0.12f;
            Color color = i < 5 ? ColorFromHex(0x80B86B) : i < 10 ? ColorFromHex(0xE0A751) : i < 15 ? ColorFromHex(0xD88466) : ColorFromHex(0x678DB2);
            CreateButton(screen, (i + 1).ToString("00"), new Vector2(x, y), new Vector2(x + 0.16f, y + 0.08f), color, delegate { StartLevel(levelIndex); });
            if ((i + 1) % 5 == 0)
            {
                CreateSprite(screen, "MilestoneStar_" + i, "Art/Security/UI/star", ColorFromHex(0xFFFFFF, 0.92f), new Vector2(x + 0.11f, y + 0.045f), new Vector2(x + 0.18f, y + 0.105f));
            }
        }

        CreateButton(screen, "补满体力", new Vector2(0.08f, 0.08f), new Vector2(0.48f, 0.15f), ColorFromHex(0xE0A751), WatchAdForEnergy);
        CreateButton(screen, "返回首页", new Vector2(0.52f, 0.08f), new Vector2(0.92f, 0.15f), ColorFromHex(0x607D8B), ShowMainScreen);
    }

    private void StartLevel(int index)
    {
        if (content == null || content.levels == null || content.levels.Length == 0)
        {
            ShowMessage("内容缺失", "没有可用关卡，请检查 Resources/Data/security_content.json。", "返回首页", ShowMainScreen);
            return;
        }

        if (!SecurityEconomy.TrySpendEnergy())
        {
            ShowMessage("体力不足", "看一段激励视频即可补满体力。", "看广告补满", delegate
            {
                WechatMiniGameBridge.ShowRewardedAd(delegate (bool success)
                {
                    if (success)
                    {
                        SecurityEconomy.AddEnergyFromAd();
                        StartLevel(index);
                    }
                    else
                    {
                        ShowLevelMap();
                    }
                });
            });
            return;
        }

        currentLevelIndex = Mathf.Clamp(index, 0, content.levels.Length - 1);
        currentLevel = content.levels[currentLevelIndex];
        currentBagIndex = 0;
        correctCount = 0;
        rewardGranted = false;
        currentViewMode = SecurityViewMode.Normal;
        hintMessage = string.Empty;
        ShowInspection();
    }

    private void ShowInspection()
    {
        if (currentLevel == null || currentLevel.bags == null || currentLevel.bags.Length == 0)
        {
            ShowLevelMap();
            return;
        }

        currentBagConfig = currentLevel.bags[Mathf.Clamp(currentBagIndex, 0, currentLevel.bags.Length - 1)];
        currentBag = SecurityContent.ToRuntimeBag(currentBagConfig, content);

        RectTransform screen = CreateScreen("Inspection", ColorFromHex(0xF3F5EC));
        AddTopResourceBar(screen, currentLevel.title);
        CreateText(screen, "第 " + (currentLevelIndex + 1) + " 关  " + (currentBagIndex + 1) + "/" + currentLevel.bags.Length, 24, ColorFromHex(0x60706C), new Vector2(0.06f, 0.875f), new Vector2(0.94f, 0.915f), TextAnchor.MiddleCenter, FontStyle.Bold);

        CreateImage(screen, "ScannerHeader", ColorFromHex(0x24465B, 0.92f), new Vector2(0.045f, 0.83f), new Vector2(0.955f, 0.872f), Vector2.zero, Vector2.zero);
        CreateText(screen, "智能安检通道  A-07", 20, ColorFromHex(0xEAF7FF), new Vector2(0.08f, 0.833f), new Vector2(0.5f, 0.868f), TextAnchor.MiddleLeft, FontStyle.Bold);
        CreateText(screen, "托盘复核中", 20, ColorFromHex(0xFFE08A), new Vector2(0.52f, 0.833f), new Vector2(0.92f, 0.868f), TextAnchor.MiddleRight, FontStyle.Bold);
        CreateImage(screen, "ViewportShadow", ColorFromHex(0x213743, 0.14f), new Vector2(0.065f, 0.275f), new Vector2(0.955f, 0.3f), Vector2.zero, Vector2.zero);
        RectTransform viewport = CreatePanel(screen, "BagViewport", new Vector2(0.045f, 0.31f), new Vector2(0.955f, 0.83f), Color.white);
        SecurityViewRenderer.RenderBag(viewport, currentBag, currentViewMode, gameFont);
        CreateImage(screen, "ScanBeam", ColorFromHex(0x7EEBFF, 0.18f), new Vector2(0.045f, 0.565f), new Vector2(0.955f, 0.605f), Vector2.zero, Vector2.zero);

        CreateViewButton(screen, "人工复核", SecurityViewMode.Normal, new Vector2(0.06f, 0.245f), new Vector2(0.32f, 0.295f));
        CreateViewButton(screen, "X光机", SecurityViewMode.XRay, new Vector2(0.37f, 0.245f), new Vector2(0.63f, 0.295f));
        CreateViewButton(screen, "灰度片", SecurityViewMode.Silhouette, new Vector2(0.68f, 0.245f), new Vector2(0.94f, 0.295f));

        RectTransform cluePanel = CreatePanel(screen, "CluePanel", new Vector2(0.06f, 0.16f), new Vector2(0.94f, 0.225f), ColorFromHex(0xFFF7E1));
        string clue = string.IsNullOrEmpty(hintMessage) ? "安检口径：液体单瓶不超过100ml；刀具、火种、压力罐需移交复检。" : hintMessage;
        CreateText(cluePanel, clue, 24, ColorFromHex(0x5D4B2B), new Vector2(0.04f, 0.08f), new Vector2(0.96f, 0.92f), TextAnchor.MiddleCenter, FontStyle.Bold);

        CreateButton(screen, "规则提示", new Vector2(0.06f, 0.095f), new Vector2(0.94f, 0.145f), ColorFromHex(0xD8A347), UseHint);
        CreateButton(screen, "准予放行", new Vector2(0.06f, 0.025f), new Vector2(0.46f, 0.08f), ColorFromHex(0x6CA869), delegate { SubmitDecision(SecurityDecision.Pass); });
        CreateButton(screen, "移交复检", new Vector2(0.54f, 0.025f), new Vector2(0.94f, 0.08f), ColorFromHex(0xD96754), delegate { SubmitDecision(SecurityDecision.Block); });
    }

    private void CreateViewButton(RectTransform parent, string label, SecurityViewMode mode, Vector2 anchorMin, Vector2 anchorMax)
    {
        Color color = currentViewMode == mode ? ColorFromHex(0x314F67) : ColorFromHex(0xA8B8C2);
        CreateButton(parent, label, anchorMin, anchorMax, color, delegate
        {
            currentViewMode = mode;
            ShowInspection();
        });
    }

    private void UseHint()
    {
        if (!SecurityEconomy.TrySpendHint())
        {
            ShowMessage("提示不足", "看一段激励视频可获得 2 个提示。", "看广告拿提示", delegate
            {
                WechatMiniGameBridge.ShowRewardedAd(delegate (bool success)
                {
                    if (success)
                    {
                        SecurityEconomy.AddRewards(0, 2);
                    }

                    ShowInspection();
                });
            });
            return;
        }

        hintMessage = currentBagConfig == null || string.IsNullOrEmpty(currentBagConfig.hint) ? "复核重点：看金属密度、尖锐轮廓、液体容量和压力罐特征。" : currentBagConfig.hint;
        ShowInspection();
    }

    private void SubmitDecision(SecurityDecision decision)
    {
        SecurityDecisionResult result = SecurityRuleEngine.Evaluate(currentBag);
        bool isCorrect = decision == result.correctDecision;
        if (isCorrect)
        {
            correctCount++;
        }

        ShowFeedback(isCorrect, decision, result);
    }

    private void ShowFeedback(bool isCorrect, SecurityDecision playerDecision, SecurityDecisionResult result)
    {
        RectTransform screen = CreateScreen("Feedback", isCorrect ? ColorFromHex(0xEEF6E7) : ColorFromHex(0xFFF0E8));
        AddTopResourceBar(screen, currentLevel.title);
        CreateImage(screen, "FeedbackCard", ColorFromHex(0xFFFFFF, 0.76f), new Vector2(0.08f, 0.34f), new Vector2(0.92f, 0.78f), Vector2.zero, Vector2.zero);
        CreateSprite(screen, "FeedbackIcon", isCorrect ? "Art/Security/UI/check" : "Art/Security/UI/warning", Color.white, new Vector2(0.39f, 0.78f), new Vector2(0.61f, 0.9f));

        CreateText(screen, isCorrect ? "判断正确" : "需要复核", 56, isCorrect ? ColorFromHex(0x4F8A4C) : ColorFromHex(0xC65344), new Vector2(0.08f, 0.72f), new Vector2(0.92f, 0.82f), TextAnchor.MiddleCenter, FontStyle.Bold);
        CreateText(screen, "你的判断：" + DecisionLabel(playerDecision), 30, ColorFromHex(0x455A64), new Vector2(0.08f, 0.64f), new Vector2(0.92f, 0.7f), TextAnchor.MiddleCenter, FontStyle.Bold);
        CreateText(screen, result.reason, 30, ColorFromHex(0x5B5142), new Vector2(0.1f, 0.46f), new Vector2(0.9f, 0.62f), TextAnchor.MiddleCenter, FontStyle.Normal);

        string button = currentBagIndex >= currentLevel.bags.Length - 1 ? "查看结算" : "下一件行李";
        CreateButton(screen, button, new Vector2(0.16f, 0.2f), new Vector2(0.84f, 0.28f), ColorFromHex(0x4F8DB3), NextBagOrSettlement);
        CreateButton(screen, "回关卡地图", new Vector2(0.16f, 0.1f), new Vector2(0.84f, 0.17f), ColorFromHex(0x607D8B), ShowLevelMap);
    }

    private void NextBagOrSettlement()
    {
        currentBagIndex++;
        hintMessage = string.Empty;
        currentViewMode = SecurityViewMode.Normal;

        if (currentBagIndex >= currentLevel.bags.Length)
        {
            ShowSettlement();
            return;
        }

        ShowInspection();
    }

    private void ShowSettlement()
    {
        if (!rewardGranted)
        {
            SecurityEconomy.AddRewards(currentLevel.rewardCoins, currentLevel.rewardHints);
            rewardGranted = true;
        }

        int total = currentLevel.bags == null ? 0 : currentLevel.bags.Length;
        int stars = correctCount == total ? 3 : correctCount * 2 >= total ? 2 : correctCount > 0 ? 1 : 0;
        string starText = stars == 3 ? "三星通过" : stars == 2 ? "二星通过" : stars == 1 ? "一星通过" : "继续练习";

        RectTransform screen = CreateScreen("Settlement", ColorFromHex(0xF2F5E8));
        CreateImage(screen, "SettlementCard", ColorFromHex(0xFFFFFF, 0.78f), new Vector2(0.08f, 0.5f), new Vector2(0.92f, 0.8f), Vector2.zero, Vector2.zero);
        CreateSprite(screen, "StarOne", "Art/Security/UI/star", stars >= 1 ? Color.white : ColorFromHex(0xB8B8B8, 0.55f), new Vector2(0.24f, 0.79f), new Vector2(0.39f, 0.88f));
        CreateSprite(screen, "StarTwo", "Art/Security/UI/star", stars >= 2 ? Color.white : ColorFromHex(0xB8B8B8, 0.55f), new Vector2(0.425f, 0.81f), new Vector2(0.575f, 0.905f));
        CreateSprite(screen, "StarThree", "Art/Security/UI/star", stars >= 3 ? Color.white : ColorFromHex(0xB8B8B8, 0.55f), new Vector2(0.61f, 0.79f), new Vector2(0.76f, 0.88f));
        AddTopResourceBar(screen, "本关结算");
        CreateText(screen, starText, 58, ColorFromHex(0xC07A32), new Vector2(0.08f, 0.72f), new Vector2(0.92f, 0.82f), TextAnchor.MiddleCenter, FontStyle.Bold);
        CreateText(screen, "正确 " + correctCount + " / " + total + "    奖励 +" + currentLevel.rewardCoins + " 金币  +" + currentLevel.rewardHints + " 提示", 28, ColorFromHex(0x455A64), new Vector2(0.08f, 0.58f), new Vector2(0.92f, 0.66f), TextAnchor.MiddleCenter, FontStyle.Bold);

        if (currentLevelIndex + 1 < content.levels.Length)
        {
            CreateButton(screen, "下一关", new Vector2(0.16f, 0.33f), new Vector2(0.84f, 0.41f), ColorFromHex(0xE56F4F), delegate { StartLevel(currentLevelIndex + 1); });
        }

        CreateButton(screen, "关卡地图", new Vector2(0.16f, 0.22f), new Vector2(0.84f, 0.3f), ColorFromHex(0x4F8DB3), ShowLevelMap);
        CreateButton(screen, "看广告补体力", new Vector2(0.16f, 0.11f), new Vector2(0.84f, 0.19f), ColorFromHex(0xD8A347), WatchAdForEnergy);
    }

    private void WatchAdForEnergy()
    {
        WechatMiniGameBridge.ShowRewardedAd(delegate (bool success)
        {
            if (success)
            {
                SecurityEconomy.AddEnergyFromAd();
            }

            ShowLevelMap();
        });
    }

    private void ShowMessage(string title, string body, string actionLabel, Action action)
    {
        RectTransform screen = CreateScreen("Message", ColorFromHex(0xF4F0E5));
        AddTopResourceBar(screen, title);
        CreateText(screen, title, 50, ColorFromHex(0x253C4A), new Vector2(0.08f, 0.62f), new Vector2(0.92f, 0.72f), TextAnchor.MiddleCenter, FontStyle.Bold);
        CreateText(screen, body, 30, ColorFromHex(0x53656F), new Vector2(0.12f, 0.42f), new Vector2(0.88f, 0.58f), TextAnchor.MiddleCenter, FontStyle.Normal);
        CreateButton(screen, actionLabel, new Vector2(0.16f, 0.24f), new Vector2(0.84f, 0.32f), ColorFromHex(0xE56F4F), action);
        CreateButton(screen, "关卡地图", new Vector2(0.16f, 0.13f), new Vector2(0.84f, 0.21f), ColorFromHex(0x607D8B), ShowLevelMap);
    }

    private void AddTopResourceBar(RectTransform parent, string title)
    {
        CreateImage(parent, "TopBar", ColorFromHex(0x263C4A), new Vector2(0f, 0.92f), new Vector2(1f, 1f), Vector2.zero, Vector2.zero);
        CreateText(parent, title, 26, Color.white, new Vector2(0.04f, 0.96f), new Vector2(0.96f, 0.995f), TextAnchor.MiddleLeft, FontStyle.Bold);
        CreateResourcePill(parent, "EnergyPill", "Art/Security/UI/battery", "体力 " + SecurityEconomy.Energy + "/" + SecurityEconomy.EnergyMax, new Vector2(0.04f, 0.923f), new Vector2(0.34f, 0.958f), ColorFromHex(0x315D73));
        CreateResourcePill(parent, "HintPill", "Art/Security/UI/hint", "提示 " + SecurityEconomy.Hints, new Vector2(0.36f, 0.923f), new Vector2(0.64f, 0.958f), ColorFromHex(0xA46C2F));
        CreateResourcePill(parent, "CoinPill", "Art/Security/UI/coin", "金币 " + SecurityEconomy.Coins, new Vector2(0.66f, 0.923f), new Vector2(0.96f, 0.958f), ColorFromHex(0x866539));
    }

    private void BuildOrAdoptCanvas()
    {
        canvas = FindObjectOfType<Canvas>();
        if (canvas == null)
        {
            GameObject canvasObject = new GameObject("SecurityCheck_Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvas = canvasObject.GetComponent<Canvas>();
            DontDestroyOnLoad(canvasObject);
        }

        canvas.renderMode = RenderMode.ScreenSpaceOverlay;

        CanvasScaler scaler = canvas.GetComponent<CanvasScaler>();
        if (scaler == null)
        {
            scaler = canvas.gameObject.AddComponent<CanvasScaler>();
        }

        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(DesignWidth, DesignHeight);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;

        if (canvas.GetComponent<GraphicRaycaster>() == null)
        {
            canvas.gameObject.AddComponent<GraphicRaycaster>();
        }

        GameObject rootObject = new GameObject("SecurityCheck_Root", typeof(RectTransform));
        rootObject.transform.SetParent(canvas.transform, false);
        root = rootObject.GetComponent<RectTransform>();
        root.anchorMin = Vector2.zero;
        root.anchorMax = Vector2.one;
        root.offsetMin = Vector2.zero;
        root.offsetMax = Vector2.zero;
    }

    private static void EnsureEventSystem()
    {
        if (FindObjectOfType<EventSystem>() != null)
        {
            return;
        }

        GameObject eventSystem = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        DontDestroyOnLoad(eventSystem);
    }

    private RectTransform CreateScreen(string name, Color background)
    {
        Clear(root);
        RectTransform screen = CreatePanel(root, name, Vector2.zero, Vector2.one, background);
        return screen;
    }

    private RectTransform CreatePanel(Transform parent, string name, Vector2 anchorMin, Vector2 anchorMax, Color color)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        Image image = go.GetComponent<Image>();
        image.color = color;
        return rect;
    }

    private Image CreateImage(Transform parent, string name, Color color, Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = offsetMin;
        rect.offsetMax = offsetMax;
        Image image = go.GetComponent<Image>();
        image.color = color;
        return image;
    }

    private Sprite Sprite(string path)
    {
        if (string.IsNullOrEmpty(path))
        {
            return null;
        }

        Sprite sprite;
        if (spriteCache.TryGetValue(path, out sprite))
        {
            return sprite;
        }

        sprite = Resources.Load<Sprite>(path);
        spriteCache[path] = sprite;
        return sprite;
    }

    private Image CreateSprite(Transform parent, string name, string spritePath, Color color, Vector2 anchorMin, Vector2 anchorMax)
    {
        Image image = CreateImage(parent, name, color, anchorMin, anchorMax, Vector2.zero, Vector2.zero);
        image.sprite = Sprite(spritePath);
        image.preserveAspect = true;
        image.raycastTarget = false;
        return image;
    }

    private void CreateResourcePill(Transform parent, string name, string iconPath, string value, Vector2 anchorMin, Vector2 anchorMax, Color color)
    {
        RectTransform pill = CreatePanel(parent, name, anchorMin, anchorMax, color);
        CreateSprite(pill, name + "_Icon", iconPath, Color.white, new Vector2(0.08f, 0.12f), new Vector2(0.34f, 0.88f));
        CreateText(pill, value, 18, Color.white, new Vector2(0.34f, 0.02f), new Vector2(0.96f, 0.98f), TextAnchor.MiddleCenter, FontStyle.Bold);
    }

    private Text CreateText(Transform parent, string value, int size, Color color, Vector2 anchorMin, Vector2 anchorMax, TextAnchor alignment, FontStyle style)
    {
        GameObject go = new GameObject("Text", typeof(RectTransform), typeof(Text));
        go.transform.SetParent(parent, false);
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        Text text = go.GetComponent<Text>();
        text.font = gameFont;
        text.fontSize = size;
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize = 14;
        text.resizeTextMaxSize = size;
        text.horizontalOverflow = HorizontalWrapMode.Wrap;
        text.verticalOverflow = VerticalWrapMode.Truncate;
        text.alignment = alignment;
        text.fontStyle = style;
        text.color = color;
        text.text = value;
        return text;
    }

    private Button CreateButton(Transform parent, string label, Vector2 anchorMin, Vector2 anchorMax, Color color, Action onClick)
    {
        GameObject go = new GameObject("Button_" + label, typeof(RectTransform), typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        Image image = go.GetComponent<Image>();
        image.color = color;

        Button button = go.GetComponent<Button>();
        ColorBlock colors = button.colors;
        colors.normalColor = color;
        colors.highlightedColor = Color.Lerp(color, Color.white, 0.12f);
        colors.pressedColor = Color.Lerp(color, Color.black, 0.12f);
        colors.selectedColor = color;
        button.colors = colors;
        button.onClick.AddListener(delegate { if (onClick != null) onClick(); });

        string iconPath = SelectButtonIcon(color, anchorMin, anchorMax);
        if (!string.IsNullOrEmpty(iconPath))
        {
            CreateImage(rect, "ButtonIconPlate", ColorFromHex(0xFFFFFF, 0.16f), new Vector2(0.055f, 0.17f), new Vector2(0.205f, 0.83f), Vector2.zero, Vector2.zero);
            CreateSprite(rect, "ButtonIcon", iconPath, Color.white, new Vector2(0.075f, 0.24f), new Vector2(0.185f, 0.76f));
            CreateText(rect, label, 28, Color.white, new Vector2(0.2f, 0.05f), new Vector2(0.96f, 0.95f), TextAnchor.MiddleCenter, FontStyle.Bold);
        }
        else
        {
            CreateText(rect, label, 28, Color.white, new Vector2(0.04f, 0.05f), new Vector2(0.96f, 0.95f), TextAnchor.MiddleCenter, FontStyle.Bold);
        }

        return button;
    }

    private static string SelectButtonIcon(Color color, Vector2 anchorMin, Vector2 anchorMax)
    {
        float width = anchorMax.x - anchorMin.x;
        float height = anchorMax.y - anchorMin.y;
        if (width < 0.25f && height < 0.09f)
        {
            return null;
        }

        if (Approximately(color, ColorFromHex(0xD96754)))
        {
            return "Art/Security/UI/block";
        }

        if (Approximately(color, ColorFromHex(0x6CA869)) || Approximately(color, ColorFromHex(0x80B86B)))
        {
            return "Art/Security/UI/check";
        }

        if (Approximately(color, ColorFromHex(0xD8A347)) || Approximately(color, ColorFromHex(0xE0A751)))
        {
            return "Art/Security/UI/hint";
        }

        if (Approximately(color, ColorFromHex(0x4F8DB3)) || Approximately(color, ColorFromHex(0x607D8B)))
        {
            return "Art/Security/UI/map";
        }

        if (Approximately(color, ColorFromHex(0xE56F4F)))
        {
            return "Art/Security/UI/search";
        }

        return "Art/Security/UI/sparkles";
    }

    private static bool Approximately(Color left, Color right)
    {
        return Mathf.Abs(left.r - right.r) < 0.01f
            && Mathf.Abs(left.g - right.g) < 0.01f
            && Mathf.Abs(left.b - right.b) < 0.01f;
    }

    private static void Clear(Transform parent)
    {
        if (parent == null)
        {
            return;
        }

        for (int i = parent.childCount - 1; i >= 0; i--)
        {
            Destroy(parent.GetChild(i).gameObject);
        }
    }

    private static string DecisionLabel(SecurityDecision decision)
    {
        return decision == SecurityDecision.Pass ? "放行" : "拦截";
    }

    private static Color ColorFromHex(uint rgb, float alpha = 1f)
    {
        float r = ((rgb >> 16) & 0xFF) / 255f;
        float g = ((rgb >> 8) & 0xFF) / 255f;
        float b = (rgb & 0xFF) / 255f;
        return new Color(r, g, b, alpha);
    }
}
