using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public enum SecurityViewMode
{
    Normal,
    XRay,
    Silhouette
}

public static class SecurityViewRenderer
{
    private static readonly Dictionary<string, Sprite> SpriteCache = new Dictionary<string, Sprite>();

    public static void RenderBag(Transform parent, SecurityBagRuntime bag, SecurityViewMode mode, Font font)
    {
        Clear(parent);

        Color background = mode == SecurityViewMode.XRay
            ? ColorFromHex(0x17345F)
            : mode == SecurityViewMode.Silhouette ? ColorFromHex(0xD9DED7) : ColorFromHex(0xF7EFE2);
        Color bagColor = mode == SecurityViewMode.XRay
            ? ColorFromHex(0x244C86)
            : mode == SecurityViewMode.Silhouette ? ColorFromHex(0xAAB0AB) : ColorFromHex(0x8CB9D8);
        Color trimColor = mode == SecurityViewMode.XRay
            ? ColorFromHex(0x72BDEB)
            : mode == SecurityViewMode.Silhouette ? ColorFromHex(0x747B75) : ColorFromHex(0x4F84A8);

        CreateImage(parent, "ViewBackground", background, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        CreateImage(parent, "ConveyorBand", mode == SecurityViewMode.XRay ? ColorFromHex(0x10274B) : ColorFromHex(0xD9CCC0), new Vector2(0f, 0.035f), new Vector2(1f, 0.145f), Vector2.zero, Vector2.zero);
        DrawTray(parent, mode);
        DrawScannerGrid(parent, mode);
        CreateImage(parent, "BagShell", ColorWithAlpha(bagColor, mode == SecurityViewMode.XRay ? 0.62f : 0.5f), new Vector2(0.04f, 0.16f), new Vector2(0.96f, 0.86f), Vector2.zero, Vector2.zero);
        CreateSprite(parent, "BagWatermark", Sprite("Art/Security/Bags/suitcase"), BagSpriteColor(mode), new Vector2(0.08f, 0.2f), new Vector2(0.92f, 0.82f));
        CreateImage(parent, "BagTrimTop", ColorWithAlpha(trimColor, 0.78f), new Vector2(0.1f, 0.79f), new Vector2(0.9f, 0.83f), Vector2.zero, Vector2.zero);
        CreateImage(parent, "BagTrimBottom", ColorWithAlpha(trimColor, 0.78f), new Vector2(0.1f, 0.18f), new Vector2(0.9f, 0.22f), Vector2.zero, Vector2.zero);

        SecurityItemRuntime[] items = bag == null || bag.items == null ? new SecurityItemRuntime[0] : bag.items;
        if (items.Length == 0)
        {
            CreateText(parent, "空包复核", font, 30, ColorFromHex(0x52606B), new Vector2(0.16f, 0.42f), new Vector2(0.84f, 0.58f), TextAnchor.MiddleCenter);
            return;
        }

        for (int i = 0; i < items.Length; i++)
        {
            SecurityItemRuntime item = items[i];
            bool suspicious = item != null && IsSuspicious(item.tags);
            Color itemColor = ItemColor(item, suspicious, mode);
            RectSpec spec = ItemRect(item, i, items.Length);
            Vector2 anchorMin = spec.min;
            Vector2 anchorMax = spec.max;

            if (suspicious && mode != SecurityViewMode.Normal)
            {
                Image glow = CreateImage(parent, "SuspiciousGlow_" + i, ColorFromHex(0xFFE082, 0.32f), anchorMin - new Vector2(0.035f, 0.03f), anchorMax + new Vector2(0.035f, 0.03f), Vector2.zero, Vector2.zero);
                Rotate(glow, spec.rotation);
            }

            CreateLooseItem(parent, item, mode, itemColor, anchorMin, anchorMax, spec.rotation);
        }
    }

    private static void DrawTray(Transform parent, SecurityViewMode mode)
    {
        Color tray = mode == SecurityViewMode.XRay ? ColorFromHex(0x0B1C35, 0.55f) : ColorFromHex(0xBCC6C7, 0.7f);
        Color lip = mode == SecurityViewMode.XRay ? ColorFromHex(0x55BFEA, 0.38f) : ColorFromHex(0x7B8788, 0.55f);
        CreateImage(parent, "TrayBed", tray, new Vector2(0.035f, 0.055f), new Vector2(0.965f, 0.19f), Vector2.zero, Vector2.zero);
        CreateImage(parent, "TrayFrontLip", lip, new Vector2(0.035f, 0.045f), new Vector2(0.965f, 0.075f), Vector2.zero, Vector2.zero);
        CreateImage(parent, "TrayBackLip", lip, new Vector2(0.035f, 0.18f), new Vector2(0.965f, 0.205f), Vector2.zero, Vector2.zero);
    }

    private static void DrawScannerGrid(Transform parent, SecurityViewMode mode)
    {
        Color lineColor = mode == SecurityViewMode.XRay ? ColorFromHex(0x65D8FF, 0.12f) : ColorFromHex(0xFFFFFF, 0.18f);

        for (int i = 1; i < 6; i++)
        {
            float x = i / 6f;
            CreateImage(parent, "GridVertical_" + i, lineColor, new Vector2(x - 0.002f, 0.12f), new Vector2(x + 0.002f, 0.88f), Vector2.zero, Vector2.zero);
        }

        for (int i = 1; i < 6; i++)
        {
            float y = 0.12f + i * 0.125f;
            CreateImage(parent, "GridHorizontal_" + i, lineColor, new Vector2(0.04f, y - 0.002f), new Vector2(0.96f, y + 0.002f), Vector2.zero, Vector2.zero);
        }
    }

    private static void CreateLooseItem(Transform parent, SecurityItemRuntime item, SecurityViewMode mode, Color itemColor, Vector2 anchorMin, Vector2 anchorMax, float rotation)
    {
        string itemId = item == null ? "unknown" : item.id;
        Sprite sprite = Sprite("Art/Security/Items/" + itemId);

        if (sprite == null)
        {
            Image shape = CreateImage(parent, "ItemShape_" + itemId, itemColor, anchorMin, anchorMax, Vector2.zero, Vector2.zero);
            Rotate(shape, rotation);
            return;
        }

        Image shadow = CreateSprite(parent, "ItemShadow_" + itemId, sprite, ShadowColor(mode), anchorMin + new Vector2(0.012f, -0.012f), anchorMax + new Vector2(0.012f, -0.012f));
        Rotate(shadow, rotation);
        Image icon = CreateSprite(parent, "ItemIcon_" + itemId, sprite, ItemSpriteColor(item, mode, itemColor), anchorMin, anchorMax);
        Rotate(icon, rotation);
    }

    private struct RectSpec
    {
        public readonly Vector2 min;
        public readonly Vector2 max;
        public readonly float rotation;

        public RectSpec(Vector2 min, Vector2 max, float rotation)
        {
            this.min = min;
            this.max = max;
            this.rotation = rotation;
        }
    }

    private static RectSpec ItemRect(SecurityItemRuntime item, int index, int count)
    {
        Vector2[] centers =
        {
            new Vector2(0.34f, 0.63f),
            new Vector2(0.64f, 0.57f),
            new Vector2(0.47f, 0.42f),
            new Vector2(0.25f, 0.38f),
            new Vector2(0.72f, 0.36f),
            new Vector2(0.43f, 0.27f)
        };
        float[] rotations = { -12f, 9f, -5f, 15f, -16f, 7f };

        Vector2 center = centers[index % centers.Length];
        if (count <= 2)
        {
            center.y += 0.06f;
            center.x += index == 0 ? 0.04f : -0.04f;
        }

        Vector2 size = ItemSize(item);
        Vector2 min = center - size * 0.5f;
        Vector2 max = center + size * 0.5f;
        min.x = Mathf.Clamp(min.x, 0.06f, 0.78f);
        max.x = Mathf.Clamp(max.x, 0.22f, 0.94f);
        min.y = Mathf.Clamp(min.y, 0.16f, 0.74f);
        max.y = Mathf.Clamp(max.y, 0.3f, 0.86f);
        return new RectSpec(min, max, rotations[index % rotations.Length]);
    }

    private static Vector2 ItemSize(SecurityItemRuntime item)
    {
        string id = item == null ? string.Empty : item.id;
        if (id.Contains("laptop") || id.Contains("book"))
        {
            return new Vector2(0.38f, 0.24f);
        }

        if (id.Contains("umbrella") || id.Contains("knife") || id.Contains("scissors"))
        {
            return new Vector2(0.4f, 0.22f);
        }

        if (id.Contains("water-large") || id.Contains("spray") || id.Contains("power-bank"))
        {
            return new Vector2(0.34f, 0.26f);
        }

        if (id.Contains("keys") || id.Contains("lighter"))
        {
            return new Vector2(0.29f, 0.2f);
        }

        return new Vector2(0.36f, 0.25f);
    }

    private static bool IsSuspicious(SecurityRuleTag tags)
    {
        return (tags & SecurityRuleTag.Dangerous) != 0
            || (tags & SecurityRuleTag.OversizeLiquid) != 0
            || (tags & SecurityRuleTag.DamagedBattery) != 0
            || (tags & SecurityRuleTag.SharpHidden) != 0;
    }

    private static string LabelForMode(SecurityItemRuntime item, SecurityViewMode mode)
    {
        if (item == null)
        {
            return "未知";
        }

        if (mode == SecurityViewMode.XRay)
        {
            return item.xrayLabel;
        }

        if (mode == SecurityViewMode.Silhouette)
        {
            return item.silhouetteLabel;
        }

        return item.normalLabel;
    }

    private static Color ItemColor(SecurityItemRuntime item, bool suspicious, SecurityViewMode mode)
    {
        if (mode == SecurityViewMode.XRay)
        {
            if (suspicious)
            {
                return ColorFromHex(0xF7A441);
            }

            return item != null && (item.tags & SecurityRuleTag.Liquid) != 0 ? ColorFromHex(0x6ED4FF) : ColorFromHex(0x6CB0D8);
        }

        if (mode == SecurityViewMode.Silhouette)
        {
            return suspicious ? ColorFromHex(0xFFE082) : ColorFromHex(0x858C87);
        }

        if (suspicious)
        {
            return ColorFromHex(0xD98A66);
        }

        return item != null && item.category == SecurityItemCategory.Distractor ? ColorFromHex(0xF0C567) : ColorFromHex(0xB7D99A);
    }

    private static Color BagSpriteColor(SecurityViewMode mode)
    {
        if (mode == SecurityViewMode.XRay)
        {
            return ColorFromHex(0xC9F2FF, 0.16f);
        }

        if (mode == SecurityViewMode.Silhouette)
        {
            return ColorFromHex(0x4F5652, 0.18f);
        }

        return ColorFromHex(0xFFFFFF, 0.18f);
    }

    private static Color ItemSpriteColor(SecurityItemRuntime item, SecurityViewMode mode, Color fallbackColor)
    {
        if (mode == SecurityViewMode.XRay)
        {
            if (item != null && (item.tags & SecurityRuleTag.Liquid) != 0)
            {
                return ColorFromHex(0x54D8FF, 0.82f);
            }

            if (item != null && IsSuspicious(item.tags))
            {
                return ColorFromHex(0xFF8C3A, 0.88f);
            }

            if (item != null && (item.tags & SecurityRuleTag.PowerBank) != 0)
            {
                return ColorFromHex(0x7CD7A6, 0.82f);
            }

            return ColorFromHex(0xAEEFFF, 0.76f);
        }

        if (mode == SecurityViewMode.Silhouette)
        {
            return ColorFromHex(0x303633, 0.78f);
        }

        return Color.white;
    }

    private static Color ShadowColor(SecurityViewMode mode)
    {
        if (mode == SecurityViewMode.XRay)
        {
            return ColorFromHex(0x07142B, 0.28f);
        }

        if (mode == SecurityViewMode.Silhouette)
        {
            return ColorFromHex(0x202420, 0.18f);
        }

        return ColorFromHex(0x3B4B55, 0.22f);
    }

    private static Image CreateImage(Transform parent, string name, Color color, Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = offsetMin;
        rect.offsetMax = offsetMax;
        Image image = go.GetComponent<Image>();
        image.color = color;
        return image;
    }

    private static Image CreateSprite(Transform parent, string name, Sprite sprite, Color color, Vector2 anchorMin, Vector2 anchorMax)
    {
        if (sprite == null)
        {
            return null;
        }

        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        Image image = go.GetComponent<Image>();
        image.sprite = sprite;
        image.color = color;
        image.preserveAspect = true;
        image.raycastTarget = false;
        return image;
    }

    private static void Rotate(Image image, float degrees)
    {
        if (image == null)
        {
            return;
        }

        image.rectTransform.localRotation = Quaternion.Euler(0f, 0f, degrees);
    }

    private static Color ColorWithAlpha(Color color, float alpha)
    {
        color.a = alpha;
        return color;
    }

    private static Text CreateText(Transform parent, string value, Font font, int size, Color color, Vector2 anchorMin, Vector2 anchorMax, TextAnchor alignment)
    {
        GameObject go = new GameObject("Text", typeof(RectTransform), typeof(Text));
        go.transform.SetParent(parent, false);
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        Text text = go.GetComponent<Text>();
        text.font = font;
        text.fontSize = size;
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize = 14;
        text.resizeTextMaxSize = size;
        text.alignment = alignment;
        text.color = color;
        text.text = value;
        return text;
    }

    private static void Clear(Transform parent)
    {
        if (parent == null)
        {
            return;
        }

        for (int i = parent.childCount - 1; i >= 0; i--)
        {
            GameObject child = parent.GetChild(i).gameObject;
            if (Application.isPlaying)
            {
                Object.Destroy(child);
            }
            else
            {
                Object.DestroyImmediate(child);
            }
        }
    }

    private static Color ColorFromHex(uint rgb, float alpha = 1f)
    {
        float r = ((rgb >> 16) & 0xFF) / 255f;
        float g = ((rgb >> 8) & 0xFF) / 255f;
        float b = (rgb & 0xFF) / 255f;
        return new Color(r, g, b, alpha);
    }

    private static Sprite Sprite(string path)
    {
        if (string.IsNullOrEmpty(path))
        {
            return null;
        }

        Sprite sprite;
        if (!SpriteCache.TryGetValue(path, out sprite))
        {
            sprite = Resources.Load<Sprite>(path);
            SpriteCache[path] = sprite;
        }

        return sprite;
    }
}
