using System;
using System.Collections.Generic;
using UnityEngine;

public static class SecurityContent
{
    private const string ResourcePath = "Data/security_content";

    public static SecurityContentPack Load()
    {
        TextAsset asset = Resources.Load<TextAsset>(ResourcePath);
        if (asset == null)
        {
            Debug.LogWarning("Data/security_content.json missing. Using fallback security content.");
            return Fallback();
        }

        try
        {
            SecurityContentPack pack = JsonUtility.FromJson<SecurityContentPack>(asset.text);
            return IsValid(pack) ? pack : Fallback();
        }
        catch (Exception exception)
        {
            Debug.LogWarning("Failed to parse security content: " + exception.Message);
            return Fallback();
        }
    }

    public static bool IsValid(SecurityContentPack pack)
    {
        if (pack == null || pack.items == null || pack.items.Length == 0 || pack.levels == null || pack.levels.Length == 0)
        {
            return false;
        }

        for (int i = 0; i < pack.levels.Length; i++)
        {
            if (pack.levels[i] == null || pack.levels[i].bags == null || pack.levels[i].bags.Length == 0)
            {
                return false;
            }
        }

        return true;
    }

    public static SecurityBagRuntime ToRuntimeBag(SecurityBagConfig bag, SecurityContentPack pack)
    {
        Dictionary<string, SecurityItemConfig> catalog = BuildCatalog(pack);
        List<SecurityItemRuntime> items = new List<SecurityItemRuntime>();
        string[] itemIds = bag != null && bag.itemIds != null ? bag.itemIds : new string[0];

        for (int i = 0; i < itemIds.Length; i++)
        {
            SecurityItemConfig config;
            if (!catalog.TryGetValue(itemIds[i], out config))
            {
                items.Add(new SecurityItemRuntime("unknown", SecurityItemCategory.Dangerous, SecurityRuleTag.Dangerous));
                continue;
            }

            items.Add(new SecurityItemRuntime(config.id, ParseCategory(config.category), ParseTags(config.tags), config.name, config.normal, config.xray, config.silhouette));
        }

        string id = bag == null ? "bag" : bag.id;
        string reason = bag == null ? string.Empty : bag.reason;
        string expectedDecision = bag == null ? string.Empty : bag.expectedDecision;
        return new SecurityBagRuntime(id, items.ToArray(), ParseDecision(expectedDecision), reason);
    }

    public static SecurityItemConfig FindItem(SecurityContentPack pack, string itemId)
    {
        if (pack == null || pack.items == null || string.IsNullOrEmpty(itemId))
        {
            return null;
        }

        for (int i = 0; i < pack.items.Length; i++)
        {
            if (pack.items[i] != null && pack.items[i].id == itemId)
            {
                return pack.items[i];
            }
        }

        return null;
    }

    public static SecurityItemCategory ParseCategory(string value)
    {
        SecurityItemCategory parsed;
        return Enum.TryParse(value, true, out parsed) ? parsed : SecurityItemCategory.Safe;
    }

    public static SecurityDecision ParseDecision(string value)
    {
        return string.Equals(value, "block", StringComparison.OrdinalIgnoreCase) ? SecurityDecision.Block : SecurityDecision.Pass;
    }

    public static SecurityRuleTag ParseTags(string[] values)
    {
        SecurityRuleTag tags = SecurityRuleTag.None;
        if (values == null)
        {
            return tags;
        }

        for (int i = 0; i < values.Length; i++)
        {
            SecurityRuleTag parsed;
            if (Enum.TryParse(values[i], true, out parsed))
            {
                tags |= parsed;
            }
        }

        return tags;
    }

    private static Dictionary<string, SecurityItemConfig> BuildCatalog(SecurityContentPack pack)
    {
        Dictionary<string, SecurityItemConfig> catalog = new Dictionary<string, SecurityItemConfig>();
        if (pack == null || pack.items == null)
        {
            return catalog;
        }

        for (int i = 0; i < pack.items.Length; i++)
        {
            SecurityItemConfig item = pack.items[i];
            if (item != null && !string.IsNullOrEmpty(item.id))
            {
                catalog[item.id] = item;
            }
        }

        return catalog;
    }

    private static SecurityContentPack Fallback()
    {
        SecurityContentPack pack = new SecurityContentPack();
        pack.items = new[]
        {
            new SecurityItemConfig { id = "shirt", name = "衣服", category = "Safe", tags = new[] { "Safe" }, normal = "衣物", xray = "soft", silhouette = "fold" },
            new SecurityItemConfig { id = "knife", name = "小刀", category = "Dangerous", tags = new[] { "Dangerous" }, normal = "不可见", xray = "sharp", silhouette = "knife" },
            new SecurityItemConfig { id = "water-large", name = "大瓶水", category = "Conditional", tags = new[] { "Liquid", "OversizeLiquid" }, normal = "水瓶", xray = "liquid", silhouette = "bottle" }
        };
        pack.levels = new[]
        {
            new SecurityLevelConfig
            {
                id = "fallback-01",
                title = "临时安检",
                difficulty = "兜底",
                rewardCoins = 10,
                rewardHints = 0,
                bags = new[]
                {
                    new SecurityBagConfig { id = "fallback-01-01", skin = "blue-suitcase", itemIds = new[] { "shirt" }, expectedDecision = "pass", reason = "普通衣物可放行", hint = "没有尖锐轮廓" },
                    new SecurityBagConfig { id = "fallback-01-02", skin = "red-suitcase", itemIds = new[] { "knife" }, expectedDecision = "block", reason = "发现刀具，需要拦截", hint = "X光里有刀形高亮" },
                    new SecurityBagConfig { id = "fallback-01-03", skin = "green-duffel", itemIds = new[] { "water-large" }, expectedDecision = "block", reason = "液体超量，需要拦截", hint = "瓶身明显偏大" }
                }
            }
        };
        return pack;
    }
}
