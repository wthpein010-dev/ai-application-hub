using System;

public enum SecurityDecision
{
    Pass,
    Block
}

public enum SecurityItemCategory
{
    Safe,
    Dangerous,
    Conditional,
    Distractor
}

[Flags]
public enum SecurityRuleTag
{
    None = 0,
    Safe = 1 << 0,
    Dangerous = 1 << 1,
    Liquid = 1 << 2,
    OversizeLiquid = 1 << 3,
    PowerBank = 1 << 4,
    DamagedBattery = 1 << 5,
    SharpHidden = 1 << 6,
    ToyLookalike = 1 << 7
}

public sealed class SecurityItemRuntime
{
    public readonly string id;
    public readonly string displayName;
    public readonly SecurityItemCategory category;
    public readonly SecurityRuleTag tags;
    public readonly string normalLabel;
    public readonly string xrayLabel;
    public readonly string silhouetteLabel;

    public SecurityItemRuntime(string id, SecurityItemCategory category, SecurityRuleTag tags, string displayName = null, string normalLabel = null, string xrayLabel = null, string silhouetteLabel = null)
    {
        this.id = string.IsNullOrEmpty(id) ? "unknown" : id;
        this.displayName = string.IsNullOrEmpty(displayName) ? this.id : displayName;
        this.category = category;
        this.tags = tags;
        this.normalLabel = string.IsNullOrEmpty(normalLabel) ? this.displayName : normalLabel;
        this.xrayLabel = string.IsNullOrEmpty(xrayLabel) ? this.displayName : xrayLabel;
        this.silhouetteLabel = string.IsNullOrEmpty(silhouetteLabel) ? this.displayName : silhouetteLabel;
    }
}

public sealed class SecurityBagRuntime
{
    public readonly string id;
    public readonly SecurityItemRuntime[] items;
    public readonly SecurityDecision expectedDecision;
    public readonly string configuredReason;

    public SecurityBagRuntime(string id, SecurityItemRuntime[] items, SecurityDecision expectedDecision, string configuredReason)
    {
        this.id = string.IsNullOrEmpty(id) ? "bag" : id;
        this.items = items ?? new SecurityItemRuntime[0];
        this.expectedDecision = expectedDecision;
        this.configuredReason = string.IsNullOrEmpty(configuredReason) ? "按安检规则处理" : configuredReason;
    }
}

public sealed class SecurityDecisionResult
{
    public readonly SecurityDecision correctDecision;
    public readonly string reason;
    public readonly string suspiciousItemId;

    public SecurityDecisionResult(SecurityDecision correctDecision, string reason, string suspiciousItemId)
    {
        this.correctDecision = correctDecision;
        this.reason = string.IsNullOrEmpty(reason) ? "未发现违规物品" : reason;
        this.suspiciousItemId = string.IsNullOrEmpty(suspiciousItemId) ? string.Empty : suspiciousItemId;
    }
}

[Serializable]
public sealed class SecurityContentPack
{
    public SecurityItemConfig[] items;
    public SecurityLevelConfig[] levels;
}

[Serializable]
public sealed class SecurityItemConfig
{
    public string id;
    public string name;
    public string category;
    public string[] tags;
    public string normal;
    public string xray;
    public string silhouette;
}

[Serializable]
public sealed class SecurityLevelConfig
{
    public string id;
    public string title;
    public string difficulty;
    public SecurityBagConfig[] bags;
    public int rewardCoins;
    public int rewardHints;
}

[Serializable]
public sealed class SecurityBagConfig
{
    public string id;
    public string skin;
    public string[] itemIds;
    public string expectedDecision;
    public string reason;
    public string hint;
}
