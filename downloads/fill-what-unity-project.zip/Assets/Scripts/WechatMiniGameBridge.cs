using System;
using UnityEngine;

public static class WechatMiniGameBridge
{
    public static void ShowRewardedAd(Action<bool> onCompleted)
    {
        // Replace this simulation with the official WeChat Mini Game Unity SDK call
        // after importing the SDK package into the Unity project.
        Debug.Log("Simulated WeChat rewarded video completed.");
        if (onCompleted != null)
        {
            onCompleted(true);
        }
    }

    public static void ShareChallenge(string title, string query)
    {
        Debug.Log("Simulated WeChat share: " + title + "?" + query);
    }
}
