using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class FillWhatGame : MonoBehaviour
{
    private const int DesignWidth = 750;
    private const int DesignHeight = 1624;
    private const int EnergyMax = 5;
    private const int StartCoins = 999;
    private const int StartHints = 3;
    private const string EnergyKey = "FillWhat.Energy";
    private const string NextEnergyAtKey = "FillWhat.NextEnergyAt";
    private const string CoinKey = "FillWhat.Coins";
    private const string HintKey = "FillWhat.Hints";
    private const string CurrentLevelKey = "FillWhat.CurrentLevel";

    private static FillWhatGame instance;

    private readonly Dictionary<string, Sprite> spriteCache = new Dictionary<string, Sprite>();
    private readonly List<SlotView> slots = new List<SlotView>();
    private readonly List<TileView> tiles = new List<TileView>();
    private readonly List<Text> resourceTexts = new List<Text>();
    private readonly System.Random random = new System.Random();

    private Canvas canvas;
    private RectTransform uiRoot;
    private Font gameFont;
    private GameObject currentScreen;
    private GameObject debugButtonObject;
    private GameObject popupLayer;
    private Text toastText;
    private Image loadingFill;
    private Text loadingText;
    private InputField debugEnergyInput;
    private InputField debugCoinsInput;
    private InputField debugHintsInput;
    private SlotView selectedSlot;
    private LevelData[] levels;
    private int currentLevelIndex;
    private int energy;
    private int coins;
    private int hints;
    private bool musicOn = true;
    private bool sfxOn = true;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if (SecurityCheckGame.UseSecurityCheckAsDefault)
        {
            return;
        }

        if (instance != null)
        {
            return;
        }

        GameObject host = new GameObject("FillWhat_Runtime");
        DontDestroyOnLoad(host);
        instance = host.AddComponent<FillWhatGame>();
    }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }

        instance = this;
        gameFont = Resources.Load<Font>("Fonts/HarmonyOS_Sans_SC_Bold") ?? Resources.GetBuiltinResource<Font>("Arial.ttf");
        levels = LoadLevels();
        RestorePlayerState();
        BuildOrAdoptCanvas();
        StartCoroutine(ShowLoadingThenLogin());
    }

    private void Update()
    {
        RestoreEnergyByClock();
        RefreshResources();
    }

    private IEnumerator ShowLoadingThenLogin()
    {
        ShowLoading();

        float elapsed = 0f;
        while (elapsed < 2f)
        {
            elapsed += Time.deltaTime;
            float value = Mathf.Clamp01(elapsed / 2f);
            if (loadingFill != null)
            {
                loadingFill.fillAmount = value;
            }

            if (loadingText != null)
            {
                loadingText.text = Mathf.RoundToInt(value * 100f) + "%";
            }

            yield return null;
        }

        ShowLogin();
    }

    private void BuildOrAdoptCanvas()
    {
        Camera camera = Camera.main;
        if (camera != null)
        {
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.96f, 0.82f, 0.72f, 1f);
        }

        if (FindObjectOfType<EventSystem>() == null)
        {
            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        }

        canvas = FindObjectOfType<Canvas>();
        if (canvas == null)
        {
            GameObject canvasObject = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        }

        canvas.sortingOrder = 10;
        CanvasScaler scaler = canvas.GetComponent<CanvasScaler>() ?? canvas.gameObject.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(DesignWidth, DesignHeight);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 1f;

        if (canvas.GetComponent<GraphicRaycaster>() == null)
        {
            canvas.gameObject.AddComponent<GraphicRaycaster>();
        }

        Transform rootTransform = canvas.transform.Find("DesignRoot");
        if (rootTransform == null)
        {
            GameObject root = new GameObject("DesignRoot", typeof(RectTransform));
            root.transform.SetParent(canvas.transform, false);
            rootTransform = root.transform;
        }

        uiRoot = rootTransform.GetComponent<RectTransform>();
        uiRoot.anchorMin = new Vector2(0.5f, 0.5f);
        uiRoot.anchorMax = new Vector2(0.5f, 0.5f);
        uiRoot.pivot = new Vector2(0.5f, 0.5f);
        uiRoot.anchoredPosition = Vector2.zero;
        uiRoot.sizeDelta = new Vector2(DesignWidth, DesignHeight);
        uiRoot.localScale = Vector3.one;

        Transform popup = uiRoot.Find("PopupLayer");
        if (popup == null)
        {
            GameObject popupObject = new GameObject("PopupLayer", typeof(RectTransform));
            popupObject.transform.SetParent(uiRoot, false);
            popup = popupObject.transform;
        }

        popupLayer = popup.gameObject;
        Stretch(popupLayer.GetComponent<RectTransform>());
        popupLayer.SetActive(false);
    }

    private void ShowLoading()
    {
        ClearScreen(false);
        Transform existingLoading = uiRoot.Find("LoadingScreen");
        currentScreen = existingLoading == null
            ? InstantiatePrefab("Prefabs/UGUI/Screens/LoadingScreen", "LoadingScreen", uiRoot)
            : existingLoading.gameObject;
        Stretch(currentScreen.GetComponent<RectTransform>());
        loadingFill = FindDeep<Image>(currentScreen.transform, "ProgressFill");
        loadingText = FindDeep<Text>(currentScreen.transform, "ProgressText");
        if (loadingFill != null)
        {
            loadingFill.fillAmount = 0f;
        }

        if (loadingText != null)
        {
            loadingText.text = "0%";
        }
    }

    private void ShowLogin()
    {
        ClearScreen(true);
        currentScreen = InstantiatePrefab("Prefabs/UGUI/Screens/LoginScreen", "LoginScreen", uiRoot);
        Stretch(currentScreen.GetComponent<RectTransform>());

        SetText(currentScreen.transform, "Title", "填了个啥");
        SetText(currentScreen.transform, "Subtitle", "补全成语，翻开一封写给你的诗意来信");
        SetText(currentScreen.transform, "Footer", "体力不足时可观看激励视频补充");

        BindTopBar(currentScreen.transform, false);
        Button start = FindDeep<Button>(currentScreen.transform, "StartButton");
        if (start != null)
        {
            start.onClick.RemoveAllListeners();
            start.onClick.AddListener(delegate { TryStartLevel(currentLevelIndex); });
        }

        BindToast(currentScreen.transform);
        BuildDebugButton();
        RefreshResources();
    }

    private void TryStartLevel(int index)
    {
        RestoreEnergyByClock();
        if (energy <= 0)
        {
            ShowEnergyPopup();
            return;
        }

        energy--;
        ScheduleNextEnergy();
        currentLevelIndex = Mathf.Clamp(index, 0, levels.Length - 1);
        SavePlayerState();
        ShowGame();
    }

    private void ShowGame()
    {
        ClearScreen(true);
        slots.Clear();
        tiles.Clear();
        selectedSlot = null;

        currentScreen = InstantiatePrefab("Prefabs/UGUI/Screens/GameScreen", "GameScreen", uiRoot);
        Stretch(currentScreen.GetComponent<RectTransform>());
        LevelData level = levels[currentLevelIndex];

        Image background = FindDeep<Image>(currentScreen.transform, "Background");
        if (background != null)
        {
            background.sprite = Sprite(currentLevelIndex % 2 == 0 ? "Art/Game/game_bg_1" : "Art/Game/game_bg_2");
        }

        SetText(currentScreen.transform, "LevelTitle", level.title);
        SetText(currentScreen.transform, "Theme", level.theme);
        SetText(currentScreen.transform, "Prompt", level.prompt);
        SetText(currentScreen.transform, "EndingPreview", level.ending);

        BindTopBar(currentScreen.transform, true);
        BuildGroups(level);
        BuildTileRack(level);
        BindToolButtons();
        BindToast(currentScreen.transform);
        BuildDebugButton();
        RefreshResources();
        SelectFirstOpenSlot();
    }

    private void BindTopBar(Transform root, bool inGame)
    {
        resourceTexts.Clear();
        BindResource(root, "CoinPill", "Art/Common/icon_coin", delegate { return coins.ToString(); });
        BindResource(root, "EnergyPill", "Art/Common/icon_energy", delegate { return energy + "/" + EnergyMax; });
        BindResource(root, "HintPill", "Art/Common/icon_hint", delegate { return hints.ToString(); });

        Button left = FindDeep<Button>(root, inGame ? "BackButton" : "SettingsButton");
        if (left != null)
        {
            left.onClick.RemoveAllListeners();
            if (inGame)
            {
                left.onClick.AddListener(ShowLogin);
            }
            else
            {
                left.onClick.AddListener(ShowSettingsPopup);
            }
        }

        Button more = FindDeep<Button>(root, "MoreButton");
        if (more != null)
        {
            more.onClick.RemoveAllListeners();
            more.gameObject.SetActive(false);
        }
    }

    private void BindResource(Transform root, string pillName, string iconPath, Func<string> getter)
    {
        Transform pill = FindDeep(root, pillName);
        if (pill == null)
        {
            return;
        }

        Image icon = FindDeep<Image>(pill, "Icon");
        if (icon != null)
        {
            icon.sprite = Sprite(iconPath);
            icon.preserveAspect = true;
        }

        Text value = FindDeep<Text>(pill, "Value");
        if (value != null)
        {
            ResourceText resource = value.gameObject.GetComponent<ResourceText>();
            if (resource == null)
            {
                resource = value.gameObject.AddComponent<ResourceText>();
            }

            resource.Bind(getter);
            resourceTexts.Add(value);
        }
    }

    private void RefreshResources()
    {
        for (int i = 0; i < resourceTexts.Count; i++)
        {
            if (resourceTexts[i] == null)
            {
                continue;
            }

            ResourceText binder = resourceTexts[i].GetComponent<ResourceText>();
            resourceTexts[i].text = binder == null ? resourceTexts[i].text : binder.GetValue();
        }
    }

    private void BindToolButtons()
    {
        Button hintButton = FindDeep<Button>(currentScreen.transform, "HintButton");
        if (hintButton != null)
        {
            SetButtonLabelColor(hintButton.transform, Color.black);
            hintButton.onClick.RemoveAllListeners();
            hintButton.onClick.AddListener(UseHint);
        }

        Button resetButton = FindDeep<Button>(currentScreen.transform, "ResetButton");
        if (resetButton != null)
        {
            SetButtonLabelColor(resetButton.transform, Color.black);
            resetButton.onClick.RemoveAllListeners();
            resetButton.onClick.AddListener(delegate { StartCoroutine(ResetLevelRoutine()); });
        }
    }

    private void BuildGroups(LevelData level)
    {
        Transform groupsRoot = FindDeep(currentScreen.transform, "AnswerGroups");
        if (groupsRoot == null)
        {
            return;
        }

        ClearChildren(groupsRoot);
        for (int groupIndex = 0; groupIndex < level.groups.Length; groupIndex++)
        {
            FillGroup group = level.groups[groupIndex];
            GameObject row = new GameObject("AnswerRow_" + (groupIndex + 1), typeof(RectTransform), typeof(HorizontalLayoutGroup));
            row.transform.SetParent(groupsRoot, false);
            RectTransform rowRect = row.GetComponent<RectTransform>();
            rowRect.anchorMin = new Vector2(0f, 1f);
            rowRect.anchorMax = new Vector2(1f, 1f);
            rowRect.pivot = new Vector2(0.5f, 0.5f);
            rowRect.anchoredPosition = new Vector2(0f, -44f - groupIndex * 118f);
            rowRect.sizeDelta = new Vector2(0f, 82f);

            HorizontalLayoutGroup layout = row.GetComponent<HorizontalLayoutGroup>();
            layout.childAlignment = TextAnchor.MiddleLeft;
            layout.childForceExpandWidth = false;
            layout.childForceExpandHeight = false;
            layout.spacing = 8f;

            Text clue = CreateText("Clue", row.transform, group.clue, 24, new Color(0.32f, 0.21f, 0.14f), TextAnchor.MiddleLeft);
            LayoutElement clueLayout = clue.gameObject.AddComponent<LayoutElement>();
            clueLayout.preferredWidth = 230f;
            clueLayout.preferredHeight = 72f;
            clue.horizontalOverflow = HorizontalWrapMode.Wrap;
            clue.resizeTextForBestFit = true;
            clue.resizeTextMinSize = 18;
            clue.resizeTextMaxSize = 24;

            for (int i = 0; i < group.answer.Length; i++)
            {
                SlotView slot = CreateSlot(row.transform, groupIndex, i, group.answer[i]);
                slots.Add(slot);
            }
        }
    }

    private SlotView CreateSlot(Transform parent, int groupIndex, int index, char answer)
    {
        GameObject go = InstantiatePrefab("Prefabs/UGUI/Atoms/LetterSlot", "Slot_" + groupIndex + "_" + index, parent);
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(64f, 64f);
        LayoutElement layout = go.GetComponent<LayoutElement>() ?? go.AddComponent<LayoutElement>();
        layout.preferredWidth = 64f;
        layout.preferredHeight = 64f;

        Button button = go.GetComponent<Button>() ?? go.AddComponent<Button>();
        Image image = go.GetComponent<Image>();
        Text label = FindDeep<Text>(go.transform, "Letter");
        if (label != null)
        {
            label.text = string.Empty;
            label.font = gameFont;
        }

        SlotView slot = new SlotView
        {
            groupIndex = groupIndex,
            index = index,
            answer = answer,
            button = button,
            image = image,
            label = label
        };
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(delegate { OnSlotClicked(slot); });
        return slot;
    }

    private void BuildTileRack(LevelData level)
    {
        Transform rack = FindDeep(currentScreen.transform, "TileRack");
        if (rack == null)
        {
            return;
        }

        ClearChildren(rack);
        List<char> letters = new List<char>();
        for (int i = 0; i < level.groups.Length; i++)
        {
            letters.AddRange(level.groups[i].answer.ToCharArray());
        }

        const string distractors = "诗信花月风云山水春秋知念归愿安喜灯雨雪海星梦";
        while (letters.Count < 21)
        {
            letters.Add(distractors[random.Next(distractors.Length)]);
        }

        Shuffle(letters);
        for (int i = 0; i < letters.Count; i++)
        {
            char value = letters[i];
            GameObject go = InstantiatePrefab("Prefabs/UGUI/Atoms/LetterTile", "Tile_" + i, rack);
            Text text = FindDeep<Text>(go.transform, "Letter");
            if (text != null)
            {
                text.text = value.ToString();
                text.font = gameFont;
            }

            Button button = go.GetComponent<Button>() ?? go.AddComponent<Button>();
            TileView tile = new TileView { value = value, button = button };
            tiles.Add(tile);
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(delegate { OnTileClicked(tile); });
        }
    }

    private void OnSlotClicked(SlotView slot)
    {
        if (slot == null || slot.correct)
        {
            return;
        }

        if (!string.IsNullOrEmpty(slot.value))
        {
            ReturnSlotLetter(slot);
        }

        SelectSlot(slot);
    }

    private void OnTileClicked(TileView tile)
    {
        if (tile == null || tile.button == null || !tile.button.gameObject.activeSelf)
        {
            return;
        }

        SlotView target = selectedSlot != null && !selectedSlot.correct ? selectedSlot : FindFirstOpenSlot();
        if (target == null)
        {
            ShowToast("本关已经全部填完");
            return;
        }

        if (!string.IsNullOrEmpty(target.value))
        {
            ReturnSlotLetter(target);
        }

        target.value = tile.value.ToString();
        target.sourceTile = tile;
        target.label.text = target.value;
        target.label.color = new Color(0.26f, 0.15f, 0.1f);
        target.error = false;
        tile.button.gameObject.SetActive(false);

        ClearGroupError(target.groupIndex);
        SelectNextSlot(target);
        CheckGroup(target.groupIndex);
    }

    private void ReturnSlotLetter(SlotView slot)
    {
        if (slot.sourceTile != null && slot.sourceTile.button != null)
        {
            slot.sourceTile.button.gameObject.SetActive(true);
        }

        slot.value = string.Empty;
        slot.sourceTile = null;
        slot.correct = false;
        slot.error = false;
        slot.label.text = string.Empty;
        slot.label.color = new Color(0.26f, 0.15f, 0.1f);
        slot.image.sprite = Sprite("Art/Tiles/slot_empty");
        slot.image.color = Color.white;
        slot.button.interactable = true;
    }

    private void CheckGroup(int groupIndex)
    {
        LevelData level = levels[currentLevelIndex];
        if (groupIndex < 0 || groupIndex >= level.groups.Length)
        {
            return;
        }

        List<SlotView> groupSlots = GetGroupSlots(groupIndex);
        string value = string.Empty;
        for (int i = 0; i < groupSlots.Count; i++)
        {
            if (string.IsNullOrEmpty(groupSlots[i].value))
            {
                return;
            }

            value += groupSlots[i].value;
        }

        FillGroup group = level.groups[groupIndex];
        if (value == group.answer)
        {
            for (int i = 0; i < groupSlots.Count; i++)
            {
                MarkCorrect(groupSlots[i]);
            }

            ShowToast("答对了：" + group.answer);
            if (AllSolved())
            {
                StartCoroutine(LevelCompleteRoutine());
            }
        }
        else
        {
            for (int i = 0; i < groupSlots.Count; i++)
            {
                groupSlots[i].error = true;
                groupSlots[i].label.color = new Color(0.84f, 0.16f, 0.12f);
            }

            ShowToast("这句还不太对，换一个字试试");
            StartCoroutine(Pulse(groupSlots[0].button.transform.parent));
        }
    }

    private void MarkCorrect(SlotView slot)
    {
        slot.correct = true;
        slot.error = false;
        slot.value = slot.answer.ToString();
        slot.label.text = slot.value;
        slot.label.color = Color.white;
        slot.image.sprite = Sprite("Art/Tiles/slot_filled");
        slot.image.color = new Color(0.22f, 0.64f, 0.34f);
        slot.button.interactable = false;
        if (slot.sourceTile != null && slot.sourceTile.button != null)
        {
            slot.sourceTile.button.gameObject.SetActive(false);
        }
    }

    private void ClearGroupError(int groupIndex)
    {
        List<SlotView> groupSlots = GetGroupSlots(groupIndex);
        for (int i = 0; i < groupSlots.Count; i++)
        {
            if (!groupSlots[i].correct)
            {
                groupSlots[i].error = false;
                groupSlots[i].label.color = new Color(0.26f, 0.15f, 0.1f);
            }
        }
    }

    private void UseHint()
    {
        SlotView target = null;
        for (int i = 0; i < slots.Count; i++)
        {
            if (!slots[i].correct)
            {
                target = slots[i];
                break;
            }
        }

        if (target == null)
        {
            ShowToast("本关已经全部完成");
            return;
        }

        if (hints <= 0)
        {
            ShowHintAdPopup();
            return;
        }

        hints--;
        SavePlayerState();
        RevealSlot(target);
        SelectNextSlot(target);
        ShowToast("提示已生效");
    }

    private void RevealSlot(SlotView slot)
    {
        if (!string.IsNullOrEmpty(slot.value))
        {
            ReturnSlotLetter(slot);
        }

        TileView matchingTile = FindVisibleTile(slot.answer);
        if (matchingTile != null)
        {
            matchingTile.button.gameObject.SetActive(false);
            slot.sourceTile = matchingTile;
        }

        slot.value = slot.answer.ToString();
        MarkCorrect(slot);
        CheckGroup(slot.groupIndex);
    }

    private TileView FindVisibleTile(char value)
    {
        for (int i = 0; i < tiles.Count; i++)
        {
            if (tiles[i].value == value && tiles[i].button.gameObject.activeSelf)
            {
                return tiles[i];
            }
        }

        return null;
    }

    private IEnumerator ResetLevelRoutine()
    {
        ShowToast("已重置本关");
        yield return new WaitForSeconds(0.12f);
        ShowGame();
    }

    private IEnumerator LevelCompleteRoutine()
    {
        yield return new WaitForSeconds(0.45f);
        bool last = GrantLevelRewardAndAdvance();
        ShowVictoryPopup(last);
    }

    private bool GrantLevelRewardAndAdvance()
    {
        coins += 20;
        hints += 1;
        bool last = currentLevelIndex >= levels.Length - 1;
        currentLevelIndex = last ? 0 : currentLevelIndex + 1;
        SavePlayerState();
        return last;
    }

    private void CompleteCurrentLevelFromDebug()
    {
        HidePopup();
        bool last = GrantLevelRewardAndAdvance();
        ShowVictoryPopup(last);
    }

    private bool AllSolved()
    {
        for (int i = 0; i < slots.Count; i++)
        {
            if (!slots[i].correct)
            {
                return false;
            }
        }

        return true;
    }

    private List<SlotView> GetGroupSlots(int groupIndex)
    {
        List<SlotView> result = new List<SlotView>();
        for (int i = 0; i < slots.Count; i++)
        {
            if (slots[i].groupIndex == groupIndex)
            {
                result.Add(slots[i]);
            }
        }

        result.Sort(delegate (SlotView a, SlotView b) { return a.index.CompareTo(b.index); });
        return result;
    }

    private void SelectFirstOpenSlot()
    {
        SelectSlot(FindFirstOpenSlot());
    }

    private SlotView FindFirstOpenSlot()
    {
        for (int i = 0; i < slots.Count; i++)
        {
            if (!slots[i].correct && string.IsNullOrEmpty(slots[i].value))
            {
                return slots[i];
            }
        }

        for (int i = 0; i < slots.Count; i++)
        {
            if (!slots[i].correct)
            {
                return slots[i];
            }
        }

        return null;
    }

    private void SelectNextSlot(SlotView current)
    {
        int start = slots.IndexOf(current) + 1;
        for (int i = start; i < slots.Count; i++)
        {
            if (!slots[i].correct && string.IsNullOrEmpty(slots[i].value))
            {
                SelectSlot(slots[i]);
                return;
            }
        }

        SelectSlot(FindFirstOpenSlot());
    }

    private void SelectSlot(SlotView slot)
    {
        selectedSlot = slot;
        for (int i = 0; i < slots.Count; i++)
        {
            if (slots[i].correct)
            {
                slots[i].image.color = new Color(0.22f, 0.64f, 0.34f);
            }
            else if (slots[i] == selectedSlot)
            {
                slots[i].image.color = new Color(1f, 0.86f, 0.43f);
            }
            else
            {
                slots[i].image.color = Color.white;
            }
        }
    }

    private void ShowEnergyPopup()
    {
        ShowPopup(
            "体力不足",
            "每封信会消耗 1 点体力。当前版本会模拟一次微信激励视频，完成后补充 1 点体力。",
            "看广告补体力",
            delegate
            {
                WechatMiniGameBridge.ShowRewardedAd(delegate (bool success)
                {
                    if (success)
                    {
                        energy = Mathf.Min(EnergyMax, energy + 1);
                        SavePlayerState();
                        HidePopup();
                        ShowToast("体力 +1");
                    }
                });
            });
    }

    private void ShowHintAdPopup()
    {
        ShowPopup(
            "提示卡不足",
            "可以通过完成关卡或观看激励视频获得提示卡。当前版本会模拟广告完成。",
            "看广告拿提示",
            delegate
            {
                WechatMiniGameBridge.ShowRewardedAd(delegate (bool success)
                {
                    if (success)
                    {
                        hints++;
                        SavePlayerState();
                        HidePopup();
                        ShowToast("提示卡 +1");
                    }
                });
            });
    }

    private void ShowSettingsPopup()
    {
        ShowPopup("游戏设置", "音乐和音效开关已接入 UI，导入真实音频后可沿用这里的状态。", "关闭", HidePopup);

        Transform panel = popupLayer.transform.Find("PopupPanel");
        if (panel == null)
        {
            return;
        }

        Button music = CreatePopupToggle(panel, "MusicToggle", musicOn ? "音乐：开" : "音乐：关", new Vector2(-125, -54));
        music.onClick.AddListener(delegate
        {
            musicOn = !musicOn;
            FindDeep<Text>(music.transform, "Label").text = musicOn ? "音乐：开" : "音乐：关";
        });

        Button sfx = CreatePopupToggle(panel, "SfxToggle", sfxOn ? "音效：开" : "音效：关", new Vector2(125, -54));
        sfx.onClick.AddListener(delegate
        {
            sfxOn = !sfxOn;
            FindDeep<Text>(sfx.transform, "Label").text = sfxOn ? "音效：开" : "音效：关";
        });
    }

    private Button CreatePopupToggle(Transform parent, string name, string text, Vector2 position)
    {
        GameObject go = InstantiatePrefab("Prefabs/UGUI/Atoms/GreenTextButton", name, parent);
        SetRect(go.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), position, new Vector2(220, 72));
        SetText(go.transform, "Label", text);
        Button button = go.GetComponent<Button>();
        button.onClick.RemoveAllListeners();
        return button;
    }

    private void BuildDebugButton()
    {
        if (debugButtonObject != null)
        {
            Destroy(debugButtonObject);
        }

        Button button = CreateSolidTextButton("DebugButton", uiRoot, "调试", new Color(0.70f, 0.70f, 0.70f, 0.92f), Color.black, 21);
        debugButtonObject = button.gameObject;
        debugButtonObject.transform.SetAsLastSibling();
        SetRect(button.GetComponent<RectTransform>(), new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(68f, 72f), new Vector2(112f, 54f));
        button.onClick.AddListener(ShowDebugPanel);
    }

    private void ShowDebugPanel()
    {
        HidePopup();
        popupLayer.SetActive(true);
        popupLayer.transform.SetAsLastSibling();

        Image blocker = CreateImage("Blocker", popupLayer.transform, null, new Color(0, 0, 0, 0.42f));
        Stretch(blocker.rectTransform);

        Image panel = CreateImage("DebugPanel", popupLayer.transform, null, new Color(0.96f, 0.93f, 0.86f, 0.98f));
        SetRect(panel.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(690f, 1240f));

        Text title = CreateText("Title", panel.transform, "调试面板", 38, new Color(0.16f, 0.12f, 0.09f), TextAnchor.MiddleCenter);
        SetRect(title.rectTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -58), new Vector2(360, 58));

        Button close = CreateSolidTextButton("Close", panel.transform, "×", new Color(0.72f, 0.72f, 0.72f, 1f), Color.black, 34);
        SetRect(close.GetComponent<RectTransform>(), new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-48, -48), new Vector2(54, 54));
        close.onClick.AddListener(HidePopup);

        debugEnergyInput = CreateDebugNumberRow(panel.transform, "体力", energy.ToString(), new Vector2(0, -138));
        debugCoinsInput = CreateDebugNumberRow(panel.transform, "金币", coins.ToString(), new Vector2(0, -214));
        debugHintsInput = CreateDebugNumberRow(panel.transform, "提示", hints.ToString(), new Vector2(0, -290));

        Button apply = CreateSolidTextButton("ApplyResources", panel.transform, "应用数值", new Color(0.36f, 0.64f, 0.42f, 1f), Color.white, 25);
        SetRect(apply.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(-150, -372), new Vector2(220, 62));
        apply.onClick.AddListener(ApplyDebugResources);

        Button pass = CreateSolidTextButton("PassLevel", panel.transform, "直接通关", new Color(0.27f, 0.54f, 0.80f, 1f), Color.white, 25);
        SetRect(pass.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(150, -372), new Vector2(220, 62));
        pass.onClick.AddListener(CompleteCurrentLevelFromDebug);

        Text listTitle = CreateText("LevelListTitle", panel.transform, "关卡快照", 28, new Color(0.22f, 0.15f, 0.10f), TextAnchor.MiddleLeft);
        SetRect(listTitle.rectTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -448), new Vector2(580, 44));

        BuildDebugLevelList(panel.transform);
    }

    private InputField CreateDebugNumberRow(Transform parent, string label, string value, Vector2 position)
    {
        Text labelText = CreateText(label + "Label", parent, label, 25, new Color(0.18f, 0.14f, 0.10f), TextAnchor.MiddleLeft);
        SetRect(labelText.rectTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), position + new Vector2(-205, 0), new Vector2(120, 58));

        InputField input = CreateInputField(label + "Input", parent, value);
        SetRect(input.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), position + new Vector2(0, 0), new Vector2(190, 58));

        Button minus = CreateSolidTextButton(label + "Minus", parent, "-", new Color(0.82f, 0.82f, 0.82f, 1f), Color.black, 28);
        SetRect(minus.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), position + new Vector2(145, 0), new Vector2(54, 54));
        minus.onClick.AddListener(delegate { StepInput(input, -1); });

        Button plus = CreateSolidTextButton(label + "Plus", parent, "+", new Color(0.82f, 0.82f, 0.82f, 1f), Color.black, 28);
        SetRect(plus.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), position + new Vector2(210, 0), new Vector2(54, 54));
        plus.onClick.AddListener(delegate { StepInput(input, 1); });

        return input;
    }

    private void StepInput(InputField input, int delta)
    {
        int current;
        if (!int.TryParse(input.text, out current))
        {
            current = 0;
        }

        input.text = Mathf.Max(0, current + delta).ToString();
    }

    private void ApplyDebugResources()
    {
        energy = Mathf.Clamp(ParseDebugInput(debugEnergyInput, energy), 0, EnergyMax);
        coins = Mathf.Max(0, ParseDebugInput(debugCoinsInput, coins));
        hints = Mathf.Max(0, ParseDebugInput(debugHintsInput, hints));
        SavePlayerState();
        RefreshResources();
        ShowToast("调试数值已应用");
    }

    private int ParseDebugInput(InputField input, int fallback)
    {
        if (input == null)
        {
            return fallback;
        }

        int value;
        return int.TryParse(input.text, out value) ? value : fallback;
    }

    private void BuildDebugLevelList(Transform parent)
    {
        GameObject viewport = new GameObject("LevelViewport", typeof(RectTransform), typeof(Image), typeof(Mask), typeof(ScrollRect));
        viewport.transform.SetParent(parent, false);
        SetRect(viewport.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -820), new Vector2(600, 660));
        Image viewportImage = viewport.GetComponent<Image>();
        viewportImage.color = new Color(1f, 1f, 1f, 0.08f);
        viewport.GetComponent<Mask>().showMaskGraphic = false;

        GameObject content = new GameObject("LevelContent", typeof(RectTransform), typeof(GridLayoutGroup), typeof(ContentSizeFitter));
        content.transform.SetParent(viewport.transform, false);
        RectTransform contentRect = content.GetComponent<RectTransform>();
        contentRect.anchorMin = new Vector2(0f, 1f);
        contentRect.anchorMax = new Vector2(1f, 1f);
        contentRect.pivot = new Vector2(0.5f, 1f);
        contentRect.anchoredPosition = Vector2.zero;
        contentRect.sizeDelta = new Vector2(0, 0);

        GridLayoutGroup grid = content.GetComponent<GridLayoutGroup>();
        grid.cellSize = new Vector2(178, 132);
        grid.spacing = new Vector2(20, 18);
        grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
        grid.constraintCount = 3;
        grid.childAlignment = TextAnchor.UpperCenter;

        ContentSizeFitter fitter = content.GetComponent<ContentSizeFitter>();
        fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        ScrollRect scroll = viewport.GetComponent<ScrollRect>();
        scroll.content = contentRect;
        scroll.horizontal = false;
        scroll.vertical = true;
        scroll.movementType = ScrollRect.MovementType.Clamped;
        scroll.inertia = true;

        for (int i = 0; i < levels.Length; i++)
        {
            CreateLevelEnvelopeCard(content.transform, i);
        }
    }

    private void CreateLevelEnvelopeCard(Transform parent, int levelIndex)
    {
        LevelData level = levels[levelIndex];
        GameObject card = new GameObject("LevelEnvelope_" + (levelIndex + 1), typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
        card.transform.SetParent(parent, false);

        Image image = card.GetComponent<Image>();
        image.sprite = Sprite("Art/Game/paper_small");
        image.type = image.sprite == null ? Image.Type.Simple : Image.Type.Sliced;
        image.color = levelIndex == currentLevelIndex ? new Color(1f, 0.92f, 0.68f, 1f) : new Color(1f, 0.96f, 0.84f, 1f);

        Image flap = CreateImage("Flap", card.transform, null, new Color(0.92f, 0.74f, 0.48f, 0.30f));
        SetRect(flap.rectTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -34), new Vector2(150, 42));

        Text index = CreateText("Index", card.transform, "第" + (levelIndex + 1) + "关", 20, new Color(0.47f, 0.24f, 0.12f), TextAnchor.MiddleCenter);
        SetRect(index.rectTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -34), new Vector2(138, 36));

        Text name = CreateText("Name", card.transform, level.theme, 20, new Color(0.24f, 0.16f, 0.10f), TextAnchor.MiddleCenter);
        name.resizeTextForBestFit = true;
        name.resizeTextMinSize = 14;
        name.resizeTextMaxSize = 20;
        SetRect(name.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, -6), new Vector2(142, 48));

        Text title = CreateText("SmallTitle", card.transform, level.title, 15, new Color(0.38f, 0.22f, 0.14f), TextAnchor.MiddleCenter);
        title.resizeTextForBestFit = true;
        title.resizeTextMinSize = 10;
        title.resizeTextMaxSize = 15;
        SetRect(title.rectTransform, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0, 24), new Vector2(142, 34));

        Button button = card.GetComponent<Button>();
        button.onClick.AddListener(delegate
        {
            currentLevelIndex = levelIndex;
            SavePlayerState();
            HidePopup();
            ShowGame();
        });
    }

    private void ShowVictoryPopup(bool last)
    {
        HidePopup();
        popupLayer.SetActive(true);
        popupLayer.transform.SetAsLastSibling();

        Image blocker = CreateImage("Blocker", popupLayer.transform, null, new Color(0, 0, 0, 0.45f));
        Stretch(blocker.rectTransform);

        Image panel = CreateImage("VictoryPanel", popupLayer.transform, Sprite("Art/Popup/popup_panel"), Color.white);
        panel.type = panel.sprite == null ? Image.Type.Simple : Image.Type.Sliced;
        SetRect(panel.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(620, 520));

        Text title = CreateText("Title", panel.transform, "恭喜过关", 46, Color.white, TextAnchor.MiddleCenter);
        SetRect(title.rectTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -22), new Vector2(460, 68));

        Text body = CreateText("Body", panel.transform, BuildVictoryMessage(last), 30, new Color(0.30f, 0.21f, 0.15f), TextAnchor.MiddleCenter);
        body.horizontalOverflow = HorizontalWrapMode.Wrap;
        SetRect(body.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, 46), new Vector2(500, 150));

        Button next = CreateSpriteTextButton("NextLevel", panel.transform, last ? "重新开始" : "下一关", "Art/Common/button_green", Color.black, 30);
        SetRect(next.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(-145, 92), new Vector2(230, 82));
        next.onClick.AddListener(delegate
        {
            HidePopup();
            TryStartLevel(currentLevelIndex);
        });

        Button home = CreateSpriteTextButton("BackHome", panel.transform, "返回主页", "Art/Common/button_blue", Color.black, 30);
        SetRect(home.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(145, 92), new Vector2(230, 82));
        home.onClick.AddListener(delegate
        {
            HidePopup();
            ShowLogin();
        });
    }

    private string BuildVictoryMessage(bool last)
    {
        return BuildPoeticVictoryMessage(GetCompletedLevelForVictory(last));
    }

    private string BuildPoeticVictoryMessage(LevelData completed)
    {
        string theme = completed == null ? "来信" : completed.theme;
        string ending = completed == null ? string.Empty : completed.ending;
        string[] lines =
        {
            "你补齐了" + theme + "里的空白，也把一封来信读成了诗。",
            theme + "的光落在纸上，答案像花影一样停在信笺间。",
            "这一封关于" + theme + "的来信，已在你的字句里温柔抵达。",
            string.IsNullOrEmpty(ending) ? theme + "的风越过纸页，留下刚刚好的回声。" : ending
        };

        return lines[random.Next(lines.Length)] + "\n获得 20 金币和 1 张提示卡。";
    }

    private LevelData GetCompletedLevelForVictory(bool last)
    {
        if (levels == null || levels.Length == 0)
        {
            return null;
        }

        int completedIndex = last ? levels.Length - 1 : currentLevelIndex - 1;
        return levels[Mathf.Clamp(completedIndex, 0, levels.Length - 1)];
    }

    private void ShowPopup(string title, string body, string actionText, Action action)
    {
        HidePopup();
        popupLayer.SetActive(true);
        popupLayer.transform.SetAsLastSibling();

        Image blocker = CreateImage("Blocker", popupLayer.transform, null, new Color(0, 0, 0, 0.45f));
        Stretch(blocker.rectTransform);

        GameObject panel = InstantiatePrefab("Prefabs/UGUI/Popups/PopupPanel", "PopupPanel", popupLayer.transform);
        SetRect(panel.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(620, 480));
        SetText(panel.transform, "Title", title);
        SetText(panel.transform, "Body", body);
        SetText(panel.transform, "Label", actionText);
        SetButtonLabelColor(panel.transform, Color.black);

        Button close = FindDeep<Button>(panel.transform, "CloseButton");
        if (close != null)
        {
            close.onClick.RemoveAllListeners();
            close.onClick.AddListener(HidePopup);
        }

        Button actionButton = FindDeep<Button>(panel.transform, "ActionButton");
        if (actionButton != null)
        {
            actionButton.onClick.RemoveAllListeners();
            actionButton.onClick.AddListener(delegate { if (action != null) action(); });
        }
    }

    private void HidePopup()
    {
        if (popupLayer == null)
        {
            return;
        }

        ClearChildren(popupLayer.transform);
        popupLayer.SetActive(false);
    }

    private void BindToast(Transform root)
    {
        Transform toast = FindDeep(root, "Toast");
        toastText = toast == null ? null : FindDeep<Text>(toast, "ToastText");
        if (toast != null)
        {
            toast.gameObject.SetActive(false);
        }
    }

    private void ShowToast(string message)
    {
        if (toastText == null)
        {
            return;
        }

        toastText.transform.parent.gameObject.SetActive(true);
        toastText.text = message;
        StopCoroutine("HideToastLater");
        StartCoroutine("HideToastLater");
    }

    private IEnumerator HideToastLater()
    {
        yield return new WaitForSeconds(1.55f);
        if (toastText != null)
        {
            toastText.transform.parent.gameObject.SetActive(false);
        }
    }

    private IEnumerator Pulse(Transform target)
    {
        Vector3 start = target.localScale;
        target.localScale = start * 1.05f;
        yield return new WaitForSeconds(0.08f);
        target.localScale = start * 0.96f;
        yield return new WaitForSeconds(0.08f);
        target.localScale = start;
    }

    private LevelData[] LoadLevels()
    {
        TextAsset levelAsset = Resources.Load<TextAsset>("Data/levels");
        if (levelAsset == null)
        {
            Debug.LogWarning("Data/levels.json was not found. Using fallback levels.");
            return FallbackLevels();
        }

        try
        {
            LevelCollection collection = JsonUtility.FromJson<LevelCollection>(levelAsset.text);
            if (collection == null || collection.levels == null || collection.levels.Length == 0)
            {
                Debug.LogWarning("Data/levels.json has no levels. Using fallback levels.");
                return FallbackLevels();
            }

            List<LevelData> parsed = new List<LevelData>();
            for (int i = 0; i < collection.levels.Length; i++)
            {
                LevelConfig config = collection.levels[i];
                if (config == null || config.groups == null || config.groups.Length == 0)
                {
                    continue;
                }

                List<FillGroup> groups = new List<FillGroup>();
                for (int j = 0; j < config.groups.Length; j++)
                {
                    FillGroupConfig groupConfig = config.groups[j];
                    if (groupConfig != null && !string.IsNullOrEmpty(groupConfig.answer))
                    {
                        groups.Add(new FillGroup(groupConfig.clue, groupConfig.answer));
                    }
                }

                if (groups.Count > 0)
                {
                    parsed.Add(new LevelData(config.title, config.prompt, config.theme, groups.ToArray(), config.ending));
                }
            }

            return parsed.Count > 0 ? parsed.ToArray() : FallbackLevels();
        }
        catch (Exception exception)
        {
            Debug.LogWarning("Failed to parse Data/levels.json. Using fallback levels. " + exception.Message);
            return FallbackLevels();
        }
    }

    private LevelData[] FallbackLevels()
    {
        return new[]
        {
            new LevelData("第一封信 · 春日初见", "春风拂过旧庭院，你的来信落在案前。补全信里的成语，让故事继续翻页。", "校园樱花", new[]
            {
                new FillGroup("愿你一路", "春风得意"),
                new FillGroup("提笔时仍觉", "心有灵犀"),
                new FillGroup("愿这封信把思念说得", "恰到好处")
            }, "明日的风若也这样温柔，我们就在旧亭边再读下一封信。")
        };
    }

    private void RestorePlayerState()
    {
        energy = PlayerPrefs.GetInt(EnergyKey, EnergyMax);
        coins = PlayerPrefs.GetInt(CoinKey, StartCoins);
        hints = PlayerPrefs.GetInt(HintKey, StartHints);
        currentLevelIndex = Mathf.Clamp(PlayerPrefs.GetInt(CurrentLevelKey, 0), 0, levels.Length - 1);
        RestoreEnergyByClock();
    }

    private void SavePlayerState()
    {
        PlayerPrefs.SetInt(EnergyKey, Mathf.Clamp(energy, 0, EnergyMax));
        PlayerPrefs.SetInt(CoinKey, Mathf.Max(0, coins));
        PlayerPrefs.SetInt(HintKey, Mathf.Max(0, hints));
        PlayerPrefs.SetInt(CurrentLevelKey, Mathf.Clamp(currentLevelIndex, 0, levels.Length - 1));
        PlayerPrefs.Save();
    }

    private void RestoreEnergyByClock()
    {
        if (energy >= EnergyMax)
        {
            PlayerPrefs.DeleteKey(NextEnergyAtKey);
            return;
        }

        string raw = PlayerPrefs.GetString(NextEnergyAtKey, string.Empty);
        long ticks;
        if (!long.TryParse(raw, out ticks) || ticks <= 0)
        {
            ScheduleNextEnergy();
            return;
        }

        DateTime next = new DateTime(ticks, DateTimeKind.Utc);
        DateTime now = DateTime.UtcNow;
        bool changed = false;
        while (energy < EnergyMax && now >= next)
        {
            energy++;
            next = next.AddHours(1);
            changed = true;
        }

        if (energy >= EnergyMax)
        {
            PlayerPrefs.DeleteKey(NextEnergyAtKey);
        }
        else if (changed)
        {
            PlayerPrefs.SetString(NextEnergyAtKey, next.Ticks.ToString());
        }

        if (changed)
        {
            SavePlayerState();
        }
    }

    private void ScheduleNextEnergy()
    {
        if (energy < EnergyMax)
        {
            PlayerPrefs.SetString(NextEnergyAtKey, DateTime.UtcNow.AddHours(1).Ticks.ToString());
        }
    }

    private GameObject InstantiatePrefab(string resourcePath, string name, Transform parent)
    {
        GameObject prefab = Resources.Load<GameObject>(resourcePath);
        GameObject instanceObject = prefab == null ? new GameObject(name, typeof(RectTransform)) : Instantiate(prefab);
        instanceObject.name = name;
        instanceObject.transform.SetParent(parent, false);
        if (instanceObject.GetComponent<RectTransform>() == null)
        {
            instanceObject.AddComponent<RectTransform>();
        }

        return instanceObject;
    }

    private Image CreateImage(string name, Transform parent, Sprite sprite, Color color)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        go.transform.SetParent(parent, false);
        Image image = go.GetComponent<Image>();
        image.sprite = sprite;
        image.color = color;
        return image;
    }

    private Button CreateSolidTextButton(string name, Transform parent, string value, Color background, Color textColor, int fontSize)
    {
        Image image = CreateImage(name, parent, null, background);
        Button button = image.gameObject.AddComponent<Button>();
        button.transition = Selectable.Transition.ColorTint;
        Text label = CreateText("Label", button.transform, value, fontSize, textColor, TextAnchor.MiddleCenter);
        label.resizeTextForBestFit = true;
        label.resizeTextMinSize = 14;
        label.resizeTextMaxSize = fontSize;
        Stretch(label.rectTransform);
        return button;
    }

    private Button CreateSpriteTextButton(string name, Transform parent, string value, string spritePath, Color textColor, int fontSize)
    {
        Image image = CreateImage(name, parent, Sprite(spritePath), Color.white);
        image.type = image.sprite == null ? Image.Type.Simple : Image.Type.Sliced;
        Button button = image.gameObject.AddComponent<Button>();
        button.transition = Selectable.Transition.ColorTint;
        Text label = CreateText("Label", button.transform, value, fontSize, textColor, TextAnchor.MiddleCenter);
        label.resizeTextForBestFit = true;
        label.resizeTextMinSize = 14;
        label.resizeTextMaxSize = fontSize;
        Stretch(label.rectTransform);
        return button;
    }

    private InputField CreateInputField(string name, Transform parent, string value)
    {
        Image image = CreateImage(name, parent, null, new Color(1f, 1f, 1f, 0.95f));
        InputField input = image.gameObject.AddComponent<InputField>();
        input.contentType = InputField.ContentType.IntegerNumber;

        Text text = CreateText("Text", image.transform, value, 25, Color.black, TextAnchor.MiddleCenter);
        SetRect(text.rectTransform, Vector2.zero, Vector2.one, Vector2.zero, new Vector2(-18, -8));
        input.textComponent = text;
        input.text = value;

        Text placeholder = CreateText("Placeholder", image.transform, "0", 25, new Color(0f, 0f, 0f, 0.35f), TextAnchor.MiddleCenter);
        SetRect(placeholder.rectTransform, Vector2.zero, Vector2.one, Vector2.zero, new Vector2(-18, -8));
        input.placeholder = placeholder;
        return input;
    }

    private Text CreateText(string name, Transform parent, string value, int size, Color color, TextAnchor anchor)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
        go.transform.SetParent(parent, false);
        Text text = go.GetComponent<Text>();
        text.text = value;
        text.font = gameFont;
        text.fontSize = size;
        text.color = color;
        text.alignment = anchor;
        text.horizontalOverflow = HorizontalWrapMode.Overflow;
        text.verticalOverflow = VerticalWrapMode.Truncate;
        text.raycastTarget = false;
        return text;
    }

    private Sprite Sprite(string path)
    {
        if (string.IsNullOrEmpty(path))
        {
            return null;
        }

        Sprite sprite;
        if (spriteCache.TryGetValue(path, out sprite))
        {
            return sprite;
        }

        sprite = Resources.Load<Sprite>(path);
        spriteCache[path] = sprite;
        return sprite;
    }

    private void ClearScreen(bool hidePopup)
    {
        resourceTexts.Clear();
        if (currentScreen != null)
        {
            Destroy(currentScreen);
        }

        if (debugButtonObject != null)
        {
            Destroy(debugButtonObject);
            debugButtonObject = null;
        }

        currentScreen = null;
        if (hidePopup)
        {
            HidePopup();
        }
    }

    private static void ClearChildren(Transform parent)
    {
        for (int i = parent.childCount - 1; i >= 0; i--)
        {
            Destroy(parent.GetChild(i).gameObject);
        }
    }

    private static Transform FindDeep(Transform root, string name)
    {
        if (root == null)
        {
            return null;
        }

        if (root.name == name)
        {
            return root;
        }

        for (int i = 0; i < root.childCount; i++)
        {
            Transform found = FindDeep(root.GetChild(i), name);
            if (found != null)
            {
                return found;
            }
        }

        return null;
    }

    private static T FindDeep<T>(Transform root, string name) where T : Component
    {
        Transform found = FindDeep(root, name);
        return found == null ? null : found.GetComponent<T>();
    }

    private static void SetText(Transform root, string name, string value)
    {
        Text text = FindDeep<Text>(root, name);
        if (text != null)
        {
            text.text = value;
        }
    }

    private static void SetButtonLabelColor(Transform root, Color color)
    {
        Text label = FindDeep<Text>(root, "Label");
        if (label != null)
        {
            label.color = color;
        }
    }

    private static void Stretch(RectTransform rect)
    {
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        rect.pivot = new Vector2(0.5f, 0.5f);
    }

    private static void SetRect(RectTransform rect, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
    {
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.pivot = new Vector2(0.5f, 0.5f);
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = sizeDelta;
    }

    private void Shuffle<T>(IList<T> values)
    {
        for (int i = values.Count - 1; i > 0; i--)
        {
            int j = random.Next(i + 1);
            T temp = values[i];
            values[i] = values[j];
            values[j] = temp;
        }
    }

    private sealed class ResourceText : MonoBehaviour
    {
        private Func<string> getter;

        public void Bind(Func<string> valueGetter)
        {
            getter = valueGetter;
        }

        public string GetValue()
        {
            return getter == null ? string.Empty : getter();
        }
    }

    private sealed class LevelData
    {
        public readonly string title;
        public readonly string prompt;
        public readonly string theme;
        public readonly FillGroup[] groups;
        public readonly string ending;

        public LevelData(string title, string prompt, string theme, FillGroup[] groups, string ending)
        {
            this.title = string.IsNullOrEmpty(title) ? "未命名来信" : title;
            this.prompt = string.IsNullOrEmpty(prompt) ? "补全信里的成语，让故事继续翻页。" : prompt;
            this.theme = string.IsNullOrEmpty(theme) ? "书信" : theme;
            this.groups = groups == null || groups.Length == 0 ? new[] { new FillGroup("补全词语", "春风得意") } : groups;
            this.ending = string.IsNullOrEmpty(ending) ? "这封信已经补完整了。" : ending;
        }
    }

    private sealed class FillGroup
    {
        public readonly string clue;
        public readonly string answer;

        public FillGroup(string clue, string answer)
        {
            this.clue = string.IsNullOrEmpty(clue) ? "补全成语" : clue;
            this.answer = answer;
        }
    }

    private sealed class SlotView
    {
        public int groupIndex;
        public int index;
        public char answer;
        public string value;
        public bool correct;
        public bool error;
        public Button button;
        public Image image;
        public Text label;
        public TileView sourceTile;
    }

    private sealed class TileView
    {
        public char value;
        public Button button;
    }

    [Serializable]
    private sealed class LevelCollection
    {
        public LevelConfig[] levels;
    }

    [Serializable]
    private sealed class LevelConfig
    {
        public string title;
        public string prompt;
        public string theme;
        public string ending;
        public FillGroupConfig[] groups;
    }

    [Serializable]
    private sealed class FillGroupConfig
    {
        public string clue;
        public string answer;
    }
}
