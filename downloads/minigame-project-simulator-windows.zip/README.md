# Game Brief Studio

Windows 桌面版 Unity 微信小游戏需求生成器。

## 使用方法

1. 双击最新的 `MinigameBrief_v1.1.exe`。如果目录中仍有 `MinigameBrief.exe`，它是被旧窗口占用而保留的首版。
2. 先填写 5 个核心问题，或点击“通用开发记忆”查看默认规则。
3. 需要更完整的策划信息时进入“详细调查问卷”，高级选项可展开。
4. 在“预览与检查”查看关键缺失、实施前确认和优化建议。
5. 点击“生成开发文件”。程序会创建并打开 `Generated/<项目名>_<时间戳>/`。
6. 把 `GAME_PROJECT_BRIEF.md` 和 `UNITY_MINIGAME_MEMORY.md` 一起拖入 Codex 任务。

推荐提示语：

> 请先阅读这两个文件，检查需求冲突和缺失，确认设计后再开始开发。

## 系统要求

- Windows 10/11 x64。
- .NET Framework 4.7.1 或更高版本。
- 程序完全离线，不上传问卷内容。

## 数据位置

- 自动草稿：`%LOCALAPPDATA%\GameBriefStudio\draft.json`
- 生成文件：EXE 同级的 `Generated` 文件夹。
- 重复生成不会覆盖旧版本。

## 能力边界

工具只生成开发需求和通用记忆，不会修改 Unity 工程、安装 Unity MCP、下载 Pinterest 素材或发布微信小游戏。
