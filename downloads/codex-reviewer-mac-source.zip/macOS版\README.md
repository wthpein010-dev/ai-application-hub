# Codex 对话评分工具 macOS 版

macOS 不使用 Windows `.exe`，请直接运行源码版。

## 运行

```bash
cd "$(dirname "$0")/.."
python3 ./codex_conversation_reviewer.py
```

也可以双击上一级目录的：

```text
run-review.command
```

输出文件在：

```text
../outputs/
```

## 说明

- 需要 macOS 已安装 Python 3。
- 工具会自动查找常见 Codex 数据目录，例如 `~/.codex`。
- 如 Codex 数据目录不在默认位置，可在终端中运行：

```bash
python3 ./codex_conversation_reviewer.py --codex-home "$HOME/.codex"
```
