#!/bin/sh
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$DIR/.." || exit 1
mkdir -p outputs
python3 ./codex_conversation_reviewer.py
printf "\n输出目录：%s/outputs\n" "$(pwd)"
