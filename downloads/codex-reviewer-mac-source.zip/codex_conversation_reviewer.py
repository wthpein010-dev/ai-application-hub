#!/usr/bin/env python3
"""
Review local Codex conversations and export prompt-quality feedback to Excel.

The tool is read-only against Codex data. It scans local Codex session JSONL
files, extracts real user prompts, scores each prompt with a transparent
heuristic rubric, and writes a portable .xlsx workbook using only Python's
standard library.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import sys
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable
from xml.sax.saxutils import escape


UUID_RE = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
)
ENV_CONTEXT_RE = re.compile(r"^\s*<environment_context>.*?</environment_context>\s*$", re.S)
SECRET_PATTERNS = [
    re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\b[A-Za-z0-9_=-]{32,}\.[A-Za-z0-9_=-]{12,}\.[A-Za-z0-9_=-]{12,}\b"),
    re.compile(r"(?i)\b(api[_-]?key|token|secret|password)\s*[:=]\s*[^\s,;]{8,}"),
]


@dataclass
class PromptReview:
    session_id: str
    thread_name: str
    session_path: str
    turn_index: int
    timestamp: str
    prompt: str
    prompt_excerpt: str
    previous_assistant_excerpt: str
    prompt_type: str
    word_count: int
    char_count: int
    clarity: float
    context: float
    specificity: float
    actionability: float
    scope_control: float
    overall: float
    grade: str
    feedback: str
    improvement: str
    suggested_rewrite: str
    themes: list[str] = field(default_factory=list)


@dataclass
class SessionSummary:
    session_id: str
    thread_name: str
    session_path: str
    prompt_count: int
    avg_overall: float
    first_timestamp: str
    last_timestamp: str
    strongest_prompt: str
    weakest_prompt: str
    main_feedback: str


def norm_path(path: Path) -> str:
    return str(path.expanduser().resolve(strict=False))


def existing_dirs(paths: Iterable[Path]) -> list[Path]:
    seen: set[str] = set()
    found: list[Path] = []
    for raw in paths:
        path = raw.expanduser()
        key = norm_path(path).casefold()
        if key in seen:
            continue
        seen.add(key)
        if path.is_dir():
            found.append(path)
    return found


def marker_score(path: Path) -> int:
    points = 0
    if (path / "sessions").is_dir():
        points += 4
    if (path / "archived_sessions").is_dir():
        points += 3
    if (path / "session_index.jsonl").is_file():
        points += 3
    if (path / "config.toml").is_file():
        points += 1
    return points


def scan_for_codex_homes(roots: Iterable[str], max_depth: int) -> list[Path]:
    found: list[Path] = []
    for raw_root in roots:
        root = Path(raw_root).expanduser()
        if not root.is_dir():
            continue
        root_parts = len(root.parts)
        stack = [root]
        while stack:
            current = stack.pop()
            if len(current.parts) - root_parts > max_depth:
                continue
            if marker_score(current) > 0:
                found.append(current)
                continue
            try:
                stack.extend(child for child in current.iterdir() if child.is_dir())
            except OSError:
                continue
    return found


def candidate_codex_homes(extra_roots: Iterable[str], scan_roots: Iterable[str], scan_depth: int) -> list[Path]:
    home = Path.home()
    candidates: list[Path] = []

    if os.environ.get("CODEX_HOME"):
        candidates.append(Path(os.environ["CODEX_HOME"]))
    candidates.append(home / ".codex")

    system = platform.system().lower()
    if system == "windows":
        for env_name in ("APPDATA", "LOCALAPPDATA", "PROGRAMDATA"):
            value = os.environ.get(env_name)
            if value:
                base = Path(value)
                candidates.extend([base / "Codex", base / "OpenAI" / "Codex", base / "OpenAI" / "codex"])
    elif system == "darwin":
        candidates.extend(
            [
                home / "Library" / "Application Support" / "Codex",
                home / "Library" / "Application Support" / "codex",
                home / "Library" / "Application Support" / "com.openai.codex",
            ]
        )
    else:
        xdg_config = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config"))
        xdg_state = Path(os.environ.get("XDG_STATE_HOME", home / ".local" / "state"))
        candidates.extend([xdg_config / "codex", xdg_config / "Codex", xdg_state / "codex", xdg_state / "Codex"])

    for root in extra_roots:
        root_path = Path(root).expanduser()
        candidates.extend([root_path, root_path / ".codex", root_path / "Codex"])

    candidates.extend(scan_for_codex_homes(scan_roots, scan_depth))
    return existing_dirs(candidates)


def choose_codex_home(paths: list[Path], explicit: str | None) -> Path | None:
    if explicit:
        path = Path(explicit).expanduser()
        return path if path.is_dir() else None
    if not paths:
        return None
    return max(paths, key=lambda p: (marker_score(p), p.stat().st_mtime if p.exists() else 0))


def session_dirs_for(codex_home: Path | None, extra_session_dirs: Iterable[str]) -> list[Path]:
    candidates: list[Path] = []
    if codex_home:
        candidates.extend([codex_home / "sessions", codex_home / "archived_sessions"])
    candidates.extend(Path(value).expanduser() for value in extra_session_dirs)
    return existing_dirs(candidates)


def iter_session_files(dirs: Iterable[Path]) -> list[Path]:
    files: list[Path] = []
    for directory in dirs:
        try:
            files.extend(path for path in directory.rglob("*.jsonl") if path.is_file())
        except OSError:
            continue
    return sorted(files, key=lambda path: norm_path(path).casefold())


def read_session_index(codex_home: Path | None) -> dict[str, dict[str, str]]:
    if not codex_home:
        return {}
    index_path = codex_home / "session_index.jsonl"
    if not index_path.is_file():
        return {}

    index: dict[str, dict[str, str]] = {}
    try:
        with index_path.open("r", encoding="utf-8-sig", errors="replace") as handle:
            for line in handle:
                if not line.strip():
                    continue
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    continue
                thread_id = item.get("id")
                if isinstance(thread_id, str):
                    index[thread_id] = {
                        "thread_name": str(item.get("thread_name") or ""),
                        "updated_at": str(item.get("updated_at") or ""),
                    }
    except OSError:
        return {}
    return index


def text_from_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, dict):
                if isinstance(item.get("text"), str):
                    parts.append(item["text"])
                elif isinstance(item.get("content"), str):
                    parts.append(item["content"])
            elif isinstance(item, str):
                parts.append(item)
        return "\n".join(part for part in parts if part)
    return ""


def redact_secrets(text: str) -> str:
    result = text
    for pattern in SECRET_PATTERNS:
        result = pattern.sub("[REDACTED]", result)
    return result


def is_real_user_prompt(text: str) -> bool:
    stripped = text.strip()
    if not stripped:
        return False
    if ENV_CONTEXT_RE.match(stripped):
        return False
    if stripped.startswith("<plugins_instructions>") or stripped.startswith("<skills_instructions>"):
        return False
    return True


def clamp(value: float, low: float = 0.0, high: float = 10.0) -> float:
    return max(low, min(high, value))


def count_words(text: str) -> int:
    ascii_words = re.findall(r"[A-Za-z0-9_]+", text)
    cjk_chars = re.findall(r"[\u4e00-\u9fff]", text)
    return len(ascii_words) + max(1, len(cjk_chars) // 2)


def parse_timestamp_key(value: str) -> datetime:
    if not value:
        return datetime.min
    normalized = value.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return datetime.min


def format_timestamp_minute(value: str) -> str:
    parsed = parse_timestamp_key(value)
    if parsed == datetime.min:
        return value
    return parsed.strftime("%Y-%m-%d %H:%M")


def review_sort_key(item: PromptReview) -> tuple[str, datetime, str, int]:
    return (item.thread_name or item.session_id, parse_timestamp_key(item.timestamp), item.session_id, item.turn_index)


def summary_sort_key(item: SessionSummary) -> tuple[str, datetime, str]:
    return (item.thread_name or item.session_id, parse_timestamp_key(item.first_timestamp), item.session_id)


def has_any(text: str, words: Iterable[str]) -> bool:
    lowered = text.lower()
    return any(word.lower() in lowered for word in words)


def classify_prompt(text: str) -> str:
    if has_any(text, ["不对", "不是", "改成", "调整", "修正", "重新"]):
        return "纠偏/ уточ清"
    if has_any(text, ["报错", "错误", "失败", "bug", "修复", "debug"]):
        return "排错"
    if has_any(text, ["review", "审查", "评价", "评分", "分析"]):
        return "评审/分析"
    if has_any(text, ["做", "实现", "生成", "创建", "写", "导出", "表格", "excel", "工具"]):
        return "执行/产出"
    if "?" in text or "？" in text or has_any(text, ["为什么", "怎么", "是否", "吗"]):
        return "询问"
    return "普通指令"


def score_prompt(text: str, has_prior_assistant: bool) -> tuple[dict[str, float], str, str, str, list[str]]:
    stripped = " ".join(text.strip().split())
    char_count = len(stripped)
    line_count = max(1, len([line for line in text.splitlines() if line.strip()]))
    numbered = bool(re.search(r"(^|\n)\s*(\d+[\.、)]|-|\*)\s+", text))
    has_action = has_any(text, ["做", "实现", "生成", "创建", "写", "读取", "导出", "分析", "评分", "评价", "修复", "支持"])
    has_output = has_any(text, ["excel", ".xlsx", "表格", "文件", "报告", "列表", "评分", "评价", "反馈", "概述"])
    has_target = has_any(text, ["codex", "对话", "工具", "代码", "文件", "项目", "脚本", "表格"])
    has_constraints = numbered or has_any(text, ["需要", "支持", "必须", "不要", "区分", "不同", "所有", "简单", "本地", "mac", "windows"])
    has_acceptance = has_any(text, ["验证", "通过", "输出", "字段", "格式", "评分", "评价", "清晰", "合理", "更好"])
    has_examples = has_any(text, ["例如", "比如", "示例", "样例", "example"])
    has_path_or_platform = bool(re.search(r"[A-Za-z]:\\|/Users/|~/|\.py|\.xlsx|\.jsonl|Windows|Mac|macOS", text, re.I))
    context_markers = re.findall(r"之前|刚才|上面|这个|那个|它|继续|不对|然后", text)
    question_count = text.count("?") + text.count("？")
    too_short = char_count < 18
    too_long = char_count > 900
    multiple_tasks = len(re.findall(r"、|\n\s*\d+[、.)]|并且|同时|然后|另外", text)) >= 5

    clarity = 5.8
    clarity += 1.0 if has_action else 0
    clarity += 0.8 if has_target else 0
    clarity += 0.7 if has_output else 0
    clarity += 0.5 if numbered or line_count > 1 else 0
    clarity -= 1.5 if too_short else 0
    clarity -= 0.9 if context_markers and not has_prior_assistant else 0
    clarity -= 0.4 if question_count >= 3 else 0

    context = 5.2
    context += 1.0 if has_target else 0
    context += 0.9 if has_prior_assistant and context_markers else 0
    context += 0.8 if has_path_or_platform else 0
    context += 0.7 if has_any(text, ["之前", "当前", "本地", "所有", "不同电脑", "Mac", "Windows", "codex"]) else 0
    context -= 1.2 if context_markers and not has_prior_assistant else 0
    context -= 0.8 if too_short else 0

    specificity = 4.8
    specificity += 1.3 if has_constraints else 0
    specificity += 1.0 if has_output else 0
    specificity += 0.8 if numbered else 0
    specificity += 0.6 if has_examples else 0
    specificity += 0.6 if has_path_or_platform else 0
    specificity -= 1.0 if not has_constraints else 0
    specificity -= 0.7 if too_short else 0

    actionability = 5.5
    actionability += 1.1 if has_action else 0
    actionability += 1.0 if has_output else 0
    actionability += 0.8 if has_acceptance else 0
    actionability += 0.5 if has_constraints else 0
    actionability -= 0.8 if not has_target else 0
    actionability -= 0.6 if too_short else 0

    scope_control = 7.2
    scope_control += 0.6 if numbered and line_count <= 8 else 0
    scope_control += 0.4 if has_output else 0
    scope_control -= 0.9 if too_long else 0
    scope_control -= 0.8 if multiple_tasks else 0
    scope_control -= 0.5 if has_any(text, ["所有"]) and not has_any(text, ["表格", "评分", "评价", "字段", "概述"]) else 0

    scores = {
        "clarity": round(clamp(clarity), 1),
        "context": round(clamp(context), 1),
        "specificity": round(clamp(specificity), 1),
        "actionability": round(clamp(actionability), 1),
        "scope_control": round(clamp(scope_control), 1),
    }
    overall = (
        scores["clarity"] * 0.25
        + scores["context"] * 0.2
        + scores["specificity"] * 0.22
        + scores["actionability"] * 0.23
        + scores["scope_control"] * 0.1
    )
    scores["overall"] = round(clamp(overall), 1)

    if scores["overall"] >= 8.5:
        grade = "优秀"
    elif scores["overall"] >= 7.4:
        grade = "良好"
    elif scores["overall"] >= 6.2:
        grade = "可用"
    else:
        grade = "需改进"

    strengths: list[str] = []
    gaps: list[str] = []
    themes: list[str] = []

    if has_action and has_target:
        strengths.append("目标和动作明确")
    if has_constraints:
        strengths.append("给出了约束或范围")
    if has_output:
        strengths.append("说明了期望产出")
    if numbered:
        strengths.append("结构化表达较好")

    if context_markers and not has_prior_assistant:
        gaps.append("较依赖上下文，单独看不够完整")
        themes.append("补充背景")
    if not has_output:
        gaps.append("缺少明确输出形式")
        themes.append("指定输出格式")
    if not has_constraints:
        gaps.append("缺少范围、字段或验收标准")
        themes.append("增加约束")
    if too_short:
        gaps.append("信息量偏少")
        themes.append("补充关键信息")
    if multiple_tasks or too_long:
        gaps.append("范围略散，适合拆成步骤或优先级")
        themes.append("拆分任务")
    if not gaps:
        gaps.append("可以再补充成功标准，让结果更稳定")
        themes.append("补充验收标准")

    feedback = f"{'；'.join(strengths) if strengths else '意图可以识别'}。主要可改进点：{'；'.join(gaps[:2])}。"
    improvement = build_improvement(has_output, has_constraints, context_markers, has_prior_assistant, multiple_tasks, too_long)
    suggested_rewrite = build_suggested_rewrite(text, has_output, has_constraints, context_markers, has_prior_assistant)

    return scores, grade, feedback, improvement, suggested_rewrite, themes


def build_improvement(
    has_output: bool,
    has_constraints: bool,
    context_markers: list[str],
    has_prior_assistant: bool,
    multiple_tasks: bool,
    too_long: bool,
) -> str:
    tips: list[str] = []
    if context_markers and not has_prior_assistant:
        tips.append("先用一句话补齐背景，不要只说“这个/之前”。")
    if not has_output:
        tips.append("明确要输出什么格式，例如表格、代码、清单或报告。")
    if not has_constraints:
        tips.append("补充关键约束：范围、平台、字段、不要做什么、完成标准。")
    if multiple_tasks or too_long:
        tips.append("把多个目标拆成 1、2、3，并标出优先级。")
    if not tips:
        tips.append("保留现有结构，再加一条“验收标准/我希望看到的列”。")
    return " ".join(tips)


def build_suggested_rewrite(text: str, has_output: bool, has_constraints: bool, context_markers: list[str], has_prior_assistant: bool) -> str:
    short = " ".join(text.strip().split())
    if len(short) > 120:
        short = short[:117] + "..."
    parts = ["请基于当前 Codex 本地会话数据完成以下任务："]
    parts.append(f"1. 目标：{short}")
    if not has_output:
        parts.append("2. 输出：请给出清晰的表格/文件，并说明每列含义。")
    else:
        parts.append("2. 输出：按我指定的格式交付，并附简短说明。")
    if not has_constraints:
        parts.append("3. 约束：说明支持的平台、读取范围、评分维度和不需要处理的内容。")
    else:
        parts.append("3. 验收：列出关键字段、成功标准和边界情况。")
    if context_markers and not has_prior_assistant:
        parts.append("4. 背景：补充“这个/之前”具体指什么。")
    return "\n".join(parts)


def extract_reviews(session_file: Path, index: dict[str, dict[str, str]], redact: bool) -> list[PromptReview]:
    session_id = UUID_RE.search(session_file.name).group(0) if UUID_RE.search(session_file.name) else ""
    thread_name = index.get(session_id, {}).get("thread_name", "")
    reviews: list[PromptReview] = []
    assistant_buffer: list[str] = []
    prompt_turn = 0

    try:
        handle = session_file.open("r", encoding="utf-8-sig", errors="replace")
    except OSError:
        return reviews

    with handle:
        for line in handle:
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            payload = item.get("payload")
            if not isinstance(payload, dict) or payload.get("type") != "message":
                continue

            role = payload.get("role")
            text = text_from_content(payload.get("content")).strip()
            if not text:
                continue

            if role == "assistant":
                assistant_buffer.append(text)
                if len("\n".join(assistant_buffer)) > 2000:
                    assistant_buffer = ["\n".join(assistant_buffer)[-2000:]]
                continue

            if role != "user" or not is_real_user_prompt(text):
                continue

            prompt_turn += 1
            if redact:
                text = redact_secrets(text)
            prior_assistant = "\n".join(assistant_buffer).strip()
            scores, grade, feedback, improvement, suggested_rewrite, themes = score_prompt(text, bool(prior_assistant))
            prompt_type = classify_prompt(text)
            reviews.append(
                PromptReview(
                    session_id=session_id,
                    thread_name=thread_name,
                    session_path=norm_path(session_file),
                    turn_index=prompt_turn,
                    timestamp=str(item.get("timestamp") or ""),
                    prompt=text[:32000],
                    prompt_excerpt=(" ".join(text.split())[:240]),
                    previous_assistant_excerpt=(" ".join(prior_assistant.split())[:240]),
                    prompt_type=prompt_type,
                    word_count=count_words(text),
                    char_count=len(text),
                    clarity=scores["clarity"],
                    context=scores["context"],
                    specificity=scores["specificity"],
                    actionability=scores["actionability"],
                    scope_control=scores["scope_control"],
                    overall=scores["overall"],
                    grade=grade,
                    feedback=feedback,
                    improvement=improvement,
                    suggested_rewrite=suggested_rewrite[:32000],
                    themes=themes,
                )
            )
            assistant_buffer = []

    return reviews


def summarize_sessions(reviews: list[PromptReview]) -> list[SessionSummary]:
    grouped: dict[str, list[PromptReview]] = defaultdict(list)
    for review in reviews:
        grouped[review.session_id].append(review)

    summaries: list[SessionSummary] = []
    for session_id, items in grouped.items():
        items = sorted(items, key=lambda r: r.turn_index)
        avg = round(sum(item.overall for item in items) / len(items), 1)
        strongest = max(items, key=lambda r: r.overall)
        weakest = min(items, key=lambda r: r.overall)
        theme_counts = Counter(theme for item in items for theme in item.themes)
        if theme_counts:
            main_feedback = "；".join(f"{theme} {count} 次" for theme, count in theme_counts.most_common(3))
        else:
            main_feedback = "整体较清晰，可继续补充验收标准"
        summaries.append(
            SessionSummary(
                session_id=session_id,
                thread_name=items[0].thread_name,
                session_path=items[0].session_path,
                prompt_count=len(items),
                avg_overall=avg,
                first_timestamp=items[0].timestamp,
                last_timestamp=items[-1].timestamp,
                strongest_prompt=strongest.prompt_excerpt,
                weakest_prompt=weakest.prompt_excerpt,
                main_feedback=main_feedback,
            )
        )
    return sorted(summaries, key=summary_sort_key)


def col_name(index: int) -> str:
    name = ""
    while index:
        index, rem = divmod(index - 1, 26)
        name = chr(65 + rem) + name
    return name


def cell_ref(row: int, col: int) -> str:
    return f"{col_name(col)}{row}"


def xml_text(value: Any) -> str:
    if value is None:
        return ""
    text = str(value)
    if len(text) > 32700:
        text = text[:32697] + "..."
    return escape(text, {"\n": "&#10;", "\r": ""})


def is_score_cell(max_col: int, row_idx: int, col_idx: int, value: Any) -> bool:
    if row_idx == 1 or not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    if not 0 <= float(value) <= 10:
        return False
    if max_col >= 21 and col_idx in {6, 8, 9, 10, 11, 12}:
        return True
    if max_col == 10 and col_idx == 4:
        return True
    return False


def score_style(value: Any) -> str:
    number = float(value)
    if number >= 8.5:
        return "4"
    if number >= 7.4:
        return "5"
    if number >= 6.2:
        return "6"
    return "7"


def cell_style(row_idx: int, col_idx: int, max_col: int, value: Any) -> str:
    if row_idx == 1:
        return "1"
    if is_score_cell(max_col, row_idx, col_idx, value):
        return score_style(value)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return "3"
    return "2" if len(str(value)) > 10 else "3"


def sheet_xml(rows: list[list[Any]], widths: list[int] | None = None, freeze: bool = True, autofilter: bool = True) -> str:
    max_col = max((len(row) for row in rows), default=1)
    widths = widths or [14] * max_col
    width_xml = "".join(
        f'<col min="{idx}" max="{idx}" width="{width}" customWidth="1"/>'
        for idx, width in enumerate(widths[:max_col], start=1)
    )
    pane_xml = (
        '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
        '<selection pane="bottomLeft"/></sheetView></sheetViews>'
        if freeze and rows
        else '<sheetViews><sheetView workbookViewId="0"/></sheetViews>'
    )
    row_xml_parts: list[str] = []
    for r_idx, row in enumerate(rows, start=1):
        cells: list[str] = []
        for c_idx, value in enumerate(row, start=1):
            ref = cell_ref(r_idx, c_idx)
            style = cell_style(r_idx, c_idx, max_col, value)
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                cells.append(f'<c r="{ref}" s="{style}"><v>{value}</v></c>')
            else:
                cells.append(f'<c r="{ref}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{xml_text(value)}</t></is></c>')
        row_xml_parts.append(f'<row r="{r_idx}">{"".join(cells)}</row>')
    dimension = f"A1:{cell_ref(max(1, len(rows)), max_col)}"
    filter_xml = f'<autoFilter ref="{dimension}"/>' if autofilter and rows and len(rows) > 1 else ""
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f'<dimension ref="{dimension}"/>'
        f"{pane_xml}"
        f"<cols>{width_xml}</cols>"
        f'<sheetData>{"".join(row_xml_parts)}</sheetData>'
        f"{filter_xml}"
        "</worksheet>"
    )


def workbook_xml(sheet_names: list[str]) -> str:
    sheets = "".join(
        f'<sheet name="{escape(name)}" sheetId="{idx}" r:id="rId{idx}"/>'
        for idx, name in enumerate(sheet_names, start=1)
    )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f"<sheets>{sheets}</sheets>"
        "</workbook>"
    )


def workbook_rels_xml(sheet_count: int) -> str:
    rels = []
    for idx in range(1, sheet_count + 1):
        rels.append(
            f'<Relationship Id="rId{idx}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{idx}.xml"/>'
        )
    rels.append(
        f'<Relationship Id="rId{sheet_count + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
    )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        f'{"".join(rels)}'
        "</Relationships>"
    )


def root_rels_xml() -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        "</Relationships>"
    )


def content_types_xml(sheet_count: int) -> str:
    sheets = "".join(
        f'<Override PartName="/xl/worksheets/sheet{idx}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        for idx in range(1, sheet_count + 1)
    )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        f"{sheets}"
        "</Types>"
    )


def styles_xml() -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<fonts count="2">'
        '<font><sz val="11"/><name val="Calibri"/></font>'
        '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
        '</fonts>'
        '<fills count="7">'
        '<fill><patternFill patternType="none"/></fill>'
        '<fill><patternFill patternType="gray125"/></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFD9EAD3"/><bgColor indexed="64"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFE2F0D9"/><bgColor indexed="64"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFF4CCCC"/><bgColor indexed="64"/></patternFill></fill>'
        '</fills>'
        '<borders count="2">'
        '<border><left/><right/><top/><bottom/><diagonal/></border>'
        '<border><left style="thin"><color rgb="FFD9E2F3"/></left><right style="thin"><color rgb="FFD9E2F3"/></right><top style="thin"><color rgb="FFD9E2F3"/></top><bottom style="thin"><color rgb="FFD9E2F3"/></bottom><diagonal/></border>'
        '</borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="8">'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top" wrapText="1"/></xf>'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        '<xf numFmtId="0" fontId="0" fillId="3" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        '<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        '<xf numFmtId="0" fontId="0" fillId="5" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        '<xf numFmtId="0" fontId="0" fillId="6" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        '</cellXfs>'
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        "</styleSheet>"
    )


def write_xlsx(output_path: Path, sheets: list[tuple[str, list[list[Any]], list[int]]]) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types_xml(len(sheets)))
        zf.writestr("_rels/.rels", root_rels_xml())
        zf.writestr("xl/workbook.xml", workbook_xml([name for name, _, _ in sheets]))
        zf.writestr("xl/_rels/workbook.xml.rels", workbook_rels_xml(len(sheets)))
        zf.writestr("xl/styles.xml", styles_xml())
        for idx, (_, rows, widths) in enumerate(sheets, start=1):
            zf.writestr(f"xl/worksheets/sheet{idx}.xml", sheet_xml(rows, widths))


def build_workbook_rows(reviews: list[PromptReview], summaries: list[SessionSummary], codex_home: Path | None) -> list[tuple[str, list[list[Any]], list[int]]]:
    total = len(reviews)
    avg = round(sum(r.overall for r in reviews) / total, 1) if total else 0
    grade_counts = Counter(r.grade for r in reviews)
    theme_counts = Counter(theme for r in reviews for theme in r.themes)
    prompt_type_counts = Counter(r.prompt_type for r in reviews)

    summary_rows: list[list[Any]] = [
        ["指标", "结果", "说明"],
        ["生成时间", datetime.now().strftime("%Y-%m-%d %H:%M"), "本地时间"],
        ["Codex 数据目录", norm_path(codex_home) if codex_home else "未找到", "只读扫描"],
        ["会话数", len(summaries), "包含至少一条真实用户提问的会话"],
        ["提问数", total, "已过滤 environment_context 等系统注入内容"],
        ["平均总分", avg, "0-10，越高表示提问越清晰、可执行"],
    ]
    for grade in ["优秀", "良好", "可用", "需改进"]:
        summary_rows.append([f"{grade}提问数", grade_counts.get(grade, 0), ""])
    summary_rows.append(["主要改进主题", "；".join(f"{k}({v})" for k, v in theme_counts.most_common(5)), ""])
    summary_rows.append(["提问类型分布", "；".join(f"{k}({v})" for k, v in prompt_type_counts.most_common()), ""])

    detail_rows: list[list[Any]] = [
        [
            "会话ID",
            "会话名称",
            "轮次",
            "时间",
            "提问类型",
            "总分",
            "等级",
            "清晰度",
            "上下文",
            "具体度",
            "可执行性",
            "范围控制",
            "简短评价",
            "改进建议",
            "建议改写",
            "提问摘要",
            "用户提问全文",
            "前一助手回复片段",
            "字符数",
            "估算词数",
            "会话文件",
        ]
    ]
    for r in sorted(reviews, key=review_sort_key):
        detail_rows.append(
            [
                r.session_id,
                r.thread_name,
                r.turn_index,
                format_timestamp_minute(r.timestamp),
                r.prompt_type,
                r.overall,
                r.grade,
                r.clarity,
                r.context,
                r.specificity,
                r.actionability,
                r.scope_control,
                r.feedback,
                r.improvement,
                r.suggested_rewrite,
                r.prompt_excerpt,
                r.prompt,
                r.previous_assistant_excerpt,
                r.char_count,
                r.word_count,
                r.session_path,
            ]
        )

    conversation_rows: list[list[Any]] = [
        ["会话ID", "会话名称", "提问数", "平均总分", "首条提问时间", "末条提问时间", "最强提问摘要", "最弱提问摘要", "主要反馈", "会话文件"]
    ]
    for s in sorted(summaries, key=summary_sort_key):
        conversation_rows.append(
            [
                s.session_id,
                s.thread_name,
                s.prompt_count,
                s.avg_overall,
                format_timestamp_minute(s.first_timestamp),
                format_timestamp_minute(s.last_timestamp),
                s.strongest_prompt,
                s.weakest_prompt,
                s.main_feedback,
                s.session_path,
            ]
        )

    rubric_rows = [
        ["维度", "含义", "高分表现", "常见扣分点"],
        ["清晰度", "别人单独看这句话能否理解你要什么", "动作、对象、目标明确", "只说“这个/之前/帮我弄一下”，缺少对象"],
        ["上下文", "是否给了必要背景、路径、平台、已有状态", "补充当前环境、约束、前置信息", "过度依赖对话记忆或隐含信息"],
        ["具体度", "要求是否足够细，边界是否明确", "列出字段、平台、范围、示例", "没有说明支持范围或判断标准"],
        ["可执行性", "Codex 能否直接开始做并验证结果", "说明产出、完成标准、验证方式", "只有想法，没有交付物或验收标准"],
        ["范围控制", "任务大小是否适合一次完成", "目标集中，步骤有优先级", "多个方向混在一起，过长或过散"],
        ["总分", "加权平均", "8.5+ 优秀，7.4+ 良好，6.2+ 可用", "低分不代表问题错误，只代表需要更多上下文和约束"],
    ]

    return [
        ("总览", summary_rows, [22, 42, 58]),
        ("逐条评分", detail_rows, [38, 18, 8, 22, 14, 8, 10, 8, 8, 8, 10, 10, 48, 54, 64, 48, 80, 52, 10, 10, 80]),
        ("会话汇总", conversation_rows, [38, 18, 10, 10, 22, 22, 54, 54, 50, 80]),
        ("评分规则", rubric_rows, [16, 42, 42, 46]),
    ]


def validate_xlsx(path: Path) -> tuple[bool, str]:
    try:
        with zipfile.ZipFile(path, "r") as zf:
            required = {"[Content_Types].xml", "xl/workbook.xml", "xl/styles.xml", "xl/worksheets/sheet1.xml"}
            missing = required.difference(zf.namelist())
            if missing:
                return False, f"missing workbook parts: {sorted(missing)}"
            bad = zf.testzip()
            if bad:
                return False, f"bad zip entry: {bad}"
    except Exception as exc:
        return False, str(exc)
    return True, "ok"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Score local Codex user prompts and export an Excel workbook.")
    parser.add_argument("--codex-home", help="Explicit Codex data directory, for example ~/.codex.")
    parser.add_argument("--session-dir", action="append", default=[], help="Additional session directory to scan.")
    parser.add_argument("--extra-root", action="append", default=[], help="Extra root to probe for Codex data.")
    parser.add_argument("--scan-root", action="append", default=[], help="Recursively scan a root for Codex data markers.")
    parser.add_argument("--scan-depth", type=int, default=4, help="Maximum depth for --scan-root. Default: 4.")
    parser.add_argument("--output", help="Output .xlsx path. Default: outputs/codex_conversation_review_<timestamp>.xlsx")
    parser.add_argument("--limit-sessions", type=int, default=0, help="Only process the most recent N session files.")
    parser.add_argument("--no-redact", action="store_true", help="Do not redact obvious API keys/tokens/password-like strings.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    homes = candidate_codex_homes(args.extra_root, args.scan_root, args.scan_depth)
    codex_home = choose_codex_home(homes, args.codex_home)
    if not codex_home:
        print("No Codex data directory found. Use --codex-home or --scan-root.", file=sys.stderr)
        return 2

    session_dirs = session_dirs_for(codex_home, args.session_dir)
    if not session_dirs:
        print("No Codex session directories found.", file=sys.stderr)
        return 2

    session_files = iter_session_files(session_dirs)
    if args.limit_sessions and args.limit_sessions > 0:
        session_files = sorted(session_files, key=lambda p: p.stat().st_mtime)[-args.limit_sessions :]

    index = read_session_index(codex_home)
    reviews: list[PromptReview] = []
    for session_file in session_files:
        reviews.extend(extract_reviews(session_file, index, redact=not args.no_redact))

    summaries = summarize_sessions(reviews)

    if args.output:
        output_path = Path(args.output).expanduser()
    else:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = Path.cwd() / "outputs" / f"codex_conversation_review_{stamp}.xlsx"

    sheets = build_workbook_rows(reviews, summaries, codex_home)
    write_xlsx(output_path, sheets)
    ok, message = validate_xlsx(output_path)
    if not ok:
        print(f"Excel export failed validation: {message}", file=sys.stderr)
        return 2

    avg = round(sum(r.overall for r in reviews) / len(reviews), 1) if reviews else 0
    print(f"Codex home: {norm_path(codex_home)}")
    print(f"Session files scanned: {len(session_files)}")
    print(f"User prompts reviewed: {len(reviews)}")
    print(f"Average score: {avg}")
    print(f"Output: {norm_path(output_path)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
