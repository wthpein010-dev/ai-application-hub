#!/bin/sh
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$DIR" || exit 1
mkdir -p outputs
if command -v python3 >/dev/null 2>&1; then
  python3 ./codex_conversation_reviewer.py
else
  python ./codex_conversation_reviewer.py
fi
printf "\nFinished. The Excel file is in:\n%s/outputs\n" "$DIR"
