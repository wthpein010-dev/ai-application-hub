#!/usr/bin/env python3
"""
Validate local Codex conversation/session data.

The tool is intentionally read-only. It discovers likely Codex data locations on
Windows, macOS, and Linux, then checks JSONL conversation files and the optional
session index for basic consistency.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


UUID_RE = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
)


@dataclass
class Finding:
    level: str
    message: str
    path: str | None = None


@dataclass
class SessionReport:
    path: str
    status: str = "ok"
    line_count: int = 0
    invalid_json_lines: int = 0
    id_from_meta: str | None = None
    id_from_filename: str | None = None
    first_timestamp: str | None = None
    last_timestamp: str | None = None
    has_session_meta: bool = False
    has_user_turn: bool = False
    has_assistant_turn: bool = False
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


@dataclass
class ValidationReport:
    platform: str
    codex_home: str | None
    session_dirs: list[str]
    index_path: str | None
    current_thread_id: str | None
    requested_thread_id: str | None
    sessions_checked: int = 0
    session_files_found: int = 0
    indexed_threads: int = 0
    invalid_index_lines: int = 0
    matched_sessions: list[SessionReport] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)


def norm_path(path: Path) -> str:
    return str(path.expanduser().resolve(strict=False))


def existing_dirs(paths: Iterable[Path]) -> list[Path]:
    seen: set[str] = set()
    found: list[Path] = []
    for raw in paths:
        path = raw.expanduser()
        key = norm_path(path).casefold()
        if key in seen:
            continue
        seen.add(key)
        if path.is_dir():
            found.append(path)
    return found


def marker_score(path: Path) -> int:
    points = 0
    for child in ("sessions", "archived_sessions"):
        if (path / child).is_dir():
            points += 4
    if (path / "session_index.jsonl").is_file():
        points += 3
    if (path / "config.toml").is_file():
        points += 1
    return points


def scan_for_codex_homes(roots: Iterable[str], max_depth: int) -> list[Path]:
    found: list[Path] = []
    for raw_root in roots:
        root = Path(raw_root).expanduser()
        if not root.is_dir():
            continue

        root_parts = len(root.parts)
        stack = [root]
        while stack:
            current = stack.pop()
            if len(current.parts) - root_parts > max_depth:
                continue
            if marker_score(current) > 0:
                found.append(current)
                continue
            try:
                stack.extend(child for child in current.iterdir() if child.is_dir())
            except OSError:
                continue
    return found


def candidate_codex_homes(extra_roots: Iterable[str], scan_roots: Iterable[str], scan_depth: int) -> list[Path]:
    home = Path.home()
    candidates: list[Path] = []

    env_home = os.environ.get("CODEX_HOME")
    if env_home:
        candidates.append(Path(env_home))

    candidates.append(home / ".codex")

    system = platform.system().lower()
    if system == "windows":
        for env_name in ("APPDATA", "LOCALAPPDATA", "PROGRAMDATA"):
            value = os.environ.get(env_name)
            if value:
                base = Path(value)
                candidates.extend(
                    [
                        base / "Codex",
                        base / "OpenAI" / "Codex",
                        base / "OpenAI" / "codex",
                    ]
                )
    elif system == "darwin":
        candidates.extend(
            [
                home / "Library" / "Application Support" / "Codex",
                home / "Library" / "Application Support" / "codex",
                home / "Library" / "Application Support" / "com.openai.codex",
            ]
        )
    else:
        xdg_config = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config"))
        xdg_state = Path(os.environ.get("XDG_STATE_HOME", home / ".local" / "state"))
        candidates.extend(
            [
                xdg_config / "codex",
                xdg_config / "Codex",
                xdg_state / "codex",
                xdg_state / "Codex",
            ]
        )

    for root in extra_roots:
        root_path = Path(root).expanduser()
        candidates.extend([root_path, root_path / ".codex", root_path / "Codex"])

    candidates.extend(scan_for_codex_homes(scan_roots, scan_depth))

    return existing_dirs(candidates)


def choose_codex_home(paths: list[Path], explicit: str | None) -> Path | None:
    if explicit:
        path = Path(explicit).expanduser()
        return path if path.is_dir() else None

    if not paths:
        return None

    def score(path: Path) -> tuple[int, float]:
        points = marker_score(path)
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0
        return (points, mtime)

    return max(paths, key=score)


def session_dirs_for(codex_home: Path | None, extra_session_dirs: Iterable[str]) -> list[Path]:
    candidates: list[Path] = []
    if codex_home:
        candidates.extend([codex_home / "sessions", codex_home / "archived_sessions"])
    candidates.extend(Path(value).expanduser() for value in extra_session_dirs)
    return existing_dirs(candidates)


def parse_timestamp(value: Any) -> str | None:
    if isinstance(value, str) and value:
        return value
    return None


def payload_contains_role(value: Any, role: str) -> bool:
    if isinstance(value, dict):
        if value.get("role") == role:
            return True
        return any(payload_contains_role(child, role) for child in value.values())
    if isinstance(value, list):
        return any(payload_contains_role(child, role) for child in value)
    return False


def validate_session_file(path: Path, thread_filter: str | None = None) -> SessionReport | None:
    report = SessionReport(path=norm_path(path))
    filename_match = UUID_RE.search(path.name)
    if filename_match:
        report.id_from_filename = filename_match.group(0)

    try:
        with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
            for line_no, line in enumerate(handle, start=1):
                line = line.strip()
                if not line:
                    continue
                report.line_count += 1
                try:
                    item = json.loads(line)
                except json.JSONDecodeError as exc:
                    report.invalid_json_lines += 1
                    if len(report.errors) < 5:
                        report.errors.append(f"line {line_no}: invalid JSON ({exc.msg})")
                    continue

                timestamp = parse_timestamp(item.get("timestamp"))
                if timestamp:
                    report.first_timestamp = report.first_timestamp or timestamp
                    report.last_timestamp = timestamp

                item_type = item.get("type")
                payload = item.get("payload")
                if item_type == "session_meta":
                    report.has_session_meta = True
                    if isinstance(payload, dict) and isinstance(payload.get("id"), str):
                        report.id_from_meta = payload["id"]

                if payload_contains_role(payload, "user"):
                    report.has_user_turn = True
                if payload_contains_role(payload, "assistant"):
                    report.has_assistant_turn = True

                if item_type == "message":
                    role = item.get("role")
                    report.has_user_turn = report.has_user_turn or role == "user"
                    report.has_assistant_turn = report.has_assistant_turn or role == "assistant"
    except OSError as exc:
        report.status = "error"
        report.errors.append(f"cannot read file: {exc}")
        return report if not thread_filter else None

    if thread_filter and thread_filter not in {report.id_from_meta, report.id_from_filename}:
        return None

    if report.line_count == 0:
        report.errors.append("file is empty")
    if report.invalid_json_lines:
        report.errors.append(f"{report.invalid_json_lines} invalid JSONL line(s)")
    if not report.has_session_meta:
        report.warnings.append("missing session_meta record")
    if report.id_from_meta and report.id_from_filename and report.id_from_meta != report.id_from_filename:
        report.errors.append("session id in metadata does not match filename")
    if not report.has_user_turn:
        report.warnings.append("no user turn detected")
    if not report.has_assistant_turn:
        report.warnings.append("no assistant turn detected")

    if report.errors:
        report.status = "error"
    elif report.warnings:
        report.status = "warning"
    return report


def load_session_index(path: Path | None, findings: list[Finding]) -> tuple[dict[str, dict[str, Any]], int]:
    if not path or not path.is_file():
        return {}, 0

    index: dict[str, dict[str, Any]] = {}
    invalid_lines = 0
    try:
        with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
            for line_no, line in enumerate(handle, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    invalid_lines += 1
                    continue
                thread_id = item.get("id")
                if isinstance(thread_id, str):
                    index[thread_id] = item
    except OSError as exc:
        findings.append(Finding("error", f"cannot read session index: {exc}", norm_path(path)))

    if invalid_lines:
        findings.append(Finding("warning", f"session index has {invalid_lines} invalid line(s)", norm_path(path)))
    return index, invalid_lines


def iter_session_files(dirs: Iterable[Path]) -> list[Path]:
    files: list[Path] = []
    for directory in dirs:
        try:
            files.extend(path for path in directory.rglob("*.jsonl") if path.is_file())
        except OSError:
            continue
    return sorted(files, key=lambda path: norm_path(path).casefold())


def validate(args: argparse.Namespace) -> ValidationReport:
    discovered_homes = candidate_codex_homes(args.extra_root, args.scan_root, args.scan_depth)
    codex_home = choose_codex_home(discovered_homes, args.codex_home)
    session_dirs = session_dirs_for(codex_home, args.session_dir)
    index_path = (codex_home / "session_index.jsonl") if codex_home else None
    current_thread_id = os.environ.get("CODEX_THREAD_ID")
    requested_thread_id = args.thread_id or (current_thread_id if args.current else None)

    report = ValidationReport(
        platform=platform.system() or sys.platform,
        codex_home=norm_path(codex_home) if codex_home else None,
        session_dirs=[norm_path(path) for path in session_dirs],
        index_path=norm_path(index_path) if index_path and index_path.exists() else None,
        current_thread_id=current_thread_id,
        requested_thread_id=requested_thread_id,
    )

    if args.codex_home and not codex_home:
        report.findings.append(Finding("error", "explicit --codex-home does not exist", args.codex_home))
    if not codex_home:
        report.findings.append(Finding("error", "no Codex data directory found"))
    if not session_dirs:
        report.findings.append(Finding("error", "no session directories found"))

    index, invalid_index_lines = load_session_index(index_path, report.findings)
    report.indexed_threads = len(index)
    report.invalid_index_lines = invalid_index_lines

    session_files = iter_session_files(session_dirs)
    report.session_files_found = len(session_files)

    if args.limit and args.limit > 0 and not requested_thread_id:
        session_files = session_files[-args.limit :]

    for session_file in session_files:
        session_report = validate_session_file(session_file, requested_thread_id)
        if session_report is None:
            continue
        report.matched_sessions.append(session_report)

    report.sessions_checked = len(report.matched_sessions)

    if requested_thread_id:
        if requested_thread_id not in index:
            report.findings.append(Finding("warning", "requested thread id was not found in session_index.jsonl"))
        if not report.matched_sessions:
            report.findings.append(Finding("error", "requested thread id has no readable session JSONL file"))

    known_session_ids = {
        value
        for item in report.matched_sessions
        for value in (item.id_from_meta, item.id_from_filename)
        if value
    }
    if requested_thread_id and requested_thread_id in known_session_ids:
        report.findings.append(Finding("ok", "requested thread id has a matching session file"))

    if report.session_files_found == 0 and session_dirs:
        report.findings.append(Finding("warning", "session directories exist but contain no JSONL files"))

    return report


def report_to_dict(report: ValidationReport) -> dict[str, Any]:
    return {
        "platform": report.platform,
        "codex_home": report.codex_home,
        "session_dirs": report.session_dirs,
        "index_path": report.index_path,
        "current_thread_id": report.current_thread_id,
        "requested_thread_id": report.requested_thread_id,
        "session_files_found": report.session_files_found,
        "sessions_checked": report.sessions_checked,
        "indexed_threads": report.indexed_threads,
        "invalid_index_lines": report.invalid_index_lines,
        "findings": [finding.__dict__ for finding in report.findings],
        "sessions": [session.__dict__ for session in report.matched_sessions],
    }


def print_text_report(report: ValidationReport) -> None:
    print("Codex conversation validation")
    print(f"Platform: {report.platform}")
    print(f"Codex home: {report.codex_home or 'not found'}")
    print(f"Session dirs: {', '.join(report.session_dirs) if report.session_dirs else 'not found'}")
    print(f"Session index: {report.index_path or 'not found'}")
    print(f"Current thread id: {report.current_thread_id or 'not set'}")
    if report.requested_thread_id:
        print(f"Requested thread id: {report.requested_thread_id}")
    print()
    print(f"Session files found: {report.session_files_found}")
    print(f"Sessions checked: {report.sessions_checked}")
    print(f"Indexed threads: {report.indexed_threads}")
    print(f"Invalid index lines: {report.invalid_index_lines}")
    print()

    if report.findings:
        print("Findings:")
        for finding in report.findings:
            suffix = f" ({finding.path})" if finding.path else ""
            print(f"  [{finding.level.upper()}] {finding.message}{suffix}")
        print()

    if report.matched_sessions:
        print("Sessions:")
        for session in report.matched_sessions:
            session_id = session.id_from_meta or session.id_from_filename or "unknown-id"
            print(f"  [{session.status.upper()}] {session_id}")
            print(f"    path: {session.path}")
            print(f"    lines: {session.line_count}, invalid JSONL lines: {session.invalid_json_lines}")
            print(f"    timestamps: {session.first_timestamp or 'unknown'} -> {session.last_timestamp or 'unknown'}")
            if session.errors:
                print(f"    errors: {'; '.join(session.errors)}")
            if session.warnings:
                print(f"    warnings: {'; '.join(session.warnings)}")
    else:
        print("Sessions: none matched")


def exit_code_for(report: ValidationReport) -> int:
    if any(finding.level == "error" for finding in report.findings):
        return 2
    if any(session.status == "error" for session in report.matched_sessions):
        return 2
    if any(finding.level == "warning" for finding in report.findings):
        return 1
    if any(session.status == "warning" for session in report.matched_sessions):
        return 1
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Validate local Codex conversation/session JSONL files across Windows and macOS."
    )
    parser.add_argument("--codex-home", help="Explicit Codex data directory, for example ~/.codex.")
    parser.add_argument(
        "--session-dir",
        action="append",
        default=[],
        help="Additional session directory to scan. Can be provided multiple times.",
    )
    parser.add_argument(
        "--extra-root",
        action="append",
        default=[],
        help="Extra root to probe for Codex data. Can be provided multiple times.",
    )
    parser.add_argument(
        "--scan-root",
        action="append",
        default=[],
        help="Recursively scan a root for Codex data markers. Use for unusual install/data locations.",
    )
    parser.add_argument(
        "--scan-depth",
        type=int,
        default=4,
        help="Maximum depth for --scan-root. Default: 4.",
    )
    parser.add_argument("--thread-id", help="Validate a specific Codex thread/session id.")
    parser.add_argument(
        "--current",
        action="store_true",
        help="Validate CODEX_THREAD_ID from the current Codex environment when available.",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="Only validate the most recent N session files after discovery. Default checks all.",
    )
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    start = datetime.now(timezone.utc)
    report = validate(args)
    data = report_to_dict(report)
    data["checked_at"] = start.isoformat()

    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print_text_report(report)

    return exit_code_for(report)


if __name__ == "__main__":
    raise SystemExit(main())
