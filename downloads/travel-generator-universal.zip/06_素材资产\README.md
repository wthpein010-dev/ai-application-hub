# 素材目录

此目录用于放置参赛素材，例如：

- 比赛海报
- 作品截图
- 演示视频封面
- Logo 或图标
- 分享卡片导出图

当前建议把原始素材和最终提交素材分开命名：

- `poster-competition.png`
- `cover-demo.png`
- `screenshot-home.png`
- `screenshot-result.png`

