@echo off
set "APP_DIR=%~dp0"
start "" "%APP_DIR%01_作品体验入口\app\index.html"
