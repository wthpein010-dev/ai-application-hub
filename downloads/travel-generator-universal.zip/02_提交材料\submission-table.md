# Submission Table

This file is an ASCII-named copy for helper scripts. The human-readable Chinese version is `提交内容总表.md`.

| Item | Current Content | Status |
|---|---|---|
| Work name | 朋友圈发图神器 | Confirmed |
| One-line intro | 输入一句旅行心情，AI 自动生成朋友圈拍照任务、配图收集格、预算建议和可分享文案。 | Ready |
| Experience entry | `01_作品体验入口\app\index.html` | Ready |
| Demo video | To record | Pending |
| Problem solved by AI | Turn a vague travel wish into an executable plan | Ready |
| Where AI is used | Intent understanding, route generation, content creation, constraint handling | Ready |
