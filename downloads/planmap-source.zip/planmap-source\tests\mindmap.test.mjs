import assert from "node:assert/strict";
import test from "node:test";

import {
  addChild,
  addSibling,
  applyOperations,
  createStarterDocument,
  findNode,
  moveNode,
  removeNode,
  updateNode,
} from "../app/lib/mindmap.ts";
import { layoutDocument } from "../app/lib/layout.ts";

test("tree edits keep immutable structure and preserve unique ids", () => {
  const original = createStarterDocument();
  const firstBranchId = original.root.children[0].id;
  const withChild = addChild(original, firstBranchId, "新增子项");

  assert.equal(original.root.children[0].children.length, 2);
  assert.equal(withChild.root.children[0].children.length, 3);
  assert.equal(withChild.root.children[0].children[2].title, "新增子项");

  const addedId = withChild.root.children[0].children[2].id;
  const renamed = updateNode(withChild, addedId, { title: "明确后的子项" });
  assert.equal(findNode(renamed.root, addedId)?.title, "明确后的子项");

  const sibling = addSibling(renamed, addedId, "同级事项");
  const titles = sibling.root.children[0].children.map((node) => node.title);
  assert.deepEqual(titles.slice(-2), ["明确后的子项", "同级事项"]);
  assert.equal(new Set(sibling.root.children[0].children.map((node) => node.id)).size, 4);
});

test("removing a branch removes its full subtree but never the root", () => {
  const original = createStarterDocument();
  const branchId = original.root.children[1].id;
  const descendantId = original.root.children[1].children[0].id;
  const removed = removeNode(original, branchId);

  assert.equal(findNode(removed.root, branchId), undefined);
  assert.equal(findNode(removed.root, descendantId), undefined);
  assert.equal(removeNode(original, original.root.id), original);
});

test("moving a node rejects cycles and moves valid branches", () => {
  const original = createStarterDocument();
  const sourceId = original.root.children[0].id;
  const descendantId = original.root.children[0].children[0].id;
  const targetId = original.root.children[2].id;

  assert.equal(moveNode(original, sourceId, descendantId), original);

  const moved = moveNode(original, descendantId, targetId);
  assert.equal(findNode(moved.root, targetId)?.children.at(-1)?.id, descendantId);
  assert.equal(findNode(moved.root, sourceId)?.children.some((node) => node.id === descendantId), false);
});

test("automatic mind-map layout is deterministic and splits root branches", () => {
  const document = createStarterDocument();
  const layout = layoutDocument(document, { width: 1200, height: 720 });
  const root = layout.nodes.find((node) => node.id === document.root.id);
  const first = layout.nodes.find((node) => node.id === document.root.children[0].id);
  const second = layout.nodes.find((node) => node.id === document.root.children[1].id);
  const third = layout.nodes.find((node) => node.id === document.root.children[2].id);

  assert.deepEqual(root && { x: root.x, y: root.y }, { x: 600, y: 360 });
  assert.ok(first && first.x > 600);
  assert.ok(second && second.x < 600);
  assert.ok(third && third.x > 600);
  assert.equal(layout.edges.length, 12);
  assert.deepEqual(layoutDocument(document, { width: 1200, height: 720 }), layout);
});

test("all six XMind-style structures position every node without manual placement", () => {
  const base = createStarterDocument();
  for (const mode of ["mindmap", "right", "tree", "fishbone", "logic", "timeline"]) {
    const document = { ...base, layout: mode };
    const layout = layoutDocument(document, { width: 1500, height: 900 });
    assert.equal(layout.nodes.length, 13, `${mode} should keep every node`);
    assert.equal(layout.edges.length, 12, `${mode} should connect every non-root node`);
    assert.equal(new Set(layout.nodes.map((node) => `${node.x}:${node.y}`)).size, 13, `${mode} should assign distinct positions`);
  }
});

test("all six structures keep a deep long-title map inside the computed canvas without overlaps", () => {
  const base = createStarterDocument();
  let cursor = base.root.children[0];
  cursor.title = "这是一条需要完整显示并自动排版的超长策划节点标题".repeat(4);
  for (let depth = 0; depth < 4; depth += 1) {
    const child = { id: `deep-${depth}`, title: `第${depth + 1}层深度节点`.repeat(8), children: [] };
    cursor.children.push(child);
    cursor = child;
  }

  for (const mode of ["mindmap", "right", "tree", "fishbone", "logic", "timeline"]) {
    const layout = layoutDocument({ ...base, layout: mode }, { width: 1500, height: 900 });
    for (const node of layout.nodes) {
      assert.ok(node.x - node.width / 2 >= 0, `${mode}:${node.id} exceeds the left edge`);
      assert.ok(node.y - node.height / 2 >= 0, `${mode}:${node.id} exceeds the top edge`);
      assert.ok(node.x + node.width / 2 <= layout.width, `${mode}:${node.id} exceeds the right edge`);
      assert.ok(node.y + node.height / 2 <= layout.height, `${mode}:${node.id} exceeds the bottom edge`);
    }
    for (let first = 0; first < layout.nodes.length; first += 1) {
      for (let second = first + 1; second < layout.nodes.length; second += 1) {
        const a = layout.nodes[first]; const b = layout.nodes[second];
        const overlaps = Math.abs(a.x - b.x) < (a.width + b.width) / 2 && Math.abs(a.y - b.y) < (a.height + b.height) / 2;
        assert.equal(overlaps, false, `${mode}:${a.id}/${b.id} should not overlap`);
      }
    }
  }
});

test("set-layout operations persist any supported structure", () => {
  const document = createStarterDocument();
  const next = applyOperations(document, [{ type: "set-layout", layout: "fishbone" }]);
  assert.equal(next.layout, "fishbone");
});
