import type { LayoutEdge, LayoutMode, LayoutNode } from "./types.ts";

function round(value: number): number {
  return Math.round(value * 100) / 100;
}

function portOffset(index: number, count: number, extent: number): number {
  if (count <= 1) return 0;
  const usable = Math.max(0, extent - 18);
  return -usable / 2 + usable * index / (count - 1);
}

export function edgePath(layout: LayoutMode, from: LayoutNode, to: LayoutNode, edge: Pick<LayoutEdge, "siblingIndex" | "siblingCount">): string {
  if (layout === "tree") {
    const startX = from.x + portOffset(edge.siblingIndex, edge.siblingCount, from.width);
    const startY = from.y + from.height / 2;
    const endX = to.x;
    const endY = to.y - to.height / 2;
    const curve = Math.max(28, Math.min(96, Math.abs(endY - startY) * 0.52));
    return `M ${round(startX)} ${round(startY)} C ${round(startX)} ${round(startY + curve)}, ${round(endX)} ${round(endY - curve)}, ${round(endX)} ${round(endY)}`;
  }

  if (layout === "timeline" && Math.abs(from.y - to.y) < 4) {
    const above = edge.siblingIndex % 2 === 0;
    const startX = from.x + portOffset(edge.siblingIndex, edge.siblingCount, from.width);
    const startY = from.y + (above ? -from.height / 2 : from.height / 2);
    const endX = to.x;
    const endY = to.y + (above ? -to.height / 2 : to.height / 2);
    const distance = 68 + Math.floor(edge.siblingIndex / 2) * 34;
    const laneY = above ? Math.min(startY, endY) - distance : Math.max(startY, endY) + distance;
    return `M ${round(startX)} ${round(startY)} C ${round(startX)} ${round(laneY)}, ${round(endX)} ${round(laneY)}, ${round(endX)} ${round(endY)}`;
  }

  if (layout === "timeline") {
    const startX = from.x + portOffset(edge.siblingIndex, edge.siblingCount, from.width);
    const startY = from.y + from.height / 2;
    const endX = to.x;
    const endY = to.y - to.height / 2;
    const laneY = startY + Math.max(24, Math.min(70, (endY - startY) * 0.42));
    return `M ${round(startX)} ${round(startY)} C ${round(startX)} ${round(laneY)}, ${round(endX)} ${round(laneY)}, ${round(endX)} ${round(endY)}`;
  }

  const direction = to.x >= from.x ? 1 : -1;
  const startX = from.x + direction * from.width / 2;
  const startY = from.y + portOffset(edge.siblingIndex, edge.siblingCount, from.height);
  const endX = to.x - direction * to.width / 2;
  const endY = to.y;
  const curve = Math.max(30, Math.min(118, Math.abs(endX - startX) * 0.5));
  return `M ${round(startX)} ${round(startY)} C ${round(startX + direction * curve)} ${round(startY)}, ${round(endX - direction * curve)} ${round(endY)}, ${round(endX)} ${round(endY)}`;
}
