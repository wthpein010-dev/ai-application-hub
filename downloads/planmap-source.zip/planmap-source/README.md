# PlanMap

PlanMap 是一款对话式策划脑图工具。用户描述游戏、产品、活动或内容策划目标后，应用会立即给出结构化初稿，并通过后续对话自动扩写、改名、删除或重组节点。

## 已实现

- 对话与脑图双栏联动
- 内置演示引擎、部署方统一 AI、自定义 OpenAI 兼容模型
- 自动排版、节点点选、双击改名、拖拽重连、节点配色
- 撤销与重做、本机多项目自动保存
- 三套浅色主题与三种脑图结构
- PNG、PDF、Markdown、XMind 导出
- 手机端对话/脑图页签

云端同步入口已预留，但需要后续接入账户与云存储后才会开放。

## 本地运行

要求 Node.js `>=22.13.0`。

```bash
npm install
npm run dev
```

## 验证

```bash
npm test
npm run lint
npx tsc --noEmit
```

## 统一 AI 配置

部署方可配置以下服务端环境变量；未配置时使用演示模式或让用户填写自己的模型设置。

- `PLANMAP_AI_API_KEY`：服务端模型密钥
- `PLANMAP_AI_BASE_URL`：OpenAI 兼容 API 地址，默认 `https://api.openai.com/v1`
- `PLANMAP_AI_MODEL`：模型名，默认 `gpt-4.1-mini`

用户自定义密钥仅写入其浏览器本机存储，不进入项目文件或导出内容。
