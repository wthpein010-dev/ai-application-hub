# 思维导图快捷工具产品审计优化 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 修复无效交互、让画布真正自适应、降低首屏脚本体积，并补齐移动端与无障碍细节。

**Architecture:** 将可测试的视图行为抽到 `app/lib/view-actions.ts`，React 组件只负责读取 DOM 能力和同步状态。导出依赖改为按需动态加载，CSS 仅调整移动端触控尺寸。

**Tech Stack:** React 19、TypeScript、Vinext/Vite、Node test runner、浏览器 Fullscreen/Web Share/Clipboard API。

**Spec:** `docs/superpowers/specs/2026-08-20-planmap-product-audit-design.md`

## Global Constraints

- 不新增依赖，不改变本地存储结构和六布局算法。
- 分享只在用户点击后触发，不自动上传内容。
- 先运行失败测试，再写最小实现。

---

### Task 1: 可测试的视图行为

**Files:**
- Create: `app/lib/view-actions.ts`
- Create: `tests/view-actions.test.mjs`
- Modify: `package.json`

**Interfaces:**
- Produces: `calculateFitView()`, `toggleFullscreen()`, `shareMindMap()`。

- [x] 写画布适配、全屏和分享的失败测试并确认失败原因是功能缺失。
- [x] 实现最小视图行为并确认新增测试通过。

### Task 2: 组件接入与真实大纲编辑

**Files:**
- Modify: `app/components/MindMapCanvas.tsx`
- Modify: `app/components/PlanMapApp.tsx`
- Modify: `tests/rendered-html.test.mjs`

**Interfaces:**
- Consumes: Task 1 的三个导出函数。
- Produces: 有效的自动适配、全屏、分享反馈和大纲改名。

- [x] 写 ARIA 状态和大纲改名入口的失败渲染测试并确认失败。
- [x] 接入行为、状态提示和大纲编辑，确认渲染与单元测试通过。

### Task 3: 按需导出与构建预算

**Files:**
- Modify: `app/components/MindMapCanvas.tsx`
- Create: `tests/build-budget.test.mjs`
- Modify: `package.json`

**Interfaces:**
- Produces: 小于 500,000 字节的 `PlanMapApp` 客户端分块。

- [x] 添加读取 Vite manifest 的构建预算测试，并在现有 560,923 字节分块上确认失败。
- [x] 将 PNG/PDF 依赖改为按需加载，构建后确认预算测试通过且导出仍可用。

### Task 4: 移动端与完整回归

**Files:**
- Modify: `app/globals.css`

**Interfaces:**
- Produces: 390px 下至少 44px 的主要触控目标。

- [x] 调整移动端触控尺寸与大纲编辑样式。
- [x] 为默认工作区加入确定性 ID 种子，消除服务端/客户端 hydration 差异。
- [x] 运行单元、构建预算、渲染、Lint、TypeScript 和桌面/手机浏览器回归。

## 实施结果

- `PlanMapApp` 首屏分块由 560,923 字节降至约 153 KB，PNG/PDF 依赖按需加载。
- PNG 与 PDF 真实浏览器导出分别在约 0.3 秒与 1.2 秒完成；导出覆盖完整、未缩放的布局，并提供进行中、成功与失败状态。
- 390×844 下六种结构选择改为两行三列，主要触控目标均达到 44px，页面无横向溢出。
- 桌面六布局与手机鱼骨/时间轴均为 13 个节点、0 重叠；自动适配、全屏、分享、大纲改名和撤销均完成浏览器回归。
- 最终门禁：34/34 单元测试、3/3 构建/渲染测试、ESLint 与 TypeScript 全部通过。
