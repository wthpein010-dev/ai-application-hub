import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "PlanMap · 对话式策划脑图",
  description: "通过对话生成、调整并交付专业策划脑图。",
  metadataBase: new URL("https://planmap.sites.openai.com"),
  openGraph: {
    title: "PlanMap · 对话式策划脑图",
    description: "把策划说清楚，脑图自动长出来。",
    images: [{ url: "/og.png", width: 1792, height: 928, alt: "PlanMap 对话生成策划脑图" }],
  },
  twitter: { card: "summary_large_image", title: "PlanMap · 对话式策划脑图", description: "把策划说清楚，脑图自动长出来。", images: ["/og.png"] },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
