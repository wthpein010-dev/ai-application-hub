import type { LayoutEdge, LayoutNode, LayoutResult, MindMapDocument, MindMapNode } from "./types.ts";

const NODE_HEIGHT = 38;
const LEVEL_GAP = 210;
const ROW_GAP = 24;

function nodeWidth(title: string, depth: number): number {
  const base = Math.max(92, Math.min(184, 42 + title.length * 15));
  return depth === 0 ? Math.max(base, 150) : base;
}

function leafCount(node: MindMapNode): number {
  if (node.collapsed || node.children.length === 0) return 1;
  return node.children.reduce((total, child) => total + leafCount(child), 0);
}

export function layoutDocument(document: MindMapDocument, viewport: { width: number; height: number }): LayoutResult {
  const nodes: LayoutNode[] = [];
  const edges: LayoutEdge[] = [];
  const centerX = Math.round(viewport.width / 2);
  const centerY = Math.round(viewport.height / 2);
  const rightOnly = document.layout === "right";
  const tree = document.layout === "tree";

  nodes.push({ id: document.root.id, title: document.root.title, x: centerX, y: tree ? 72 : centerY, width: nodeWidth(document.root.title, 0), height: 48, depth: 0, side: 0, colorIndex: 0 });

  const place = (current: MindMapNode, depth: number, side: -1 | 1, center: number, colorIndex: number, parentId: string) => {
    const x = tree ? center : centerX + side * depth * LEVEL_GAP;
    const y = tree ? 72 + depth * 112 : center;
    nodes.push({ id: current.id, title: current.title, x, y, width: nodeWidth(current.title, depth), height: NODE_HEIGHT, depth, side, colorIndex });
    edges.push({ id: `${parentId}:${current.id}`, from: parentId, to: current.id, side, colorIndex });
    if (current.collapsed || current.children.length === 0) return;
    if (tree) {
      const totalWidth = current.children.reduce((sum, child) => sum + leafCount(child) * 155, 0);
      let cursor = center - totalWidth / 2;
      current.children.forEach((child) => {
        const branchWidth = leafCount(child) * 155;
        place(child, depth + 1, 1, cursor + branchWidth / 2, colorIndex, current.id);
        cursor += branchWidth;
      });
      return;
    }
    const totalHeight = current.children.reduce((sum, child) => sum + leafCount(child) * (NODE_HEIGHT + ROW_GAP), 0);
    let cursor = center - totalHeight / 2;
    current.children.forEach((child) => {
      const branchHeight = leafCount(child) * (NODE_HEIGHT + ROW_GAP);
      place(child, depth + 1, side, cursor + branchHeight / 2, colorIndex, current.id);
      cursor += branchHeight;
    });
  };

  if (tree) {
    const totalWidth = document.root.children.reduce((sum, child) => sum + leafCount(child) * 155, 0);
    let cursor = centerX - totalWidth / 2;
    document.root.children.forEach((child, index) => {
      const width = leafCount(child) * 155;
      place(child, 1, 1, cursor + width / 2, index, document.root.id);
      cursor += width;
    });
  } else {
    const sides = document.root.children.map((_, index) => (rightOnly || index % 2 === 0 ? 1 : -1) as -1 | 1);
    ([-1, 1] as const).forEach((side) => {
      const branches = document.root.children.map((child, index) => ({ child, index })).filter((_, index) => sides[index] === side);
      const totalHeight = branches.reduce((sum, { child }) => sum + leafCount(child) * (NODE_HEIGHT + ROW_GAP), 0);
      let cursor = centerY - totalHeight / 2;
      branches.forEach(({ child, index }) => {
        const branchHeight = leafCount(child) * (NODE_HEIGHT + ROW_GAP);
        place(child, 1, side, cursor + branchHeight / 2, index, document.root.id);
        cursor += branchHeight;
      });
    });
  }

  return { nodes, edges, width: viewport.width, height: viewport.height };
}

