export function CenterFocusStrong() {
  return <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M1 4V2.3C1 1.6 1.6 1 2.3 1H4M8 1h1.7C10.4 1 11 1.6 11 2.3V4M11 8v1.7c0 .7-.6 1.3-1.3 1.3H8M4 11H2.3C1.6 11 1 10.4 1 9.7V8" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>;
}

