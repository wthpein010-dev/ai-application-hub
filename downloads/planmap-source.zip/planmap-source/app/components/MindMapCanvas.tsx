"use client";

import { CenterFocusStrong } from "@/app/icons";
import { Download, Edit3, Focus, Maximize2, Minus, Palette, Plus, RotateCcw, Trash2 } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toPng } from "html-to-image";
import { jsPDF } from "jspdf";
import { layoutDocument } from "../lib/layout";
import type { MindMapDocument } from "../lib/types";

interface MindMapCanvasProps {
  document: MindMapDocument;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onRename: (id: string, title: string) => void;
  onAddChild: (id: string) => void;
  onDelete: (id: string) => void;
  onMove: (id: string, parentId: string) => void;
  onStyle: (id: string, color: string) => void;
  onExportOpen: () => void;
  exportSignal: { type: "png" | "pdf"; id: number } | null;
}

const branchColors = ["var(--branch-1)", "var(--branch-2)", "var(--branch-3)", "var(--branch-4)", "var(--branch-5)"];
const WIDTH = 1500;
const HEIGHT = 900;

export function MindMapCanvas({ document, selectedId, onSelect, onRename, onAddChild, onDelete, onMove, onStyle, onExportOpen, exportSignal }: MindMapCanvasProps) {
  const [scale, setScale] = useState(0.78);
  const [pan, setPan] = useState({ x: -165, y: -90 });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [dragOrigin, setDragOrigin] = useState<{ x: number; y: number; panX: number; panY: number } | null>(null);
  const exportRef = useRef<HTMLDivElement>(null);
  const layout = useMemo(() => layoutDocument(document, { width: WIDTH, height: HEIGHT }), [document]);
  const nodeMap = useMemo(() => new Map(layout.nodes.map((node) => [node.id, node])), [layout]);

  useEffect(() => {
    if (!exportSignal || !exportRef.current) return;
    const run = async () => {
      const dataUrl = await toPng(exportRef.current!, { backgroundColor: getComputedStyle(documentElement()).getPropertyValue("--canvas-bg").trim() || "#f7f9fc", pixelRatio: 1.5, cacheBust: true });
      if (exportSignal.type === "png") {
        const anchor = globalThis.document.createElement("a"); anchor.href = dataUrl; anchor.download = `${document.title}.png`; anchor.click(); return;
      }
      const pdf = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      pdf.addImage(dataUrl, "PNG", 8, 8, pageWidth - 16, pageHeight - 16, undefined, "FAST");
      pdf.save(`${document.title}.pdf`);
    };
    void run();
  }, [exportSignal, document.title]);

  const resetView = () => { setScale(0.78); setPan({ x: -165, y: -90 }); };
  const beginEdit = (id: string, title: string) => { setEditingId(id); setDraft(title); };
  const finishEdit = () => { if (editingId && draft.trim()) onRename(editingId, draft.trim()); setEditingId(null); };

  return (
    <section className="canvas-panel" aria-label="脑图画布">
      <div className="canvas-heading">
        <div className="canvas-title"><strong>{document.title}</strong><span>{document.kind}</span></div>
        <div className="canvas-actions">
          <button className="secondary-button auto-layout" type="button" onClick={resetView}><RotateCcw size={15} />自动整理</button>
          <button className="primary export-button" type="button" onClick={onExportOpen}><Download size={16} />导出</button>
        </div>
      </div>
      <div
        className={`canvas-viewport ${dragOrigin ? "dragging" : ""}`}
        onPointerDown={(event) => { if (event.target === event.currentTarget || (event.target as HTMLElement).classList.contains("canvas-grid")) { setDragOrigin({ x: event.clientX, y: event.clientY, panX: pan.x, panY: pan.y }); onSelect(null); } }}
        onPointerMove={(event) => { if (dragOrigin) setPan({ x: dragOrigin.panX + event.clientX - dragOrigin.x, y: dragOrigin.panY + event.clientY - dragOrigin.y }); }}
        onPointerUp={() => setDragOrigin(null)}
        onPointerLeave={() => setDragOrigin(null)}
        onWheel={(event) => { event.preventDefault(); setScale((current) => Math.max(0.42, Math.min(1.45, current - event.deltaY * 0.0007))); }}
      >
        <div className="canvas-grid" />
        <div className="mindmap-stage" ref={exportRef} style={{ width: WIDTH, height: HEIGHT, transform: `translate(${pan.x}px, ${pan.y}px) scale(${scale})` }}>
          <svg className="edge-layer" width={WIDTH} height={HEIGHT} aria-hidden="true">
            {layout.edges.map((edge) => {
              const from = nodeMap.get(edge.from); const to = nodeMap.get(edge.to); if (!from || !to) return null;
              const startX = from.x + (edge.side > 0 ? from.width / 2 : -from.width / 2);
              const endX = to.x + (edge.side > 0 ? -to.width / 2 : to.width / 2);
              const bend = (startX + endX) / 2;
              return <path key={edge.id} d={`M ${startX} ${from.y} C ${bend} ${from.y}, ${bend} ${to.y}, ${endX} ${to.y}`} stroke={branchColors[edge.colorIndex % branchColors.length]} />;
            })}
          </svg>
          {layout.nodes.map((node) => {
            const selected = selectedId === node.id;
            const root = node.depth === 0;
            const sourceNode = findSource(document.root, node.id);
            const nodeColor = sourceNode?.color || branchColors[node.colorIndex % branchColors.length];
            return (
              <div
                key={node.id}
                className={`map-node ${root ? "root-node" : ""} ${selected ? "selected" : ""}`}
                role="button"
                tabIndex={0}
                style={{ left: node.x, top: node.y, width: node.width, minHeight: node.height, "--node-color": nodeColor } as React.CSSProperties}
                draggable={!root && editingId !== node.id}
                onDragStart={(event) => { setDraggedId(node.id); event.dataTransfer.effectAllowed = "move"; event.dataTransfer.setData("text/planmap-node", node.id); }}
                onDragEnd={() => setDraggedId(null)}
                onDragOver={(event) => { if (draggedId && draggedId !== node.id) { event.preventDefault(); event.dataTransfer.dropEffect = "move"; } }}
                onDrop={(event) => { event.preventDefault(); const source = event.dataTransfer.getData("text/planmap-node") || draggedId; if (source && source !== node.id) onMove(source, node.id); setDraggedId(null); }}
                onClick={(event) => { event.stopPropagation(); onSelect(node.id); }}
                onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); onSelect(node.id); } if (event.key === "F2") beginEdit(node.id, node.title); }}
                onDoubleClick={() => beginEdit(node.id, node.title)}
              >
                {editingId === node.id ? <input value={draft} onChange={(event) => setDraft(event.target.value)} onBlur={finishEdit} onKeyDown={(event) => { if (event.key === "Enter") finishEdit(); if (event.key === "Escape") setEditingId(null); }} /> : <span>{node.title}</span>}
                {!root && <i className="branch-bar" />}
                {selected && (
                  <div className="node-toolbar">
                    <button type="button" title="改名" onClick={(event) => { event.stopPropagation(); beginEdit(node.id, node.title); }}><Edit3 size={14} /></button>
                    <button type="button" title="添加子节点" onClick={(event) => { event.stopPropagation(); onAddChild(node.id); }}><Plus size={14} /></button>
                    <button type="button" title="切换节点颜色" onClick={(event) => { event.stopPropagation(); const palette = ["#2f80ed", "#7a67e8", "#12a594", "#ef8b43", "#e45d75"]; const index = sourceNode?.color ? palette.indexOf(sourceNode.color) : -1; onStyle(node.id, palette[(index + 1) % palette.length]); }}><Palette size={14} /></button>
                    {!root && <button type="button" title="删除节点" className="danger" onClick={(event) => { event.stopPropagation(); onDelete(node.id); }}><Trash2 size={14} /></button>}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="zoom-toolbar">
          <button type="button" aria-label="缩小画布" onClick={() => setScale((current) => Math.max(0.42, current - 0.1))}><Minus size={16} /></button>
          <span>{Math.round(scale * 100)}%</span>
          <button type="button" aria-label="放大画布" onClick={() => setScale((current) => Math.min(1.45, current + 0.1))}><Plus size={16} /></button>
          <i />
          <button type="button" aria-label="居中脑图" onClick={resetView}><Focus size={16} /></button>
          <button type="button" aria-label="全屏查看"><Maximize2 size={15} /></button>
        </div>
        <div className="mini-map" aria-hidden="true"><div className="mini-lines"><i /><i /><i /><i /><b /></div><span><CenterFocusStrong />画布导航</span></div>
        <div className="drag-hint">拖动节点到另一节点可重新连接</div>
      </div>
    </section>
  );
}

function documentElement() {
  return globalThis.document?.documentElement;
}

function findSource(root: MindMapDocument["root"], id: string): MindMapDocument["root"] | undefined {
  if (root.id === id) return root;
  for (const child of root.children) {
    const match = findSource(child, id);
    if (match) return match;
  }
  return undefined;
}
