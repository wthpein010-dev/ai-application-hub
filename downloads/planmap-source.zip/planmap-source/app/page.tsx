import type { Metadata } from "next";
import { PlanMapApp } from "./components/PlanMapApp";

export const metadata: Metadata = {
  title: "PlanMap · 对话式策划脑图",
  description: "把策划说清楚，脑图自动长出来。通过对话生成、调整并交付专业策划脑图。",
};

export default function Home() {
  return <PlanMapApp />;
}

