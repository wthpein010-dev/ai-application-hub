import assert from "node:assert/strict";
import test from "node:test";

import {
  addChild,
  addSibling,
  createStarterDocument,
  findNode,
  moveNode,
  removeNode,
  updateNode,
} from "../app/lib/mindmap.ts";
import { layoutDocument } from "../app/lib/layout.ts";

test("tree edits keep immutable structure and preserve unique ids", () => {
  const original = createStarterDocument();
  const firstBranchId = original.root.children[0].id;
  const withChild = addChild(original, firstBranchId, "新增子项");

  assert.equal(original.root.children[0].children.length, 2);
  assert.equal(withChild.root.children[0].children.length, 3);
  assert.equal(withChild.root.children[0].children[2].title, "新增子项");

  const addedId = withChild.root.children[0].children[2].id;
  const renamed = updateNode(withChild, addedId, { title: "明确后的子项" });
  assert.equal(findNode(renamed.root, addedId)?.title, "明确后的子项");

  const sibling = addSibling(renamed, addedId, "同级事项");
  const titles = sibling.root.children[0].children.map((node) => node.title);
  assert.deepEqual(titles.slice(-2), ["明确后的子项", "同级事项"]);
  assert.equal(new Set(sibling.root.children[0].children.map((node) => node.id)).size, 4);
});

test("removing a branch removes its full subtree but never the root", () => {
  const original = createStarterDocument();
  const branchId = original.root.children[1].id;
  const descendantId = original.root.children[1].children[0].id;
  const removed = removeNode(original, branchId);

  assert.equal(findNode(removed.root, branchId), undefined);
  assert.equal(findNode(removed.root, descendantId), undefined);
  assert.equal(removeNode(original, original.root.id), original);
});

test("moving a node rejects cycles and moves valid branches", () => {
  const original = createStarterDocument();
  const sourceId = original.root.children[0].id;
  const descendantId = original.root.children[0].children[0].id;
  const targetId = original.root.children[2].id;

  assert.equal(moveNode(original, sourceId, descendantId), original);

  const moved = moveNode(original, descendantId, targetId);
  assert.equal(findNode(moved.root, targetId)?.children.at(-1)?.id, descendantId);
  assert.equal(findNode(moved.root, sourceId)?.children.some((node) => node.id === descendantId), false);
});

test("automatic mind-map layout is deterministic and splits root branches", () => {
  const document = createStarterDocument();
  const layout = layoutDocument(document, { width: 1200, height: 720 });
  const root = layout.nodes.find((node) => node.id === document.root.id);
  const first = layout.nodes.find((node) => node.id === document.root.children[0].id);
  const second = layout.nodes.find((node) => node.id === document.root.children[1].id);
  const third = layout.nodes.find((node) => node.id === document.root.children[2].id);

  assert.deepEqual(root && { x: root.x, y: root.y }, { x: 600, y: 360 });
  assert.ok(first && first.x > 600);
  assert.ok(second && second.x < 600);
  assert.ok(third && third.x > 600);
  assert.equal(layout.edges.length, 12);
  assert.deepEqual(layoutDocument(document, { width: 1200, height: 720 }), layout);
});
