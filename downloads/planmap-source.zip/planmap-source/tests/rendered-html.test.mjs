import assert from "node:assert/strict";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);
  return worker.fetch(
    new Request("http://localhost/", { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("server renders the conversation-first PlanMap workspace", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);
  const html = await response.text();

  assert.match(html, /<title>PlanMap · 对话式策划脑图<\/title>/i);
  assert.match(html, /AI 策划搭档/);
  assert.match(html, /把策划说清楚，脑图自动长出来/);
  assert.match(html, /新品发布会策划/);
  assert.match(html, /导出/);
  assert.match(html, /自动整理/);
  assert.match(html, /演示模式/);
  assert.doesNotMatch(html, /codex-preview|Building your site|react-loading-skeleton/);
});

test("workspace exposes accessible primary actions", async () => {
  const response = await render();
  const html = await response.text();

  assert.match(html, /aria-label="发送消息"/);
  assert.match(html, /aria-label="打开设置"/);
  assert.match(html, /aria-label="撤销"/);
  assert.match(html, /aria-label="重做"/);
  assert.match(html, /aria-label="缩小画布"/);
  assert.match(html, /aria-label="放大画布"/);
});
