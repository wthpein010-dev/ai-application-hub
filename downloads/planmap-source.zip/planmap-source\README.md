# 思维导图快捷工具

思维导图快捷工具（内部项目 ID 仍为 PlanMap）是一款对话优先的智能脑图应用。用户描述游戏、产品、活动或内容策划目标后，应用会立即给出结构化初稿，并通过后续对话自动定位文字、扩写、改名、删除、重组或切换结构。

## 已实现

- 对话与脑图双栏联动
- 内置演示引擎、部署方统一 AI、自定义 OpenAI 兼容模型
- Ollama、LM Studio、LocalAI 与 OpenAI 兼容预设
- 不选节点也能进行全局文本替换和整体调整
- 自动排版、节点点选、双击改名、拖拽重连、节点配色
- 撤销与重做、本机多项目自动保存
- 三套浅色主题与六种脑图结构：左右、横向、树状、鱼骨、逻辑、时间轴
- 脑图、大纲、演示三种作品视图
- PNG、PDF、Markdown、XMind 导出
- 手机端对话/脑图页签

云端同步入口已预留，但需要后续接入账户与云存储后才会开放。

## 本地运行

要求 Node.js `>=22.13.0`。

```bash
npm install
npm run dev
```

## 验证

```bash
npm test
npm run lint
npx tsc --noEmit
```

## 统一 AI 配置

部署方可配置以下服务端环境变量；未配置时使用演示模式或让用户填写自己的模型设置。

- `PLANMAP_AI_API_KEY`：服务端模型密钥
- `PLANMAP_AI_BASE_URL`：OpenAI 兼容 API 地址，默认 `https://api.openai.com/v1`
- `PLANMAP_AI_MODEL`：模型名，默认 `gpt-4.1-mini`

用户自定义密钥仅写入其浏览器本机存储，不进入项目文件或导出内容。
