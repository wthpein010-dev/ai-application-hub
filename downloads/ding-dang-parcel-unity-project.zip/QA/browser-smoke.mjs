import {chromium} from 'file:///D:/AI-Workspace/Projects/after-hours-stall/Tools/node_modules/playwright/index.mjs';
import {createServer} from 'node:http';import {createReadStream,existsSync,statSync,writeFileSync} from 'node:fs';import {resolve,extname,join} from 'node:path';import assert from 'node:assert/strict';
const project='D:/AI-Workspace/Projects/ding-dang-parcel', root=resolve(project,'Builds/WebGL'), out=project+'/QA';
const server=createServer((req,res)=>{let p=resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));if(!p.startsWith(root)||!existsSync(p)){res.writeHead(404).end();return;}if(statSync(p).isDirectory())p=join(p,'index.html');res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.wasm':'application/wasm','.data':'application/octet-stream'})[extname(p)]||'application/octet-stream');createReadStream(p).pipe(res)});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base=process.argv[2]||'http://127.0.0.1:'+server.address().port+'/';
const browser=await chromium.launch({executablePath:'E:/AI-Workspace/Dev-Cache/playwright/chromium-1228/chrome-win64/chrome.exe',headless:true,args:['--enable-webgl','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const report=[];
try{for(const mobile of [false,true]){
 const viewport=mobile?{width:390,height:844}:{width:1100,height:900}, ctx=await browser.newContext({viewport,hasTouch:mobile,isMobile:mobile,deviceScaleFactor:1}),page=await ctx.newPage();let errors=[],resources=[];page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)resources.push(r.url()+':'+r.status())});const started=Date.now();
 await page.goto(base);await page.waitForFunction(()=>window.parcelInstance&&window.parcelStatus,null,{timeout:120000});await page.waitForTimeout(1600);
 await page.screenshot({path:out+'/initial-'+(mobile?'mobile':'desktop')+'.png'});
 const xy=(x,y)=>{const s=Math.min(viewport.width/600,viewport.height/1000);return{x:(viewport.width-600*s)/2+x*s,y:(viewport.height-1000*s)/2+y*s}};
 const tap=async(x,y)=>{const p=xy(x,y);if(mobile)await page.touchscreen.tap(p.x,p.y);else await page.mouse.click(p.x,p.y);await page.waitForTimeout(200)};
 const drag=async(x,y,tx,ty)=>{const a=xy(x,y),b=xy(tx,ty);if(mobile){const cdp=await ctx.newCDPSession(page);await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[a]});await page.waitForTimeout(200);await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[b]});await page.waitForTimeout(200);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await cdp.detach();}else{await page.mouse.move(a.x,a.y);await page.mouse.down();await page.waitForTimeout(150);await page.mouse.move(b.x,b.y,{steps:8});await page.waitForTimeout(150);await page.mouse.up();}await page.waitForTimeout(350)};
 const status=()=>page.evaluate(()=>window.parcelStatus);
 assert.match(await status(),/关卡=1;已放=0/);
 await tap(94,770);for(let i=0;i<3;i++)await tap(80,951);
 await drag(94,770,218,327);assert.match(await status(),/已放=1/);
 await tap(200,950);assert.match(await status(),/已放=0/);
 await drag(94,770,218,327);assert.match(await status(),/已放=1/);
 await page.reload();await page.waitForFunction(()=>window.parcelStatus?.includes('已放=1'),null,{timeout:120000});
 await tap(229,770);for(let i=0;i<2;i++)await tap(80,951);
 await drag(229,770,218,327);assert.match(await status(),/已放=1/);
 await drag(229,770,300,327);assert.match(await status(),/完成=True;解锁=2/);
 await page.screenshot({path:out+'/victory-'+(mobile?'mobile':'desktop')+'.png'});
 await page.reload();await page.waitForFunction(()=>window.parcelStatus?.includes('完成=True'),null,{timeout:120000});
 await tap(300,696);assert.match(await status(),/关卡=2;已放=0/);
 await tap(416,950);await page.screenshot({path:out+'/hint-'+(mobile?'mobile':'desktop')+'.png'});await tap(300,800);
 await tap(510,230);await page.screenshot({path:out+'/levels-'+(mobile?'mobile':'desktop')+'.png'});await tap(300,777);
 await tap(308,950);assert.match(await status(),/关卡=2;已放=0/);
 if(!mobile){
 const maps=["AAB/ABB","AAB/ACB/CCB","AABB/ACDB/CCDD","AAAB/CDDB/CCDB","AABB/ACBD/CCDD/EEED","AABBC/ADBBC/DDDEE","AAABB/ACDBB/CCDEE/FFDEE","AABBC/ADBCC/EDDFF/EEGGF","AAABB/ACDBB/CCDEE/FFDEG/FFGGG","AAABBC/ADDBCC/EDFFCC/EEFGHH/IIGGHH"];
 for(let n=1;n<10;n++){const rows=maps[n].split('/'), chars=[...new Set(rows.join(''))].sort(),w=rows[0].length,cell=Math.min(82,440/w),bx=(600-w*cell)/2,cols=chars.length>6?5:4;
 for(let i=0;i<chars.length;i++){const cx=30+(i%cols)*540/cols+(540/cols-6)/2,cy=715+Math.floor(i/cols)*104+40;await tap(cx,cy);let rot=(i+1)%4;for(let k=0;k<(4-rot)%4;k++)await tap(80,951);let xx=99,yy=99;rows.forEach((row,y)=>[...row].forEach((c,x)=>{if(c===chars[i]){xx=Math.min(xx,x);yy=Math.min(yy,y)}}));await drag(cx,cy,bx+(xx+.5)*cell,286+(yy+.5)*cell);}
 assert.match(await status(),new RegExp('关卡='+(n+1)+';.*完成=True'));if(n===6||n===9)await page.screenshot({path:out+'/level-'+(n+1)+'-complete.png'});if(n<9)await tap(300,696);
 }
}const metrics=await page.evaluate(()=>({heap:performance.memory?.usedJSHeapSize,status:window.parcelStatus,canvas:{w:document.querySelector('canvas').width,h:document.querySelector('canvas').height}}));
 assert.deepEqual(errors,[]);assert.deepEqual(resources,[]);report.push({mobile,viewport,seconds:(Date.now()-started)/1000,...metrics,errors,resources});await ctx.close();
}writeFileSync(out+'/browser-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}finally{await browser.close();server.close()}



