const {chromium}=await import(process.env.PARCEL_PLAYWRIGHT_MODULE||'playwright');
import{createServer}from'node:http';
import{createReadStream,existsSync,statSync,writeFileSync,mkdirSync}from'node:fs';
import{resolve,join,extname}from'node:path';
import assert from'node:assert/strict';
const project=resolve(import.meta.dirname,'..'),root=resolve(project,'Builds/WebGL'),out=join(project,'QA',(process.argv[2]?'mobile-1.1.0-public':'mobile-1.1.0')+(process.env.PARCEL_OUTPUT_SUFFIX||''));mkdirSync(out,{recursive:true});
const server=createServer((req,res)=>{let p=resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));if(!p.startsWith(root)||!existsSync(p)){res.writeHead(404).end();return;}if(statSync(p).isDirectory())p=join(p,'index.html');res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm','.data':'application/octet-stream'})[extname(p)]||'application/octet-stream');createReadStream(p).pipe(res)});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base=process.argv[2]||'http://127.0.0.1:'+server.address().port+'/';
const browser=await chromium.launch({executablePath:process.env.PARCEL_CHROMIUM_EXECUTABLE,headless:true,args:['--enable-webgl','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const maps=["AAB/ABB","AAB/ACB/CCB","AABB/ACDB/CCDD","AAAB/CDDB/CCDB","AABB/ACBD/CCDD/EEED","AABBC/ADBBC/DDDEE","AAABB/ACDBB/CCDEE/FFDEE","AABBC/ADBCC/EDDFF/EEGGF","AAABB/ACDBB/CCDEE/FFDEG/FFGGG","AAABBC/ADDBCC/EDFFCC/EEFGHH/IIGGHH"];
const cases=[{width:720,height:1280,touch:true},{width:360,height:640,touch:true,dpr:2},{width:390,height:844,touch:true,dpr:2},{width:1280,height:900,touch:false}].filter(c=>!process.env.PARCEL_CASE_WIDTH||c.width===Number(process.env.PARCEL_CASE_WIDTH));
const reports=[];let currentPage,currentName;
try{for(const test of cases){
 const name=test.width+'x'+test.height,context=await browser.newContext({viewport:{width:test.width,height:test.height},hasTouch:test.touch,isMobile:test.touch,deviceScaleFactor:test.dpr||1}),page=await context.newPage();currentPage=page;currentName=name;
 const errors=[],failed=[];page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)failed.push(r.url()+':'+r.status())});
 const begun=Date.now();await page.goto(base,{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.parcelInstance&&window.parcelStatus,null,{timeout:120000});await page.waitForTimeout(400);
 assert.equal(await page.evaluate(()=>window.parcelVersion),'1.1.0');assert.deepEqual(await page.evaluate(()=>window.parcelDesign),{width:720,height:1280});
 const state=async()=>Object.fromEntries((await page.evaluate(()=>window.parcelStatus)).split(';').map(s=>{const i=s.indexOf('=');return[s.slice(0,i),s.slice(i+1)]}));
 const check=async(key,value)=>assert.equal((await state())[key],String(value),name+' '+key);
 const xy=async(x,y)=>{const r=await page.locator('canvas').boundingBox(),z=Math.min(r.width/720,r.height/1280);return{x:r.x+(r.width-720*z)/2+x*z,y:r.y+(r.height-1280*z)/2+y*z}};
 const tap=async(x,y,delay=120)=>{const p=await xy(x,y);if(test.touch)await page.touchscreen.tap(p.x,p.y);else await page.mouse.click(p.x,p.y);await page.waitForTimeout(delay)};
 const cdp=test.touch?await context.newCDPSession(page):null;
 const begin=async(x,y)=>{const a=await xy(x,y);if(cdp)await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...a,id:0}]});else{await page.mouse.move(a.x,a.y);await page.mouse.down()}await page.waitForTimeout(100)};
 const move=async(x,y)=>{const p=await xy(x,y);if(cdp)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{...p,id:0}]});else await page.mouse.move(p.x,p.y,{steps:5});await page.waitForTimeout(100)};
 const end=async(cancel=false)=>{if(cdp)await cdp.send('Input.dispatchTouchEvent',{type:cancel?'touchCancel':'touchEnd',touchPoints:[]});else{if(cancel)await page.evaluate(()=>document.querySelector('canvas').dispatchEvent(new PointerEvent('pointercancel')));await page.mouse.up()}await page.waitForTimeout(240)};
 const drag=async(x,y,tx,ty,cancel=false)=>{await begin(x,y);await move(tx,ty);await end(cancel)};
 const snapshot=async()=>{const s=await state();return{moves:s['操作'],packed:s['摆放'],rotations:s['旋转']}};
 const same=async(before)=>assert.deepEqual(await snapshot(),before,name+' canceled/invalid input altered model');
 await check('关卡',1);await check('已放',0);await check('操作',0);
 await page.screenshot({path:join(out,name+'-initial.png')});
 await tap(113,971);await check('选中',0);await check('操作',0);await check('拖动',-1);
 for(let k=0;k<3;k++)await tap(105,1212);assert.equal((await state())['旋转'].split('/')[0],'0');await check('操作',3);
 let saved=await snapshot();await drag(113,971,261.6,423.2,true);await same(saved);await check('拖动',-1);
 await drag(113,971,-40,520);await same(saved);
 await drag(113,971,261.6,423.2);await check('已放',1);assert.equal((await state())['摆放'].split('/')[0],'0,0');
 await page.screenshot({path:join(out,name+'-playing.png')});
 saved=await snapshot();await drag(261.6,423.2,360,423.2,true);await same(saved);await check('拖动',-1);
 await drag(261.6,423.2,458.4,423.2);await same(saved);
 await tap(245.4,1212);await check('已放',0);await check('操作',3);
 saved=await snapshot();for(let i=0;i<4;i++)await tap(105,1212,65);await check('操作',Number(saved.moves)+4);assert.equal((await state())['旋转'],saved.rotations);
 await tap(372.6,1212);await check('操作',0);await check('已放',0);
 await tap(113,971);await tap(105,1212);await tap(499.8,1212);await check('界面','提示');await page.screenshot({path:join(out,name+'-hint.png')});
 saved=await snapshot();for(const x of [105,245.4,372.6,616.2]){await tap(x,x===616.2?294:1212);await same(saved);await check('界面','提示')}await drag(113,971,261.6,423.2);await same(saved);await check('界面','提示');
 await tap(360,1039.84);await check('界面','打包');await tap(372.6,1212);
 await tap(616.2,294);await check('界面','选关');await tap(501,481);await check('关卡',1);await check('界面','选关');
 await page.screenshot({path:join(out,name+'-levels.png')});await tap(360,1007.84);await check('界面','打包');
 await tap(113,971);for(let i=0;i<3;i++)await tap(105,1212);await drag(113,971,261.6,423.2);
 saved=await snapshot();await page.reload({waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.parcelStatus?.includes('已放=1'),null,{timeout:120000});await same({...saved,moves:'0'});
 await tap(275,971);await tap(105,1212);await tap(105,1212);
 saved=await snapshot();await drag(275,971,261.6,423.2);await same(saved);
 await drag(275,971,360,423.2);await check('完成','True');await check('解锁',2);await check('界面','通关');
 await page.screenshot({path:join(out,name+'-victory.png')});await page.reload({waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.parcelStatus?.includes('完成=True'),null,{timeout:120000});
 await tap(360,1009.12);await check('完成','False');await check('操作',0);await check('关卡',1);
 await tap(113,971);for(let i=0;i<3;i++)await tap(105,1212);await drag(113,971,261.6,423.2);await tap(275,971);for(let i=0;i<2;i++)await tap(105,1212);await drag(275,971,360,423.2);await check('完成','True');
 await tap(360,902.88);await check('关卡',2);await page.reload({waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.parcelStatus?.startsWith('关卡=2'),null,{timeout:120000});
 saved=await snapshot();
 // Cancel an active drag when the visual viewport changes (browser bars/orientation).
 await begin(113,971);await move(260,470);await page.setViewportSize({width:test.width,height:test.height+80});await page.waitForTimeout(400);await end();await same(saved);await check('拖动',-1);await page.setViewportSize({width:test.width,height:test.height});await page.waitForTimeout(350);
 // CSS safe area simulation: no controls should extend beneath reserved edges.
 await page.evaluate(()=>{for(const [k,v]of Object.entries({top:32,bottom:28,left:12,right:12}))document.documentElement.style.setProperty('--parcel-safe-'+k,v+'px')});await page.waitForTimeout(500);
 const rect=await page.locator('#viewport').boundingBox();assert.equal(rect.x,12);assert.equal(rect.y,32);assert.equal(rect.width,test.width-24);assert.equal(rect.height,test.height-60);
 await tap(499.8,1212);await check('界面','提示');await page.screenshot({path:join(out,name+'-safe-area.png')});await tap(360,1039.84);await check('界面','打包');
 await page.mouse.wheel(0,600);await page.waitForTimeout(100);assert.equal(await page.evaluate(()=>scrollY),0);
 await drag(140,80,140,220);await same(saved);assert.equal(await page.evaluate(()=>scrollY),0);
 if(cdp){const p1=await xy(100,80),p2=await xy(200,80);await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...p1,id:0},{...p2,id:1}]});await page.waitForTimeout(100);await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{...p1,x:p1.x-30,id:0},{...p2,x:p2.x+30,id:1}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(250);await same(saved);assert.equal(await page.evaluate(()=>visualViewport.scale),1)}
 await page.evaluate(()=>{for(const k of ['top','bottom','left','right'])document.documentElement.style.removeProperty('--parcel-safe-'+k)});await page.waitForTimeout(400);
 if(test.width===720&&!process.env.PARCEL_QUICK){for(let n=1;n<10;n++){const rows=maps[n].split('/'),chars=[...new Set(rows.join(''))].sort(),w=rows[0].length,c=Math.min(98.4,528/w),bx=(720-w*c)/2,cols=chars.length>6?5:4;
 for(let i=0;i<chars.length;i++){const x=36+(i%cols)*648/cols+(648/cols-8)/2,y=936+Math.floor(i/cols)*110+35;await tap(x,y);for(let k=0;k<(4-(i+1)%4)%4;k++)await tap(105,1212);let xx=99,yy=99;rows.forEach((row,y)=>[...row].forEach((t,x)=>{if(t===chars[i]){xx=Math.min(xx,x);yy=Math.min(yy,y)}}));await drag(x,y,bx+(xx+.5)*c,374+(yy+.5)*c);}
 await check('关卡',n+1);await check('完成','True');if(n===8||n===9)await page.screenshot({path:join(out,name+'-level-'+(n+1)+'.png')});if(n<9)await tap(360,902.88);
 }}
 const metrics=await page.evaluate(()=>({version:window.parcelVersion,status:window.parcelStatus,heap:performance.memory?.usedJSHeapSize,canvas:{width:document.querySelector('canvas').width,height:document.querySelector('canvas').height},scrollY,scale:visualViewport.scale}));
 assert.equal(metrics.canvas.width,test.width*(test.dpr||1));assert.equal(metrics.canvas.height,test.height*(test.dpr||1));assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);reports.push({name,touch:test.touch,deviceScaleFactor:test.dpr||1,realDevice:false,seconds:(Date.now()-begun)/1000,allTenLevels:test.width===720&&!process.env.PARCEL_QUICK,...metrics,errors,failed,checks:['tap','drag','touch-cancel','out-of-bounds','rotate','rapid-taps','undo','hint','restart','retry','progress-reload','unlock','resize-cancel','safe-area-simulation','no-scroll','modal-controls-blocked']});writeFileSync(join(out,'report.json'),JSON.stringify(reports,null,2));console.log(name+' passed');if(cdp)await cdp.detach();await context.close();
}console.log(JSON.stringify(reports,null,2));
}catch(e){if(currentPage)await currentPage.screenshot({path:join(out,currentName+'-failure.png')}).catch(()=>{});writeFileSync(join(out,'failure.txt'),String(e.stack));throw e}
finally{await browser.close();server.close()}
