# 验收方法
Unity 构建时 Parcel.Model.Validate 自动验证10关可解答案、面积、越界和撤销。
浏览器测试在 QA 下 npm install 后运行 npm run test:game（需要已安装 Playwright Chromium）；项目构建须位于 Builds/WebGL。可通过 PARCEL_CHROMIUM_EXECUTABLE 指定已安装浏览器，PARCEL_PLAYWRIGHT_MODULE 指定现有Playwright模块的file URL。不会运行Hub仓库的任何Node测试。
npm run test:page 需要同级 ding-dang-parcel-hub 工作树，检查独立介绍页、下载与试玩。
证据 browser-report.json、landing-report.json 和实际运行PNG截图。浏览器手机模拟不代表真机验证。WebGL初始WASM内存128MB，报告heap为JS堆，不是设备总内存。
