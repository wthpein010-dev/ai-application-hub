# 当前验收（v1.1.0）
QA下npm install后运行npm run test:game，需要已安装Playwright Chromium及Builds/WebGL构建。可用PARCEL_CHROMIUM_EXECUTABLE指定现有浏览器，用PARCEL_PLAYWRIGHT_MODULE指定现有模块file URL；TEMP/TMP建议设为D盘项目QA/Temp。PARCEL_CASE_WIDTH仅用于调试单一尺寸，完整验收不设置。PARCEL_QUICK跳过10关遍历，仅用于线上复核。
npm run test:legacy需要旧版WebGL构建于Builds/Legacy-v1.0.0或PARCEL_LEGACY_BUILD指定位置（旧构建不放入源工程包），旧运行写入存档后同源同路径加载新构建。
npm run test:page需要同级ding-dang-parcel-hub工作树，检查专属页、原管理员门禁和公开试玩。
mobile-1.1.0/report.json与legacy-save-report.json为本地证据；mobile-1.1.0-public为线上复核。安全区和手机均为浏览器模拟，不代表真实移动设备。JS heap采样不是设备或完整WASM总内存。
历史browser-smoke/public-smoke脚本对应v1.0.0；当前npm测试入口已改为mobile-smoke。Regression/modal-before.txt是验证修复前弹层点击穿透会失败的证据，不能当作当前构建失败。
不运行Hub全仓Node测试、ClickFlow或Python/Tk套件。
