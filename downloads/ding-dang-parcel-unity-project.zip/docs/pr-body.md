叮当打包铺是原创中文 Unity 空间装箱谜题：拖动、90度旋转搞怪连体小物，完成10个手工纸盒关卡。新增该游戏专属介绍页、可玩WebGL构建、真实运行截图及可打开Unity工程下载。

验证：Unity2022.3.62f3c1 WebGL构建成功；10关参考解答完整覆盖且无重叠；Chromium真实鼠标操作完成全部10关；390×844模拟单指触摸、撤销、非法落点、重开、提示、选关解锁和刷新进度恢复通过；桌面/手机版介绍页无横向溢出，工程下载200且试玩实际启动；无脚本错误或失败资源。真实iOS/Android设备及Windows独立播放器未验证。

美术/音效为原创程序化资源，中文字体Noto Sans CJK SC采用OFL。WebGL约27.5MB、工程包14.4MB。

仅新增projects/ding-dang-parcel及downloads/ding-dang-parcel-unity-project.zip，未改首页、共享清单、CI或求职网站。入口集成说明见专属目录INTEGRATION.md。
