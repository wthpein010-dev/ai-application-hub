> 历史记录：v1.0.0。当前手机版本请参阅 mobile-1.1.0.md 与 mobile-integration.md。

# 发布核验记录
版本1.0.0；PR161已合并，提交05748532a2d5a4cccce73f5bccdad9f619816ae6。
最终PR提交fff7dee1023f45e573cf4246945750994341c7e3的下载契约CI37247020333成功（15项）。
Pages run37247193949成功，Pages API status=built且commit=05748532a2d5a4cccce73f5bccdad9f619816ae6。
介绍页 https://wthpein010-dev.github.io/ai-application-hub/projects/ding-dang-parcel/
试玩 https://wthpein010-dev.github.io/ai-application-hub/projects/ding-dang-parcel/play/
线上浏览器桌面和390x844单指触摸：实际装箱、旋转、撤销、非法落点、刷新恢复、通关、选关、提示、重开通过，零pageerror和资源失败。截图及报告在QA/public。
全部10关正常鼠标操作通关证据在QA/browser-report.json；Unity构建成功及10关模型验证在Builds/build-final.log。
完整工程包14822521字节，SHA256 083AB42A56270909E4F18BA9BF57E3F7BD9522F54995F0A8694F0B5BFBD545B6。
Hub共享入口和game-producer-portfolio作品条目留给父线程集成；未改首页、共享清单、CI或求职站。网页下载按原管理员门禁，不绕过。真实移动设备与Windows独立播放器未验证。
本线程启动的Unity构建均已退出；08:27前保存检查点，无耗时构建运行。
