using System;using System.Runtime.InteropServices;using UnityEngine;using System.Collections.Generic;
namespace Parcel {
public class ParcelGame:MonoBehaviour {
#if UNITY_WEBGL && !UNITY_EDITOR
[DllImport("__Internal")]static extern void ParcelAnnounce(string s);
#endif
Model model;int level,selected=-1,drag=-1,unlocked;bool menu,help,finished,sound=true;string notice="拖动小物进纸盒，选中后可旋转";float toast,winTime;Vector2 mouse,offset;readonly ParcelViewport viewport=new ParcelViewport();bool pointerActive,blockUntilRelease,drawingModal;int activeTouch=-1;Vector2 pointerStart,tapStart;Vector2? tapPoint;Font font;Texture2D round,circle;GUIStyle label;AudioSource audioSource;AudioClip click;string last;
Color ink=new Color(.22f,.19f,.25f), cream=new Color(1,.96f,.87f);
Color[] colors={new Color(1,.73f,.22f),new Color(.36f,.76f,.62f),new Color(.98f,.43f,.48f),new Color(.57f,.57f,.86f),new Color(.35f,.70f,.89f),new Color(.98f,.63f,.39f),new Color(.85f,.60f,.77f),new Color(.64f,.76f,.36f),new Color(.68f,.77f,.92f)};
string[] names={"鸭鸭抱枕","薄荷袜袜","草莓吐司","月亮枕","鱼鱼玩偶","快乐靴","软糖包","仙人掌","星星糖"};
void Awake(){Application.targetFrameRate=60;Input.simulateMouseWithTouches=false;font=Resources.Load<Font>("ParcelChinese");round=Shape(false);circle=Shape(true);audioSource=gameObject.AddComponent<AudioSource>();click=AudioClip.Create("原创叮当音",4410,1,44100,false);float[] data=new float[4410];for(int i=0;i<data.Length;i++)data[i]=Mathf.Sin(i*2*Mathf.PI*740/44100)*Mathf.Exp(-i/700f)*.2f;click.SetData(data,0);unlocked=Mathf.Clamp(PlayerPrefs.GetInt("parcel.unlocked",1),1,10);Load(Mathf.Clamp(PlayerPrefs.GetInt("parcel.level",0),0,9),true);}
Texture2D Shape(bool disc){var t=new Texture2D(64,64,TextureFormat.RGBA32,false);for(int y=0;y<64;y++)for(int x=0;x<64;x++){float d=disc?Vector2.Distance(new Vector2(x,y),new Vector2(31.5f,31.5f))-31:Vector2.Distance(new Vector2(Mathf.Max(0,Mathf.Abs(x-31.5f)-21),Mathf.Max(0,Mathf.Abs(y-31.5f)-21)),Vector2.zero)-10;float a=Mathf.Clamp01(1-d);t.SetPixel(x,y,new Color(1,1,1,a));}t.Apply();return t;}
void Load(int n,bool restore=false){level=n;model=new Model(Levels.All[n]);selected=drag=-1;finished=false;menu=false;PlayerPrefs.SetInt("parcel.level",n);if(restore){string saved=PlayerPrefs.GetString("parcel.board."+n,"");var a=saved.Split(';');if(a.Length==model.pieces.Length){for(int i=0;i<a.Length;i++){var v=a[i].Split(',');if(v.Length==3&&int.TryParse(v[0],out int x)&&int.TryParse(v[1],out int y)&&int.TryParse(v[2],out int r)){r=Mathf.Clamp(r,0,3);if(x<0||model.Fits(i,x,y,r)){model.pieces[i].x=x;model.pieces[i].y=y;model.pieces[i].rotation=r;}}}finished=model.Won;}}Persist();}
void Persist(){var a=new List<string>();foreach(var p in model.pieces)a.Add(p.x+","+p.y+","+p.rotation);PlayerPrefs.SetString("parcel.board."+level,string.Join(";",a));PlayerPrefs.Save();}
float Cell=>Mathf.Min(98.4f,528f/model.level.w);Rect Board=>new Rect((720-model.level.w*Cell)/2,374,model.level.w*Cell,model.level.h*Cell);
Rect Tray(int i){int cols=model.pieces.Length>6?5:4;float w=648f/cols;return new Rect(36+(i%cols)*w,936+(i/cols)*110,w-8,108);}
Vector2 Pos(int i){var p=model.pieces[i];if(p.x>=0)return new Vector2(Board.x+p.x*Cell,Board.y+p.y*Cell);var t=Tray(i);var s=p.Shape();int w=1,h=1;foreach(var c in s){w=Math.Max(w,c.x+1);h=Math.Max(h,c.y+1);}float unit=TrayUnit(i);return new Vector2(t.center.x-w*unit/2,t.y+5);}
float TrayUnit(int i){var s=model.pieces[i].Shape();int w=1,h=1;foreach(var c in s){w=Math.Max(w,c.x+1);h=Math.Max(h,c.y+1);}return Mathf.Min(43.2f,Mathf.Min((Tray(i).width-14)/w,72f/h));}
void Update(){
 tapPoint=null;
 if(viewport.Update(Screen.safeArea,Screen.height)&&pointerActive)CancelPointer();
 mouse=viewport.ToGame(Input.mousePosition);
 if(blockUntilRelease){if(Input.touchCount==0&&!Input.GetMouseButton(0))blockUntilRelease=false;return;}
 if(Input.touchCount>0||activeTouch>=0){
  if(activeTouch<0){for(int i=0;i<Input.touchCount;i++){var t=Input.GetTouch(i);if(t.phase==TouchPhase.Began){activeTouch=t.fingerId;mouse=viewport.ToGame(t.position);BeginPointer();break;}}}
  bool found=false;
  for(int i=0;i<Input.touchCount;i++){var t=Input.GetTouch(i);if(t.fingerId!=activeTouch)continue;found=true;mouse=viewport.ToGame(t.position);if(t.phase==TouchPhase.Canceled)CancelPointer();else if(t.phase==TouchPhase.Ended){FinishPointer();if(Input.touchCount>1)blockUntilRelease=true;}break;}
  if(activeTouch>=0&&!found)CancelPointer();
  return;
 }
 if(Input.GetMouseButtonDown(0))BeginPointer();
 if(pointerActive&&Input.GetMouseButtonUp(0))FinishPointer();
 if(!menu&&!help&&!finished&&drag<0){if(Input.GetKeyDown(KeyCode.R)&&selected>=0)Rotate();if(Input.GetKeyDown(KeyCode.Z)){model.Undo();After();}}
}
void BeginPointer(){
 if(!viewport.Contains(mouse))return;
 pointerActive=true;pointerStart=mouse;drag=-1;
 if(menu||help||finished)return;
 for(int i=model.pieces.Length-1;i>=0;i--){
  var p=model.pieces[i];float c=p.x>=0?Cell:TrayUnit(i);Vector2 pos=Pos(i);bool hit=p.x<0&&Tray(i).Contains(mouse);
  foreach(var a in p.Shape())if(new Rect(pos.x+a.x*c,pos.y+a.y*c,c,c).Contains(mouse))hit=true;
  if(hit){selected=drag=i;offset=p.x>=0?mouse-pos:new Vector2(Cell/2,Cell/2);break;}
 }
}
void FinishPointer(){
 if(!pointerActive)return;
 pointerActive=false;activeTouch=-1;
 bool isTap=Vector2.Distance(mouse,pointerStart)<14;
 if(!viewport.Contains(mouse)){drag=-1;return;}
 if(drag<0){if(isTap){tapPoint=mouse;tapStart=pointerStart;}return;}
 int id=drag;drag=-1;
 if(isTap)return;
 Vector2 v=mouse-offset;int x=Mathf.RoundToInt((v.x-Board.x)/Cell),y=Mathf.RoundToInt((v.y-Board.y)/Cell);
 if(Board.Contains(mouse)){if(model.Place(id,x,y)){Ping();Notice("放得刚刚好！");After();}else Notice("这里放不下，试试旋转或换个位置");}
 else if(new Rect(36,936,648,220).Contains(mouse)){model.Remove(id);After();}
}
void CancelPointer(){pointerActive=false;drag=-1;activeTouch=-1;tapPoint=null;blockUntilRelease=true;}
public void ParcelCancelPointer(string reason){CancelPointer();}
void OnApplicationFocus(bool focus){if(!focus)CancelPointer();}
void OnApplicationPause(bool paused){if(paused)CancelPointer();}
void After(){Persist();if(model.Won){finished=true;winTime=Time.time;unlocked=Math.Max(unlocked,Math.Min(10,level+2));PlayerPrefs.SetInt("parcel.unlocked",unlocked);PlayerPrefs.Save();Ping();}Publish();}
void Notice(string s){notice=s;toast=Time.time+3;}
void Ping(){if(sound)audioSource.PlayOneShot(click);}
void Rotate(){if(selected<0){Notice("先点一下想旋转的小物");return;}if(model.Rotate(selected)){Ping();After();}else Notice("旋转会撞到邻居，先拖回备货区");}
void Publish(){string s="关卡="+(level+1)+";已放="+Array.FindAll(model.pieces,p=>p.x>=0).Length+";总数="+model.pieces.Length+";完成="+finished+";解锁="+unlocked+";操作="+model.moves+";选中="+selected+";拖动="+drag+";旋转="+string.Join("/",Array.ConvertAll(model.pieces,p=>p.rotation.ToString()))+";摆放="+string.Join("/",Array.ConvertAll(model.pieces,p=>p.x+","+p.y))+";布局=720x1280;界面="+(menu?"选关":help?"提示":finished?"通关":"打包");
if(s==last)return;last=s;
#if UNITY_WEBGL && !UNITY_EDITOR
ParcelAnnounce(s);
#endif
}
void Box(Rect r,Color c,bool disc=false){GUI.color=c;GUI.DrawTexture(r,disc?circle:round);GUI.color=Color.white;}
void Text(Rect r,string s,int size=22,Color? c=null,TextAnchor align=TextAnchor.MiddleCenter){label.fontSize=Mathf.RoundToInt(size*1.3f);label.normal.textColor=c??ink;label.alignment=align;GUI.Label(r,s,label);}
bool Button(Rect r,string s,Color? c=null){bool pressed=pointerActive&&drag<0&&r.Contains(pointerStart)&&r.Contains(mouse);Box(new Rect(r.x,r.y+5,r.width,r.height),ink);Box(new Rect(r.x,r.y+(pressed?3:0),r.width,r.height),c??cream);Text(r,s,21);if((!(menu||help||finished)||drawingModal)&&tapPoint.HasValue&&r.Contains(tapPoint.Value)&&r.Contains(tapStart)){tapPoint=null;Ping();return true;}return false;}
void DrawPiece(int i,Vector2 pos,float unit,bool ghost=false){var p=model.pieces[i];var a=p.Shape();Color col=colors[i%colors.Length];if(ghost)col.a=.55f;
foreach(var v in a){Rect r=new Rect(pos.x+v.x*unit+2,pos.y+v.y*unit+2,unit-4,unit-4);Box(new Rect(r.x,r.y+4,r.width,r.height),new Color(.25f,.20f,.25f,.22f));Box(r,ink);}
foreach(var v in a)foreach(var d in new[]{Vector2Int.right,Vector2Int.up})if(Array.IndexOf(a,v+d)>=0){float x=pos.x+v.x*unit,y=pos.y+v.y*unit;Box(d.x==1?new Rect(x+unit-9,y+2,18,unit-4):new Rect(x+2,y+unit-9,unit-4,18),ink);}
foreach(var v in a)Box(new Rect(pos.x+v.x*unit+4,pos.y+v.y*unit+4,unit-8,unit-9),col);
foreach(var v in a)foreach(var d in new[]{Vector2Int.right,Vector2Int.up})if(Array.IndexOf(a,v+d)>=0){float x=pos.x+v.x*unit,y=pos.y+v.y*unit;Box(d.x==1?new Rect(x+unit-11,y+4,22,unit-9):new Rect(x+4,y+unit-11,unit-8,22),col);}
foreach(var v in a){float x=pos.x+v.x*unit,y=pos.y+v.y*unit;Box(new Rect(x+unit*.18f,y+unit*.14f,unit*.60f,unit*.10f),new Color(1,1,1,.3f));if(i%3==2){for(int k=0;k<3;k++)Box(new Rect(x+unit*(.2f+k*.22f),y+unit*.78f,unit*.055f,unit*.09f),cream,true);}else if(i%3==1){Box(new Rect(x+unit*.72f,y+unit*.35f,unit*.06f,unit*.27f),new Color(1,1,1,.35f));}}
var f=a[0];float fx=pos.x+f.x*unit,fy=pos.y+f.y*unit;float eye=Mathf.Max(3,unit*.065f);Box(new Rect(fx+unit*.28f,fy+unit*.38f,eye,eye*1.4f),ink,true);Box(new Rect(fx+unit*.62f,fy+unit*.38f,eye,eye*1.4f),ink,true);
Box(new Rect(fx+unit*.15f,fy+unit*.57f,unit*.17f,unit*.08f),new Color(1,.30f,.39f,.5f),true);Box(new Rect(fx+unit*.67f,fy+unit*.57f,unit*.17f,unit*.08f),new Color(1,.30f,.39f,.5f),true);
if(i%3==0){Box(new Rect(fx+unit*.38f,fy+unit*.55f,unit*.26f,unit*.13f),new Color(1,.40f,.13f),true);Box(new Rect(fx+unit*.42f,fy+unit*.12f,unit*.16f,unit*.12f),cream,true);}else{Box(new Rect(fx+unit*.42f,fy+unit*.59f,unit*.16f,unit*.075f),ink,true);}
}
void OnGUI(){if(model==null)return;drawingModal=false;GUI.matrix=viewport.Matrix;label=new GUIStyle(GUI.skin.label){font=font,wordWrap=true,padding=new RectOffset(0,0,0,0)};GUI.skin.font=font;
Box(new Rect(0f,0f,720f,1280f),new Color(.98f,.89f,.75f));for(int i=0;i<12;i++)Box(new Rect((i*164)%696,51+i*100,7,7),new Color(.82f,.70f,.59f,.30f),true);
Box(new Rect(28.8f,32f,662.4f,212.48f),cream);Box(new Rect(52.8f,56.32f,105.6f,44.8f),new Color(.95f,.51f,.36f));Text(new Rect(52.8f,56.32f,105.6f,44.8f),"小店营业",16,Color.white);Text(new Rect(40.8f,101.12f,638.4f,85.76f),"叮当打包铺",43);Text(new Rect(48f,185.6f,624f,38.4f),"把奇奇怪怪，装成刚刚好。",19);
Text(new Rect(42f,266.24f,504f,46.08f),model.level.title,25,null,TextAnchor.MiddleLeft);if(Button(new Rect(555.6f,250f,121.2f,88f),"选关"))menu=!menu;
Text(new Rect(42f,306f,636f,42f),model.level.story,18,null,TextAnchor.MiddleLeft);
var b=Board;Box(new Rect(b.x-22,b.y-20,b.width+44,b.height+48),new Color(.70f,.43f,.25f));Box(new Rect(b.x-14,b.y-12,b.width+28,b.height+28),new Color(.85f,.62f,.38f));Box(new Rect(b.x-7,b.y-5,b.width+14,b.height+13),new Color(.95f,.78f,.53f));
for(int y=0;y<model.level.h;y++)for(int x=0;x<model.level.w;x++){Box(new Rect(b.x+x*Cell+2,b.y+y*Cell+2,Cell-4,Cell-4),new Color(.89f,.69f,.43f));Box(new Rect(b.x+x*Cell+Cell/2-2,b.y+y*Cell+Cell/2-2,4,4),new Color(.68f,.46f,.28f,.35f),true);}
for(int i=0;i<model.pieces.Length;i++)if(model.pieces[i].x>=0&&i!=drag)DrawPiece(i,Pos(i),Cell);if(model.level.h<=3){float yy=b.yMax+44;Box(new Rect(180,yy,360,82),cream);Box(new Rect(196,yy+14,66,56),new Color(.43f,.74f,.64f));Text(new Rect(196,yy+14,66,56),"邮",26,Color.white);Text(new Rect(278,yy+7,236,34),"寄往：快乐小街",19,null,TextAnchor.MiddleLeft);Text(new Rect(278,yy+43,236,30),"易萌 · 轻放 · 请抱抱",15,null,TextAnchor.MiddleLeft);}
Text(new Rect(40.8f,886f,400f,43.52f),"备货小物 · 点选再旋转",20,null,TextAnchor.MiddleLeft);Text(new Rect(444f,886f,240f,43.52f),Array.FindAll(model.pieces,p=>p.x>=0).Length+" / "+model.pieces.Length+" 已装好",19);
for(int i=0;i<model.pieces.Length;i++)if(model.pieces[i].x<0){var t=Tray(i);Box(t,selected==i?new Color(1,.84f,.47f):cream);if(i!=drag)DrawPiece(i,Pos(i),TrayUnit(i));Text(new Rect(t.x,t.y+75,t.width,32),names[i%names.Length],18);}
if(drag>=0){Vector2 v=mouse-offset;int x=Mathf.RoundToInt((v.x-b.x)/Cell),y=Mathf.RoundToInt((v.y-b.y)/Cell);if(b.Contains(mouse)){GUI.color=Color.white;DrawPiece(drag,new Vector2(b.x+x*Cell,b.y+y*Cell),Cell,true);}DrawPiece(drag,v,Cell);}
if(Button(new Rect(36f,1168f,138f,88f),"旋转 ↻",new Color(1,.79f,.30f)))Rotate();
if(Button(new Rect(189.6f,1168f,111.6f,88f),"撤销")){model.Undo();After();}
if(Button(new Rect(316.8f,1168f,111.6f,88f),"重开")){Load(level);Notice("重新打包，慢慢来");}
if(Button(new Rect(444f,1168f,111.6f,88f),"提示")){help=true;}
if(Button(new Rect(571.2f,1168f,112.8f,88f),sound?"音效 开":"音效 关"))sound=!sound;
if(Time.time<toast) {Box(new Rect(78f,820.48f,564f,51.2f),cream);Text(new Rect(78f,820.48f,564f,51.2f),notice,17);}
if(level==0&&!finished&&Time.time>=toast)Text(new Rect(42f,805.12f,636f,72.96f),"① 拖到纸盒  ② 点击旋转  ③ 全部装好\n放错可撤销，空隙不必按顺序填。",18);
drawingModal=true;if(menu){Overlay();Text(new Rect(66f,341.76f,588f,74.24f),"今天寄哪一单？",30);for(int i=0;i<10;i++){var r=new Rect(78+(i%2)*288,437+(i/2)*97,270,88);if(Button(r,(i<unlocked?"":"未解锁 · ")+(i+1)+" "+Levels.All[i].title.Split('：')[0],i<unlocked?cream:new Color(.83f,.79f,.71f))&&i<unlocked)Load(i,true);}if(Button(new Rect(210f,963.84f,300f,88f),"回到打包台"))menu=false;}
if(help){Overlay();Text(new Rect(66f,340.48f,588f,81.92f),"打包小秘诀",30);Text(new Rect(81.6f,433.92f,556.8f,115.2f),"先找角落，再找凹口。\n点一下小物，按「旋转」转 90 度。",21);float u=Mathf.Min(52.8f,288f/model.level.w);for(int i=0;i<model.pieces.Length;i++){var old=model.pieces[i].rotation;model.pieces[i].rotation=0;DrawPiece(i,new Vector2(360-model.level.w*u/2+model.level.answers[i].x*u,602+model.level.answers[i].y*u),u);model.pieces[i].rotation=old;}Text(new Rect(90f,906.24f,540f,64f),"参考装箱图 · 还有其他正确摆法哦",18);if(Button(new Rect(210f,995.84f,300f,88f),"我来试试看",new Color(1,.78f,.29f)))help=false;}
if(finished){for(int i=0;i<32;i++){float t=Time.time-winTime;float x=(i*99+Mathf.Sin(t+i)*30)%720;float y=(i*68+t*60)%1280;Box(new Rect(x,y,10,16),colors[i%colors.Length]);}Overlay();Text(new Rect(84f,378.88f,552f,99.84f),"叮当！打包完成",36);Box(new Rect(262.8f,503.04f,194.4f,162.56f),new Color(.84f,.58f,.32f));Box(new Rect(345.6f,503.04f,28.8f,162.56f),cream);Text(new Rect(247.2f,538.88f,225.6f,75.52f),"妥妥送达",23);Text(new Rect(91.2f,710.4f,537.6f,89.6f),level==9?"十单小快乐，全部寄出！\n谢谢你照顾每一件奇怪的小物。":"刚刚好的纸盒，满满当当的快乐。\n本单用了 "+model.moves+" 次操作",21);if(Button(new Rect(159.6f,858.88f,400.8f,88f),level==9?"再去选一单":"贴好标签 · 下一单",new Color(1,.78f,.29f))){if(level==9){finished=false;menu=true;}else Load(level+1);}if(Button(new Rect(213.6f,965.12f,292.8f,88f),"这单再玩一次"))Load(level);}
Publish();
}
void Overlay(){Box(new Rect(0f,0f,720f,1280f),new Color(.20f,.16f,.23f,.66f));Box(new Rect(48f,307.2f,624f,780.8f),cream);}
}}



