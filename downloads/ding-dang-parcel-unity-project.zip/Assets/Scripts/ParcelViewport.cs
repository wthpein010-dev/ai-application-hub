using UnityEngine;
namespace Parcel {
public sealed class ParcelViewport {
 public const float Width=720,Height=1280;
 public float Scale {get;private set;}=1;
 public Vector2 Origin {get;private set;}
 Rect last;
 public bool Update(Rect safe,int screenHeight){
  if(safe.width<=0||safe.height<=0)safe=new Rect(0,0,Screen.width,Screen.height);
  bool changed=safe!=last;last=safe;
  Scale=Mathf.Min(safe.width/Width,safe.height/Height);
  Origin=new Vector2(safe.x+(safe.width-Width*Scale)/2,screenHeight-safe.yMax+(safe.height-Height*Scale)/2);
  return changed;
 }
 public Vector2 ToGame(Vector2 screen)=>new Vector2((screen.x-Origin.x)/Scale,(Screen.height-screen.y-Origin.y)/Scale);
 public bool Contains(Vector2 game)=>new Rect(0,0,Width,Height).Contains(game);
 public Matrix4x4 Matrix=>Matrix4x4.TRS(new Vector3(Origin.x,Origin.y,0),Quaternion.identity,new Vector3(Scale,Scale,1));
}
}
