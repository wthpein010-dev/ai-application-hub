using System;using System.Collections.Generic;using UnityEngine;
namespace Parcel {
[Serializable] public class Piece {public Vector2Int[] cells; public int x=-1,y=-1,rotation; public Piece Clone(){return new Piece{cells=cells,x=x,y=y,rotation=rotation};} public Vector2Int[] Shape(int r=-1){if(r<0)r=rotation;var a=new Vector2Int[cells.Length];int mx=999,my=999;for(int i=0;i<a.Length;i++){int x=cells[i].x,y=cells[i].y;for(int j=0;j<r;j++){int t=x;x=-y;y=t;}a[i]=new Vector2Int(x,y);mx=Math.Min(mx,x);my=Math.Min(my,y);}for(int i=0;i<a.Length;i++)a[i]-=new Vector2Int(mx,my);return a;}}
public class Level {public string title,story; public int w,h; public Piece[] pieces;public Vector2Int[] answers;}
public static class Levels {
public static Level[] All=new[]{
 Make("第一单：软乎乎","小鸭抱枕和薄荷袜，第一次出门！",3,2,"AAB/ABB"),
 Make("鸭鸭去旅行","转一转，让小鸭和朋友靠在一起。",3,3,"AAB/ACB/CCB"),
 Make("草莓野餐","给草莓吐司留一个温暖的小角落。",4,3,"AABB/ACDB/CCDD"),
 Make("雨天寄件","小雨靴、仙人掌，一起躲进纸盒。",4,3,"AAAB/CDDB/CCDB"),
 Make("月亮邮局","月亮枕头弯弯，正好抱住小伙伴。",4,4,"AABB/ACBD/CCDD/EEED"),
 Make("给海边的你","海盐糖、鱼鱼玩偶和一双快乐袜。",5,3,"AABBC/ADBBC/DDDEE"),
 Make("周末杂货","每一个奇怪的小物，都值得被珍惜。",5,4,"AAABB/ACDBB/CCDEE/FFDEE"),
 Make("生日惊喜","蛋糕不可以挤坏，但朋友可以贴贴。",5,4,"AABBC/ADBCC/EDDFF/EEGGF"),
 Make("星星快递","转好角度，把星星稳稳送到远方。",5,5,"AAABB/ACDBB/CCDEE/FFDEG/FFGGG"),
 Make("叮当毕业单","最后一个纸盒，装满刚刚好的快乐。",6,5,"AAABBC/ADDBCC/EDFFCC/EEFGHH/IIGGHH")
};
static Level Make(string title,string story,int w,int h,string map){var rows=map.Split('/');var groups=new SortedDictionary<char,List<Vector2Int>>();for(int y=0;y<h;y++)for(int x=0;x<w;x++){char c=rows[y][x];if(!groups.ContainsKey(c))groups[c]=new List<Vector2Int>();groups[c].Add(new Vector2Int(x,y));}var ps=new List<Piece>();var ans=new List<Vector2Int>();foreach(var g in groups){int mx=99,my=99;foreach(var v in g.Value){mx=Math.Min(mx,v.x);my=Math.Min(my,v.y);}var a=g.Value.ToArray();for(int i=0;i<a.Length;i++)a[i]-=new Vector2Int(mx,my);ps.Add(new Piece{cells=a});ans.Add(new Vector2Int(mx,my));}return new Level{title=title,story=story,w=w,h=h,pieces=ps.ToArray(),answers=ans.ToArray()};}
}
public class Model {
public Level level;public Piece[] pieces;public Stack<Piece[]> history=new Stack<Piece[]>();public int moves;
public Model(Level l){level=l;pieces=Array.ConvertAll(l.pieces,p=>p.Clone());for(int i=0;i<pieces.Length;i++)pieces[i].rotation=(i+1)%4;}
public bool Fits(int id,int x,int y,int r){foreach(var a in pieces[id].Shape(r)){var p=a+new Vector2Int(x,y);if(p.x<0||p.y<0||p.x>=level.w||p.y>=level.h)return false;for(int j=0;j<pieces.Length;j++)if(j!=id&&pieces[j].x>=0)foreach(var b in pieces[j].Shape())if(p==b+new Vector2Int(pieces[j].x,pieces[j].y))return false;}return true;}
void Save(){history.Push(Array.ConvertAll(pieces,p=>p.Clone()));moves++;}
public bool Place(int i,int x,int y){if(!Fits(i,x,y,pieces[i].rotation))return false;Save();pieces[i].x=x;pieces[i].y=y;return true;}
public bool Rotate(int i){var p=pieces[i];int r=(p.rotation+1)%4;if(p.x>=0&&!Fits(i,p.x,p.y,r))return false;Save();p.rotation=r;return true;}
public void Remove(int i){if(pieces[i].x<0)return;Save();pieces[i].x=-1;pieces[i].y=-1;}
public bool Undo(){if(history.Count==0)return false;pieces=history.Pop();moves=Math.Max(0,moves-1);return true;}
public bool Won {get {foreach(var p in pieces)if(p.x<0)return false;return true;}}
public static void Validate(){for(int n=0;n<Levels.All.Length;n++){var m=new Model(Levels.All[n]);int area=0;for(int i=0;i<m.pieces.Length;i++){m.pieces[i].rotation=0;var a=m.level.answers[i];if(!m.Place(i,a.x,a.y))throw new Exception("Invalid solution "+n);area+=m.pieces[i].cells.Length;}if(!m.Won||area!=m.level.w*m.level.h)throw new Exception("Incomplete "+n);m.Undo();if(m.Won)throw new Exception("Undo failed");m=new Model(Levels.All[n]);if(m.Place(0,-1,0))throw new Exception("Bounds");if(m.Place(0,99,99))throw new Exception("Bounds");Debug.Log("PARCEL VERIFIED level "+(n+1)+" area "+area);}}
}}
