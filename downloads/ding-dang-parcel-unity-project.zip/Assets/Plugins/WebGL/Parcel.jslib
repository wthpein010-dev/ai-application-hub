mergeInto(LibraryManager.library,{ParcelAnnounce:function(ptr){window.parcelStatus=UTF8ToString(ptr);var e=document.getElementById('state');if(e)e.textContent=window.parcelStatus;}});
