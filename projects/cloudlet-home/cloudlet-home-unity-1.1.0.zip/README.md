# 小云朵搬家 v1.1.0
Unity 2022.3.62f3c1，原创中文风向解谜。720×1280竖屏基准，单指触摸和电脑鼠标可玩。保留十个手工关卡与cloudlet.*旧存档。
打开 Assets/Scenes/Cloudlet.unity。批处理构建：Unity -batchmode -quit -projectPath <工程目录> -executeMethod CloudBuild.WebGL -buildTarget WebGL。构建输出 Builds/WebGL，浏览器需要通过HTTP加载，不能直接打开file网址。
输入：按下捕获目标，目标内抬起执行一次；移出、取消、多指、窗口变化与切后台取消输入。后台暂停试飞并保存，返回后可继续调整。详见 docs/MOBILE-1.1.0.md。
美术与音效为原创程序绘制/合成。Noto Sans SC字体许可证：Assets/Fonts/OFL.txt。
验证：三档手机尺寸与桌面各10/10关；原生Unity Touch输入由Chromium CDP模拟，不代表真机；旧1.0.0进度/风向迁移与DPR3继续游玩通过；真实移动硬件与Safari未测。
复现：Tools内 npm install，npx playwright install chromium，npm test。
