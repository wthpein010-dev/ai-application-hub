using UnityEngine;
namespace Cloudlet {
// A gesture is captured by one enabled target at press time. It is consumed once
// after a release inside that same target. Cancellation never produces a tap.
public sealed class CloudTapInput {
 bool active,hasTarget,ready,blocked,endOnCapture;int finger,beginFrame,readyFrame,width,height;float suppressMouse;Rect target;Vector2 origin,current;public int AcceptedCount{get;private set;}public int CanceledCount{get;private set;}public string LastMode{get;private set;}="";
 public void Cancel(){if(active)CanceledCount++;active=false;hasTarget=false;ready=false;blocked=true;}
 void Begin(Vector2 p,int id,string mode){active=true;hasTarget=false;ready=false;endOnCapture=false;origin=current=p;finger=id;beginFrame=Time.frameCount;LastMode=mode;}
 void Move(Vector2 p){current=p;if(active&&hasTarget&&!target.Contains(p))Cancel();}
 void End(Vector2 p){Move(p);if(active&&hasTarget&&target.Contains(p)){ready=true;readyFrame=Time.frameCount;}active=false;}
 public void Poll(System.Func<Vector2,Vector2> map){ready=false;if(width!=Screen.width||height!=Screen.height){if(width!=0)Cancel();width=Screen.width;height=Screen.height;}
  int count=Input.touchCount;if(count>0){suppressMouse=Time.unscaledTime+.35f;if(count>1){Cancel();return;}if(blocked)return;Touch t=Input.GetTouch(0);Vector2 p=map(t.position);if(t.phase==TouchPhase.Began)Begin(p,t.fingerId,"touch");else if(active&&t.fingerId==finger){if(t.phase==TouchPhase.Canceled)Cancel();else if(t.phase==TouchPhase.Ended)End(p);else Move(p);}return;}
  if(active&&finger>=0)Cancel();if(blocked){if(!Input.GetMouseButton(0))blocked=false;return;}if(Time.unscaledTime<suppressMouse)return;Vector2 m=map(Input.mousePosition);if(Input.GetMouseButtonDown(0)){Begin(m,-1,"mouse");if(Input.GetMouseButtonUp(0))endOnCapture=true;}else if(active&&finger==-1){if(Input.GetMouseButtonUp(0))End(m);else if(Input.GetMouseButton(0))Move(m);else Cancel();}
 }
 public bool Take(Rect rect){if(active&&!hasTarget&&beginFrame==Time.frameCount&&rect.Contains(origin)){target=rect;hasTarget=true;if(endOnCapture)End(current);}if(ready&&readyFrame==Time.frameCount&&hasTarget&&target==rect&&rect.Contains(current)){ready=false;hasTarget=false;AcceptedCount++;return true;}return false;}
}
}
