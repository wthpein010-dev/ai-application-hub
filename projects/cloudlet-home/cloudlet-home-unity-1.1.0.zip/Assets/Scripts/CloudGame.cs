using System;using System.Collections.Generic;using System.Runtime.InteropServices;using UnityEngine;
namespace Cloudlet {
public class CloudGame:MonoBehaviour {
#if UNITY_WEBGL && !UNITY_EDITOR
[DllImport("__Internal")] static extern void CloudState(string s);
[DllImport("__Internal")] static extern float CloudCssRatio();
#endif
const float DesignWidth=720,DesignHeight=1280;readonly CloudTapInput input=new CloudTapInput();
float UiScale=>Mathf.Min(Screen.width/DesignWidth,Screen.height/DesignHeight);
float CssRatio {get {
#if UNITY_WEBGL && !UNITY_EDITOR
return Mathf.Max(1,CloudCssRatio());
#else
return 1;
#endif
}}
Vector2 ToDesign(Vector2 p){float scale=UiScale;return new Vector2((p.x-(Screen.width-DesignWidth*scale)/2)/scale,(Screen.height-p.y-(Screen.height-DesignHeight*scale)/2)/scale);}
Rect HitBox(float x,float y,float w,float h){float minimum=44*CssRatio/UiScale;return new Rect(x-Mathf.Max(0,minimum-w)/2,y-Mathf.Max(0,minimum-h)/2,Mathf.Max(w,minimum),Mathf.Max(h,minimum));}
bool Hit(float x,float y,float w,float h,bool modal=false,bool enabled=true){return enabled&&menu==modal&&input.Take(HitBox(x,y,w,h));}
public void CancelInput(){input.Cancel();if(winds!=null)Announce();}
public void PauseForBrowser(){input.Cancel();if(winds==null)return;Save();if(running)Stop("暂时停风啦，回来后可以继续调整。");else Announce();}
void OnApplicationFocus(bool focus){if(!focus)PauseForBrowser();}
void OnApplicationPause(bool pause){if(pause)PauseForBrowser();}
public Font chinese; Texture2D dot; GUIStyle label;int level,unlocked,solved;Dictionary<int,int> winds;Stack<Dictionary<int,int>> history=new Stack<Dictionary<int,int>>();Vector2[] pos,from;int[] cells;bool[] arrived;bool running,won;float beat,phase;int ticks,moves;string message="";int hints;bool menu;float flash;AudioSource sound;AudioClip tickClip,winClip;
Color ink=new Color(.16f,.24f,.28f),mint=new Color(.46f,.79f,.68f),gold=new Color(1,.79f,.35f),pink=new Color(1,.56f,.64f),blue=new Color(.53f,.73f,.94f);Color[] colors;
Level L=>Levels.All[level];void Start(){Input.simulateMouseWithTouches=false;colors=new[]{gold,pink,blue};dot=new Texture2D(64,64,TextureFormat.RGBA32,false);for(int y=0;y<64;y++)for(int x=0;x<64;x++){float d=Vector2.Distance(new Vector2(x+.5f,y+.5f),new Vector2(32,32));dot.SetPixel(x,y,new Color(1,1,1,Mathf.Clamp01(32-d)));}dot.Apply();sound=gameObject.AddComponent<AudioSource>();tickClip=Tone(550,.09f);winClip=Tone(830,.25f);unlocked=Mathf.Clamp(PlayerPrefs.GetInt("cloudlet.unlocked",0),0,9);solved=PlayerPrefs.GetInt("cloudlet.solved",0);level=Mathf.Clamp(PlayerPrefs.GetInt("cloudlet.level",0),0,unlocked);Load(true);}
AudioClip Tone(float f,float duration){int n=(int)(22050*duration);var a=new float[n];for(int i=0;i<n;i++)a[i]=Mathf.Sin(i*f*Mathf.PI*2/22050)*.15f*(1f-i/(float)n);var c=AudioClip.Create("Original chime",n,1,22050,false);c.SetData(a,0);return c;}
Vector2 Center(int c)=>new Vector2(128+(c%5)*116,368+(c/5)*116);
void Load(bool restore=false){winds=L.Solution();foreach(int c in L.controls)winds[c]=(winds[c]+1+(c%2))%4;history.Clear();moves=0;hints=0;flash=0;won=false;running=false;message=L.tip;menu=false;if(restore){string s=PlayerPrefs.GetString("cloudlet.wind."+level,"");var a=s.Split(',');if(a.Length==L.controls.Length)for(int i=0;i<a.Length;i++){int v;if(int.TryParse(a[i],out v)&&v>=0&&v<4)winds[L.controls[i]]=v;}}ResetClouds();Save();Announce();}
void ResetClouds(){pos=new Vector2[L.routes.Length];from=new Vector2[L.routes.Length];cells=new int[L.routes.Length];arrived=new bool[L.routes.Length];for(int i=0;i<cells.Length;i++){cells[i]=L.routes[i].cells[0];pos[i]=from[i]=Center(cells[i]);}ticks=0;phase=0;}
void Save(){PlayerPrefs.SetInt("cloudlet.level",level);PlayerPrefs.SetInt("cloudlet.unlocked",unlocked);PlayerPrefs.SetInt("cloudlet.solved",solved);var a=new List<string>();foreach(int c in L.controls)a.Add(winds[c].ToString());PlayerPrefs.SetString("cloudlet.wind."+level,string.Join(",",a));PlayerPrefs.Save();}
void Announce(){string s=JsonUtility.ToJson(new State{level=level+1,unlocked=unlocked+1,solved=solved,running=running,won=won,moves=moves,message=message,version="1.1.0",designWidth=720,designHeight=1280,menu=menu,winds=Array.ConvertAll(L.controls,c=>winds[c]),acceptedInputs=input.AcceptedCount,canceledInputs=input.CanceledCount,lastInput=input.LastMode,minButtonPixels=Mathf.Max(44,104*UiScale/CssRatio)});
#if UNITY_WEBGL && !UNITY_EDITOR
CloudState(s);
#endif
}
[Serializable] class State {public int level,unlocked,solved,moves;public bool running,won;public string message,version,lastInput;public int designWidth,designHeight,acceptedInputs,canceledInputs;public int[] winds;public bool menu;public float minButtonPixels;}
void Turn(int c){if(running||won)return;history.Push(new Dictionary<int,int>(winds));winds[c]=(winds[c]+1)%4;moves++;sound.PlayOneShot(tickClip,.5f);Save();Announce();}
void Undo(){if(running){Stop("已停风，可以继续调整。");return;}if(history.Count>0){winds=history.Pop();moves=Mathf.Max(0,moves-1);won=false;ResetClouds();message="撤销好了，再看看风向。";Save();Announce();}}
void Go(){if(running){Stop("已停风，可以继续调整。");return;}won=false;ResetClouds();running=true;beat=Time.time;message="呼——小云朵出发啦！";Announce();}
void Stop(string s){running=false;won=false;ResetClouds();message=s;Announce();}
void Update(){int canceled=input.CanceledCount;input.Poll(ToDesign);if(canceled!=input.CanceledCount&&winds!=null)Announce();flash=Mathf.Max(0,flash-Time.deltaTime);if(!running)return;phase=Mathf.Clamp01((Time.time-beat)/.5f);for(int i=0;i<pos.Length;i++)pos[i]=Vector2.Lerp(from[i],Center(cells[i]),phase*phase*(3-2*phase));if(phase<1)return;beat=Time.time;ticks++;bool all=true;for(int i=0;i<cells.Length;i++){if(arrived[i])continue;int c=cells[i],home=L.routes[i].cells[L.routes[i].cells.Length-1];if(c==home){arrived[i]=true;flash=.6f;sound.PlayOneShot(winClip,.45f);continue;}all=false;int d;if(!winds.TryGetValue(c,out d)){Stop("前面没有风带，转转黄色风车吧。 ");return;}int next=c+(d==0?1:d==1?5:d==2?-1:-5);if(next<0||next>24||(d%2==0&&next/5!=c/5)||!IsRoad(next)){Stop("哎呀，吹到花园里了！调整风向再出发。 ");return;}foreach(var r in L.routes)if(next==r.cells[r.cells.Length-1]&&next!=home){Stop("这不是我的小屋，看看屋顶颜色吧！");return;}from[i]=pos[i];cells[i]=next;}if(all){running=false;won=true;solved|=1<<level;unlocked=Mathf.Min(9,Mathf.Max(unlocked,level+1));message=level==9?"全村到家！你是最棒的风向管理员。":"到家啦！又完成一趟温柔的搬家。";flash=2;Save();Announce();}else if(ticks>35){Stop("风绕成圈了！换个方向试试。 ");} }
bool IsRoad(int c){foreach(var r in L.routes)foreach(int x in r.cells)if(c==x)return true;return false;}
void Ell(float x,float y,float w,float h,Color c){GUI.color=c;GUI.DrawTexture(new Rect(x,y,w,h),dot);GUI.color=Color.white;}
void Box(float x,float y,float w,float h,Color c){GUI.color=c;GUI.DrawTexture(new Rect(x,y,w,h),Texture2D.whiteTexture);GUI.color=Color.white;}
void Text(string s,float x,float y,float w,float h,int size,Color c,TextAnchor align=TextAnchor.MiddleCenter){label.fontSize=size;label.normal.textColor=c;label.alignment=align;GUI.Label(new Rect(x,y,w,h),s,label);}
bool Button(string s,float x,float y,float w,float h,Color c,int size=30,bool modal=false,bool enabled=true){Ell(x,y+5,w,h,new Color(.12f,.24f,.22f,.16f));Ell(x,y,w,h,c);Text(s,x,y,w,h,size,ink);return Hit(x,y,w,h,modal,enabled);}
void Cloud(Vector2 p,int col,float size=1){float bob=Mathf.Sin(Time.time*2+col)*3;float x=p.x,y=p.y+bob;var tint=col==0?new Color(1,1,.98f):Color.Lerp(colors[col],Color.white,.65f);Ell(x-34*size,y+13*size,70*size,12*size,new Color(ink.r,ink.g,ink.b,.1f));Ell(x-36*size,y-12*size,72*size,40*size,tint);Ell(x-23*size,y-27*size,41*size,44*size,tint);Ell(x+1*size,y-20*size,31*size,35*size,tint);Ell(x-14*size,y-1*size,5*size,7*size,ink);Ell(x+11*size,y-1*size,5*size,7*size,ink);Ell(x-25*size,y+9*size,10*size,5*size,pink);Ell(x+20*size,y+9*size,10*size,5*size,pink);Text("︶",x-13*size,y+3*size,27*size,20*size,18,ink);}
void House(Vector2 p,int col){Color c=colors[col];Ell(p.x-42,p.y+26,84,13,new Color(.15f,.3f,.2f,.12f));Box(p.x-29,p.y-11,58,42,new Color(1,.98f,.87f));Box(p.x+16,p.y-32,8,19,c);for(int i=0;i<26;i++)Box(p.x-i*1.65f,p.y-36+i,i*3.3f,2,c);Box(p.x-32,p.y-9,64,4,Color.Lerp(c,ink,.14f));Box(p.x-8,p.y+7,16,24,mint);Ell(p.x+2,p.y+18,3,3,gold);Box(p.x-23,p.y,12,12,blue);Box(p.x+12,p.y,12,12,blue);Text(col==0?"暖暖家":col==1?"桃桃家":"蓝蓝家",p.x-54,p.y+34,108,28,20,ink);}
void Tree(Vector2 p,int i){Box(p.x-3,p.y+6,6,28,new Color(.62f,.42f,.29f));Color leaf=i%2==0?mint:new Color(.64f,.82f,.58f);Ell(p.x-28,p.y-20,38,37,leaf);Ell(p.x-7,p.y-20,37,37,leaf);Ell(p.x-19,p.y-36,40,44,leaf);Ell(p.x-12,p.y-22,10,9,new Color(.81f,.93f,.68f));if(i%3==0){Ell(p.x+24,p.y+15,14,14,pink);Ell(p.x+28,p.y+19,6,6,gold);}}
void Arrow(Vector2 p,int d,bool control){Color c=control?ink:new Color(.33f,.65f,.58f);int dx=d==0?1:d==2?-1:0,dy=d==1?1:d==3?-1:0;for(int t=-22;t<12;t++)Box(p.x+dx*t-3,p.y+dy*t-3,6,6,c);for(int t=0;t<14;t++){float x=p.x+dx*(10+t),y=p.y+dy*(10+t);if(dx!=0)Box(x-1,y-(14-t),3,(14-t)*2,c);else Box(x-(14-t),y-1,(14-t)*2,3,c);}if(control){Ell(p.x-3,p.y+34,6,6,new Color(.85f,.6f,.21f));Ell(p.x-3,p.y-40,6,6,new Color(.85f,.6f,.21f));Ell(p.x-40,p.y-3,6,6,new Color(.85f,.6f,.21f));Ell(p.x+34,p.y-3,6,6,new Color(.85f,.6f,.21f));}}
void OnGUI(){if(winds==null)return;float scale=UiScale;GUI.matrix=Matrix4x4.TRS(new Vector3((Screen.width-DesignWidth*scale)/2,(Screen.height-DesignHeight*scale)/2,0),Quaternion.identity,new Vector3(scale,scale,1));if(label==null)label=new GUIStyle(GUI.skin.label){font=chinese,wordWrap=true};Box(-300,-300,1320,1880,new Color(.98f,.96f,.88f));Ell(540,-54,245,230,new Color(1,.88f,.58f));Cloud(new Vector2(60,90),0,.8f);Text("小云朵搬家",110,40,500,75,52,ink);Text("给风一个方向，送云一程好心情",60,126,600,44,26,ink);Text("第 "+(level+1)+" / 10 站 · "+L.name,36,194,648,50,32,ink);Text("轻点黄色风车 · 转好方向再出发",36,254,648,38,26,new Color(.28f,.45f,.42f));
Ell(36,302,648,600,new Color(.81f,.88f,.76f));for(int c=0;c<25;c++){Vector2 p=Center(c);if(IsRoad(c)){Ell(p.x-52,p.y-52,104,104,new Color(.86f,.94f,.86f));bool home=false;for(int i=0;i<L.routes.Length;i++)if(c==L.routes[i].cells[L.routes[i].cells.Length-1]){House(p,L.routes[i].color);home=true;}if(!home&&winds.ContainsKey(c)){bool control=Array.IndexOf(L.controls,c)>=0;if(control){Ell(p.x-39,p.y-39,78,78,gold);Ell(p.x-32,p.y-32,64,64,new Color(1,.9f,.64f));}Arrow(p,winds[c],control);if(control&&Hit(p.x-53,p.y-53,106,106,false,!running&&!won))Turn(c);}}else Tree(p,c);}
for(int i=0;i<pos.Length;i++)if(!arrived[i])Cloud(pos[i],L.routes[i].color,1.12f);if(flash>0)for(int i=0;i<20;i++){float t=Time.time*2+i;Ell(70+i*30,330+(Mathf.Sin(t)*.5f+.5f)*530,8,14,colors[i%3]);}
Text(message,40,918,640,82,28,ink);if(won){if(Button(level==9?"再玩一遍":"下一站 →",64,1010,592,100,gold,34)){if(level<9)level++;else level=0;Load();}}else if(Button(running?"停风调整":"出发 · 试试风向",64,1010,592,100,mint,34))Go();
if(Button("撤销",36,1128,150,104,new Color(.89f,.91f,.84f)))Undo();if(Button("重置",202,1128,150,104,new Color(.89f,.91f,.84f)))Load();if(Button("提示",368,1128,150,104,new Color(.89f,.91f,.84f),30,false,!running&&!won)){var solution=L.Solution();foreach(int c in L.controls)if(winds[c]!=solution[c]){history.Push(new Dictionary<int,int>(winds));winds[c]=solution[c];hints++;message="这一个风车调好啦！观察它指向哪里。";Save();Announce();break;}}if(Button("选关",534,1128,150,104,new Color(.89f,.91f,.84f))){menu=!menu;Announce();}
Text("已到家 "+Count(solved)+" / 10 · 自动保存",190,1245,340,28,20,ink);
if(menu){Box(0,0,720,1280,new Color(.13f,.25f,.22f,.88f));Ell(40,216,640,936,new Color(.98f,.96f,.88f));Text("选择一趟搬家",60,250,600,72,42,ink);for(int i=0;i<10;i++){int n=i;float x=64+(i%2)*308,y=350+(i/2)*132;if(Button((i+1)+" · "+(i>unlocked?"未解锁":Levels.All[i].name),x,y,284,104,i>unlocked?new Color(.78f,.8f,.74f):((solved&(1<<i))!=0?mint:gold),30,true,i<=unlocked)){level=n;Load(true);}}if(Button("回到花园",140,1025,440,100,pink,32,true)){menu=false;Announce();}}}
int Count(int n){int c=0;while(n>0){c+=n&1;n>>=1;}return c;}
}
}
