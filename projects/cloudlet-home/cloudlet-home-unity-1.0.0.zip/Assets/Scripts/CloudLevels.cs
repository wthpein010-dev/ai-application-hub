using System;using System.Collections.Generic;using UnityEngine;
namespace Cloudlet {
[Serializable] public class Route {public int[] cells; public int color;public Route(int c,params int[] p){color=c;cells=p;}}
public class Level {public string name,tip;public Route[] routes;public int[] controls;public Level(string n,string t,int[] c,params Route[] r){name=n;tip=t;controls=c;routes=r;}public Dictionary<int,int> Solution(){var d=new Dictionary<int,int>();foreach(var r in routes)for(int i=0;i<r.cells.Length-1;i++){int a=r.cells[i],b=r.cells[i+1];d[a]=b==a+1?0:b==a+5?1:b==a-1?2:3;}return d;}}
public static class Levels {public static Level[] All={
new Level("第一次乘风","点击黄色风车，转到向右，再点「出发」。",new[]{11},new Route(0,10,11,12,13,14)),
new Level("拐个小弯","云朵每到一格，都会跟随这里的箭头。",new[]{2,12},new Route(0,0,1,2,7,12,13,14)),
new Level("花园兜风","试飞失败也没关系，风向还会保留下来。",new[]{21,11,13},new Route(0,20,21,16,11,12,13,8,3,4)),
new Level("两位邻居","两朵云一起出发，分别回到同色的小屋。",new[]{1,3,21,23},new Route(0,0,1,6,11,16,21,20),new Route(1,4,3,8,13,18,23,24)),
new Level("绕过小池塘","薄荷色是道路，树木和池塘都不能穿过。",new[]{5,11,17,23},new Route(0,0,5,10,11,12,17,22,23,24)),
new Level("穿过风铃街","锁定的小风带不能转，先观察它们的方向。",new[]{1,3,13,11},new Route(0,0,1,2,3,4,9,14,13,12,11,10,15,20)),
new Level("相邻的晚霞","粉云住粉屋，白云住黄屋，别走错门。",new[]{1,7,13,21},new Route(0,0,1,6,7,8,13,14),new Route(1,24,23,22,21,16,11,10)),
new Level("螺旋风车","有些箭头会把你送回旧路，留心循环。",new[]{21,23,13,11,6},new Route(0,20,21,22,23,24,19,14,13,12,11,6,1,2,3,4)),
new Level("雨后彩虹","需要时点「提示」，只会修好一个风车。",new[]{1,7,17,19},new Route(0,0,1,2,7,12,17,16,15,20),new Route(1,4,9,8,13,18,19,24)),
new Level("全村搬家日","最后一趟！三位小邻居一起回家。",new[]{1,11,7,17,3,13},new Route(0,0,1,6,11,16,21,20),new Route(1,2,7,12,17,22),new Route(2,4,3,8,13,18,23,24))
};public static void Validate(){for(int k=0;k<All.Length;k++){var l=All[k];var used=new HashSet<int>();foreach(var r in l.routes){foreach(int c in r.cells){if(c<0||c>24||!used.Add(c))throw new Exception("Invalid/overlapping route "+k);}for(int i=1;i<r.cells.Length;i++){int a=r.cells[i-1],b=r.cells[i];if(Mathf.Abs(a%5-b%5)+Mathf.Abs(a/5-b/5)!=1)throw new Exception("Nonadjacent route "+k);}}foreach(int c in l.controls)if(!l.Solution().ContainsKey(c))throw new Exception("Bad control "+k);Debug.Log("CLOUDLET VERIFIED level "+(k+1)+" clouds="+l.routes.Length);}}}
}
