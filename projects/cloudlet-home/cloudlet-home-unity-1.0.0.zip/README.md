# 小云朵搬家
Unity 2022.3.62f3c1，原创轻休闲风向解谜，版本 1.0.0。打开 Assets/Scenes/Cloudlet.unity 即可游戏。
编辑器菜单批处理：-batchmode -quit -projectPath <工程目录> -executeMethod CloudBuild.WebGL -buildTarget WebGL。
所有原创代码与图形可随工程交付；Noto Sans SC 字体许可证位于 Assets/Fonts/OFL.txt。生成缓存 Library、Temp、Logs 不属于源码。验收见 QA/。

浏览器验收复现：进入 Tools，npm install；npx playwright install chromium；npm test。390×844 为浏览器模拟触摸，真实移动硬件尚未验证。
